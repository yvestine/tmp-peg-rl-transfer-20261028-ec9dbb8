# 插孔 RL 模型状态核对

核对日期：2026-10-28。本文纠正此前仅引用 phase50 旧基线、遗漏 original50 guided 及复测结果的汇总。

## 当前结论

旧 residual PPO + gated_residual_v2 继续作为稳定比较基线。接触收益预测引导的 guided PPO 是 original50 单轮最高分候选，但复测未持续超过旧模型，不能称为稳定 92% 的最佳策略。

| 同一 original50 开发场景 | 首轮 | 追加复测 |
| --- | ---: | ---: |
| frozen：旧 PPO + gated-v2 | 44/50 | 44/50 |
| guided：接触收益预测引导 PPO + gated-v2 | 46/50 | 43/50 |
| control：同预算继续 PPO + gated-v2 | 42/50 | 未在该追加复测中运行 |

两轮是同一组 50 条历史开发条件，不是 100 个独立场景。guided 两轮合计 89/100、旧模型 88/100，不足以支持稳定优越的结论。此前 phase50 的旧模型 43/50、control 43/50、阶段两组各 41/50 属于另一套条件，不能与 original50 混为同一排名。新自动门控模型的 10/50 则来自新局部插入起点，也不在本表的协议中。

原始证据：

- `outputs/tavla_rl/ppo_fusion/contact_counterfactual_v3_20261023/comparison.json`
- 同目录 `followup_original50/comparison.json` 和 `report.md`
- `outputs/tavla_rl/ppo_contact_phase/run_20261025_010318/comparison.json`

## 旧基线怎么做

在录制 VLA 名义参考的局部插入仿真上训练残差 PPO。best checkpoint 为 1,109,407 有效步，Actor 156D、Critic 183D；Critic 可用仿真物理真值，Actor 使用机器人状态、去偏力历史、冻结 32D 力 latent、名义动作及估计几何量。奖励包含插入/横向进展、成功和失败，以及力、姿态、时间与动作变化代价。

实时评测中 VLA 持续重规划。入口采用外部规则：估计尖端相对孔口 -10～+8 mm；负荷至少 1 N 持续三个 10Hz tick；最近一秒下降不足 0.5 mm。RL 输出当前 VLA 位姿上的五维局部修正，限幅为 XY 各 2 mm、Z 3 mm、roll/pitch 各 2°，经 IK 与原关节限速执行。零残差或 IK 失败恢复原 VLA 分支。

这些入口条件和几何输入保留了工具/孔口标定依赖，不是学出来的自动接管。

旧权重：`outputs/tavla_rl/ppo_fusion/run_20261022_010632/residual/train_000/checkpoints/best.pth`。

## guided 候选额外做了什么

1. 在近似匹配的仿真起点与前缀上分叉：两条零修正、旧 PPO、旧 PPO 五轴正负扰动，共 13 分支，比较后续 24 tick / 2.4 秒的结果。配对前检查关节、位置、力和门控一致性，并记录双零分支差异；这不是精确状态克隆。
2. 三个预测器估计累计奖励、进展、峰值力和失败。Actor 实际接收的是 11 个候选相对零修正的预测回报均值与集成分歧，共 22D；风险输出没有直接作为动作安全筛选器。
3. 在原状态、门控与 20 步运动历史上加入这些预测特征，从旧 actor/critic 初始化，冻结预测器，再做约 120 万步真实仿真 PPO rollout 更新。
4. 部署仍继承 StableFusionEnv：何时介入仍由旧规则决定，guided 学的是结合历史与预测特征如何修正。它尚未解决无高度标定的自动介入。

预测器诊断仅 33 个保留配对组，收益方向准确率 56.25%，MSE 0.120140、零收益基线 0.120409。其可靠性和不确定性校准不足以支持作为独立可信门控。

guided 权重：`outputs/tavla_rl/ppo_fusion/contact_counterfactual_v3_20261023/training/guided/attempt_000/checkpoints/best.pth`，依赖原 base checkpoint，预测器权重已包含在 actor state 中。
