"""Simulation adapter matching the force-alignment-latent dataset converter.

Supply one already aligned robot-base XYZ force sample per 0.1 s of SIMULATION
time. The first 20 samples calibrate a fixed baseline. Force derivatives are
computed before forming sliding windows, retaining the derivative at the
window's left edge. Two histories are separate: 32 encoder feature rows and
10 resulting latent rows for the remote VLA policy.
"""

from collections import deque
import hashlib
from pathlib import Path

import numpy as np
import torch

from insertion_alignment_encoder.deploy_infer import ForceAlignmentLatentEncoder
from insertion_alignment_encoder.preprocess import initial_baseline, normalize_features


DEFAULT_ENCODER = Path(__file__).resolve().parent / "assets" / "encoder.pt"
ENCODER_SHA256 = "db793ebd4f3158b8a8add895cf04368b2289df7fad450f1d2a39b09bb46acd80"
POLICY_HISTORY = 10


def aligned_force_from_calibrated_link7(wrench_base_n: np.ndarray) -> np.ndarray:
    """Match sim-data-aligned: -1 * calibrated link7 XYZ, scale 1.

    The caller must provide the SAME calibrated sensor convention as the
    original simulator exporter, in robot-base axes. Do not apply this to
    obs/state/ee_force_base (which is already aligned), or to an uncalibrated
    body wrench/contact sensor with a different convention.
    """
    wrench = np.asarray(wrench_base_n, dtype=np.float32)
    if wrench.shape not in ((3,), (6,)) or not np.isfinite(wrench).all():
        raise ValueError("Expected a finite calibrated base-frame wrench of shape (3,) or (6,)")
    return -wrench[:3].copy()


def gripper_width_to_position(width_m: float, max_width_m: float = 0.08) -> float:
    """Map total two-finger opening width to the recorded gripper_pos scale."""
    width, maximum = float(width_m), float(max_width_m)
    if not np.isfinite([width, maximum]).all() or maximum <= 0 or not 0 <= width <= maximum:
        raise ValueError("Expected 0 <= total gripper width <= positive maximum width")
    return width / maximum


class StreamingForceAlignmentEncoder:
    """Causal streaming encoder with the dataset's baseline and derivative."""

    def __init__(self, encoder_path: str | Path = DEFAULT_ENCODER, device: str = "cpu"):
        if hashlib.sha256(Path(encoder_path).read_bytes()).hexdigest() != ENCODER_SHA256:
            raise ValueError("Encoder checkpoint does not match this bundle and the trained pure-real policy")
        self.encoder = ForceAlignmentLatentEncoder(encoder_path, device=device)
        if self.encoder.latent_dim != 32:
            raise ValueError("This policy requires a 32-dimensional force-alignment latent")
        self.reset()

    def reset(self) -> None:
        self._calibration_force: list[np.ndarray] = []
        self._calibration_time: list[float] = []
        self._features: deque[np.ndarray] = deque(maxlen=self.encoder.history)
        self._latents: deque[np.ndarray] = deque(maxlen=POLICY_HISTORY)
        self._baseline: np.ndarray | None = None
        self._previous_residual: np.ndarray | None = None
        self._previous_timestamp: float | None = None
        self.samples_seen = 0

    @property
    def ready(self) -> bool:
        return self._baseline is not None and len(self._latents) > 0

    @property
    def effort_history(self) -> np.ndarray:
        """Return unnormalized float32 (10, 32), oldest first/current last."""
        if not self.ready:
            raise RuntimeError(f"Collect {self.encoder.baseline_frames} startup force samples first")
        rows = np.stack(self._latents).astype(np.float32)
        if len(rows) < POLICY_HISTORY:
            rows = np.concatenate([np.repeat(rows[:1], POLICY_HISTORY - len(rows), axis=0), rows])
        return rows.copy()

    @torch.inference_mode()
    def update(self, force_xyz_n: np.ndarray, timestamp_s: float) -> np.ndarray | None:
        """Update exactly once per new sample; return effort history after calibration."""
        force = np.asarray(force_xyz_n, dtype=np.float32)
        timestamp = float(timestamp_s)
        if force.shape != (3,) or not np.isfinite(force).all() or not np.isfinite(timestamp):
            raise ValueError("Expected finite force (3,) and a finite timestamp in seconds")
        if self._previous_timestamp is not None and timestamp <= self._previous_timestamp:
            raise ValueError("Simulation timestamps must strictly increase; reset on a new episode")

        if self._baseline is None:
            self._calibration_force.append(force.copy())
            self._calibration_time.append(timestamp)
            self._previous_timestamp = timestamp
            self.samples_seen += 1
            if len(self._calibration_force) < self.encoder.baseline_frames:
                return None
            forces = np.stack(self._calibration_force)
            times = np.asarray(self._calibration_time, dtype=np.float64)
            self._baseline = initial_baseline(forces, self.encoder.baseline_frames)
            # Backfill all startup latents with the final fixed 20-frame baseline,
            # giving the VLA genuine latent history at its first request.
            features = self.encoder.features(forces, times)
            latents = self.encoder.latents(forces, None, times)
            self._features.extend(features)
            self._latents.extend(latents)
            self._previous_residual = force - self._baseline
            self._calibration_force.clear()
            self._calibration_time.clear()
            return self.effort_history

        residual = force - self._baseline
        dt = np.float32(np.clip(timestamp - self._previous_timestamp, 0.02, 0.5))
        derivative = (residual - self._previous_residual) / dt
        feature = normalize_features(np.concatenate([residual, derivative])[None], self.encoder.scales)[0]
        self._features.append(feature)
        window = np.stack(self._features)
        if len(window) < self.encoder.history:
            window = np.concatenate([np.repeat(window[:1], self.encoder.history - len(window), axis=0), window])
        x = torch.from_numpy(window[None]).to(self.encoder.device)
        latent, _, _ = self.encoder.model(x)
        self._latents.append(latent[0].cpu().numpy().astype(np.float32))
        self._previous_residual = residual
        self._previous_timestamp = timestamp
        self.samples_seen += 1
        return self.effort_history


def _rgb(image: np.ndarray, name: str) -> np.ndarray:
    image = np.asarray(image)
    if image.ndim != 3 or image.shape[-1] != 3 or image.dtype != np.uint8 or min(image.shape[:2]) < 4:
        raise ValueError(f"{name} must be RGB uint8 (H,W,3); convert BGR/RGBA explicitly")
    return np.ascontiguousarray(image)


class TavlaSimulationAdapter:
    """Turn synchronized simulation observations into the policy wire schema."""

    def __init__(self, encoder_path: str | Path = DEFAULT_ENCODER, device: str = "cpu"):
        self.force_encoder = StreamingForceAlignmentEncoder(encoder_path, device=device)

    def reset(self) -> None:
        self.force_encoder.reset()

    def update_force(self, force_xyz_n: np.ndarray, timestamp_s: float) -> np.ndarray | None:
        return self.force_encoder.update(force_xyz_n, timestamp_s)

    def build_observation(
        self,
        front_rgb: np.ndarray,
        wrist_rgb: np.ndarray,
        joint_pos_rad: np.ndarray,
        gripper_pos: float,
        prompt: str = "peg-in-hole",
    ) -> dict:
        joints = np.asarray(joint_pos_rad, dtype=np.float32)
        gripper = float(gripper_pos)
        if joints.shape != (7,) or not np.isfinite(joints).all():
            raise ValueError("joint_pos_rad must contain seven finite joints in training order")
        if not np.isfinite(gripper) or not 0 <= gripper <= 1:
            raise ValueError("gripper_pos must be the recorded normalized position, not width in meters")
        if not isinstance(prompt, str) or not prompt:
            raise ValueError("prompt must be a nonempty string")
        front, wrist = _rgb(front_rgb, "front_rgb"), _rgb(wrist_rgb, "wrist_rgb")
        return {
            "images": {"cam_high": front, "cam_left_wrist": wrist, "cam_right_wrist": wrist},
            "state": np.concatenate([joints, np.asarray([gripper], dtype=np.float32)]),
            "effort": self.force_encoder.effort_history,
            "prompt": prompt,
        }
