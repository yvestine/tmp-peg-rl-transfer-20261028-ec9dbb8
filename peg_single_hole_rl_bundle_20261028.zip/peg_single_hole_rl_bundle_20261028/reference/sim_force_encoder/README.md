# Force-alignment latent：纯真机 TAVLA 策略的仿真接入包

本包供仿真侧使用：**仿真机本地运行最新的力 encoder，把相机、机器人状态和
10 帧 encoder latent 发给训练机上的 TAVLA server，接收关节位置目标。**
完整 TAVLA/Pi0 权重留在训练机。

目标策略固定为已完成的纯真机实验：

```text
训练配置：pi0_lora_user_single_arm_control_latent
实际数据：local/tavla_single_arm_force_align_latent（40 episodes / 7188 frames）
实验名称：force_align_latent_gpu0123_fsdp
最终步数：29999（共 30000 个训练步骤）
checkpoint：checkpoints/pi0_lora_user_single_arm_control_latent/force_align_latent_gpu0123_fsdp/29999
```

配置名保留了 `control_latent`，但这次数据里的 effort 是 **ForceAlignmentEncoder
输出的力对齐 latent**。当前启动中的 co-training 实验是另一个策略，不能混用其权重。
这里的“纯真机”指 VLA 策略微调数据；本 encoder 自己的预训练使用了成对的 Real/Sim 力。

## 1. 先跑通连接

解压后进入本 README 所在目录。Python 推荐 3.11（最低 3.10）；CPU 可以运行 encoder，
无需在仿真侧安装 JAX、LeRobot、OpenPI 服务端或 TAVLA 大模型。

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python validate_bundle.py
```

`validate_bundle.py` 校验文件 SHA256、encoder 加载、两域参考力序列、在线/离线
latent 一致性、两层历史、reset 和 NumPy websocket 序列化。首次运行应输出 `PASS`。
依赖安装需要包源；本包未附带 PyTorch 等安装轮子。

如果从自己的仿真项目目录导入这些模块，把解压后的包根目录加入 Python 搜索路径：

```python
import sys
sys.path.insert(0, "/PATH/TO/force_align_latent_sim_bundle_20261004")
from sim_adapter import TavlaSimulationAdapter
```

这样也会优先使用包内与当前服务端匹配的 `openpi_client`，避免其它环境中的旧版客户端。

训练侧 server 就绪后，在仿真机执行（把 `TRAINING_HOST` 替换为可达的训练机地址）：

```bash
python smoke_client.py --host TRAINING_HOST --port 8000
```

这是用包内一条固定真机观测检查网络和推理返回，**不会驱动机器人，也不是仿真成功率测试**。
应返回 `actions_shape: [50, 8]`、`actions_finite: true` 和正确的模型身份 metadata。
运行时部署记录在 `deployment_status.json`；最终验证记录在 `verification.json`。

## 2. 这个 encoder 的身份与转移清单

最新 encoder 复制自：

```text
TAVLA/eval_outputs/insertion_alignment_encoder/encoder.pt
artifact_format = tavla_force_alignment_encoder_terminal_reference_v1
geometry_supervision = true
SHA256 = db793ebd4f3158b8a8add895cf04368b2289df7fad450f1d2a39b09bb46acd80
```

它是 `train_terminal_geometry.py` 训练的 force-only 模型：六通道力特征经过
Conv1d / 因果卷积块 / GRU / Tanh 得到 32 维 latent。当前产物包含分类头及位置辅助头；
VLA 只用 latent。在线计算无需 EE pose、孔位置、分类标签或几何标定目标。

已用当前 checkpoint 重算真机 traj 0、1、39 的全部 latent；与这轮 VLA
实际读取的训练集逐项比较，最大绝对误差均为 0.0。详细身份记录见 `manifest.json`。

| 文件/目录 | 仿真侧用途 |
|---|---|
| `assets/encoder.pt` | 最新 encoder 权重、特征尺度、历史长度、基线参数，必须一起保留 |
| `insertion_alignment_encoder/` | 原仓库的模型、预处理、离线推理源码快照 |
| `sim_adapter.py` | 与数据转换器一致的在线预处理、两层历史、请求组装 |
| `openpi_client/` | 与当前 server 匹配的轻量 websocket/NumPy MessagePack 客户端 |
| `sim_loop_example.py` | 框架无关的单环境闭环接入示例 |
| `replay_client.py` | 已保存仿真观测流的请求回放示例 |
| `smoke_client.py` | 单请求连通性/模型身份检查 |
| `reference/` | 两域力序列、预期 latent、固定观测及仿真力来源约定 |
| `manifest.json` / `verification.json` | 校验和、模型身份、已执行验证的结果 |
| `training_side/serve_force_align_latent_real.py` | 训练机专用 server 启动脚本副本 |

仿真侧不需要传输 Pi0 的 `params/`、优化器 `train_state/`、训练集或策略归一化统计。
策略归一化统计保留在训练机 checkpoint 的 `assets/norm_stats.json`，server 自动使用。

旧包 `sim_side_test_bundle.zip` 对应另一套仿射/10 维力趋势处理。
本模型使用本包的 32 维 encoder latent；不要再叠加旧的
`sim_aligned_to_real_affine.pt`、10 维 `force_features.py` 或旧 `ControlEncoder`。

## 3. 训练机启动 server

训练机仓库已经提供专用入口 `scripts/serve_force_align_latent_real.py`。进入已有的
`force` tmux 会话；在 TAVLA 根目录的 shell 中执行：

```bash
tmux attach -t force
# 在 force 窗口中的 TAVLA shell 执行：
cd /data/workspace/gujiawei/TAVLA
CUDA_VISIBLE_DEVICES=5 \
OPENPI_DATA_HOME=/data/workspace/gujiawei/TAVLA/.cache/openpi \
XLA_PYTHON_CLIENT_PREALLOCATE=false \
PYTHONUNBUFFERED=1 \
.venv/bin/python scripts/serve_force_align_latent_real.py --port 8000
```

GPU 5 是本次部署时选择的空闲卡；重启时请按当时 GPU 使用情况调整。
本次部署运行在已存在的 `force:0` tmux 窗口，没有创建新会话。
可用 `tmux attach -t force` 查看会话；监听地址及日志路径见 `deployment_status.json`。

若只携带本包回到另一台训练机，可在那台机器的 TAVLA 根目录执行：

```bash
CUDA_VISIBLE_DEVICES=5 XLA_PYTHON_CLIENT_PREALLOCATE=false \
.venv/bin/python /PATH/TO/BUNDLE/training_side/serve_force_align_latent_real.py \
  --tavla-root /PATH/TO/TAVLA \
  --checkpoint-dir checkpoints/pi0_lora_user_single_arm_control_latent/force_align_latent_gpu0123_fsdp/29999 \
  --encoder /PATH/TO/BUNDLE/assets/encoder.pt \
  --port 8000
```

该入口检查 `assets/datasets.txt` 确实只有真机 force-align 数据集；读取 checkpoint
自带的 norm stats；在握手 metadata 中发布 encoder SHA256 和输入输出形状。
它不会在服务端把原始力变成 latent。首次推理有 JAX 编译时间，明显慢于后续请求。

网络协议是 `ws://TRAINING_HOST:8000` 的二进制 websocket + NumPy MessagePack，
不是 HTTP REST/JSON。握手第一帧为 metadata；随后一个请求对应一个响应。
server 监听 `0.0.0.0`。如果两机不能直接连端口，可在仿真机做 SSH 转发：

```bash
ssh -N -L 8000:127.0.0.1:8000 gujiawei@TRAINING_HOST
# 另一个终端：
python smoke_client.py --host 127.0.0.1 --port 8000
```

## 4. 仿真侧发送的输入

server 的请求是以下**嵌套结构**，不要发送 LeRobot 文件里的 `observation.*` 字段名：

```python
obs = {
    "images": {
        "cam_high": front_rgb,        # uint8 (H, W, 3), RGB
        "cam_left_wrist": wrist_rgb,  # uint8 (H, W, 3), RGB
        "cam_right_wrist": wrist_rgb, # 训练时左右 wrist 使用同一张图
    },
    "state": state,                  # float32 (8,)
    "effort": latent_history,        # float32 (10, 32)
    "prompt": "peg-in-hole",
}
```

| 字段 | 内容与约定 |
|---|---|
| `cam_high` | 前方相机，对应训练 `front_camera.mp4`；需合理匹配训练视角 |
| `cam_left_wrist` | 腕部相机，对应训练 `wrist_camera.mp4` |
| `cam_right_wrist` | 复制同一张 wrist 图；省略时当前 server 也会自动复制 left |
| `state[:7]` | 7 个机械臂关节位置，rad，按训练 joint_0…joint_6 顺序（Franka panda_joint1…7） |
| `state[7]` | 归一化夹爪位置 `gripper_pos`，0 闭合、1 最大总开口；参考最大总宽度 0.08 m |
| `effort` | 最近 10 个采样时刻的原始 encoder latent，时间从旧到新，最后一行是当前帧 |
| `prompt` | `peg-in-hole`；专用 server 缺省时也使用这个训练任务 |

相机图像应是 RGB、`uint8` 0…255、HWC；OpenCV 图像须先做 BGR→RGB，
RGBA 须去掉 alpha。不要在客户端做 ImageNet 标准化或转换成 -1…1；server
会按训练流程保留比例缩放并补边到 224×224，再做模型图像预处理。
也可以直接发已经正确缩放补边的 224×224 RGB 图。

`state` 发真实物理位置，不做 z-score、不 pad 到 32；server 会 pad 与归一化。
`effort` 发 encoder 的 Tanh 输出（通常在 [-1,1]），**不要手工再做策略 z-score**；
server 用这轮纯真机训练的 effort norm stats 做归一化。encoder 六通道的尺度归一化
仍在仿真机执行，这是两个不同步骤。

夹爪如果已有同定义的 `obs/state/gripper_pos`，直接使用。如果只拿到两指总宽度：

```python
from sim_adapter import gripper_width_to_position
gripper_pos = gripper_width_to_position(total_opening_width_m, max_width_m=0.08)
```

注意总宽度是两指间距，不是单指滑动关节位置；若仿真测量的是一个对称指关节，
应先换成总宽度再转换。训练 40 条轨迹中该值约在 [0,0.0948473]，
traj 0 的初始值约为 0.086524（总宽度约 0.006922 m）。不要误认为 0.0865 是米。

## 5. 力从仿真传感器到 encoder 的预处理

### 5.1 先明确传感器来源、坐标系和符号

encoder 的物理输入为 **robot-base 坐标系三轴力 `[Fx,Fy,Fz]`，单位 N**。
只使用力；不使用力矩、关节力矩、EE pose、孔位或 action。

当前 encoder 预训练的 Sim 分支来自 `sim-data-aligned/`。其真实保存的来源约定为：

```text
source = sim/force/panda_link7_wrench_calibrated
obs/state/ee_force_base = -1.0 * 1.0 * calibrated_wrench[:, :3]
```

来源记录见 `reference/sim_force_source_contract.json`。构建脚本顶部历史描述出现过
scale=3.4，但**实际执行常量、40 条轨迹 manifest 和 HDF5 属性均为 scale=1.0**；
部署按实际值 1.0，不使用 3.4，也不使用旧的全局仿射幅值对齐器。

根据手里拿到的信号，使用下表：

| 手里的信号 | 送 adapter 前的操作 |
|---|---|
| 已生成的 `sim-data-aligned/.../obs/state/ee_force_base` | 直接使用 XYZ；符号已对齐，不再取负 |
| 与原采集器同定义、同标定且已在 base 轴下的 `panda_link7_wrench_calibrated` | 调用 `aligned_force_from_calibrated_link7(...)`，取 XYZ 并乘 -1 |
| 原始 link/body local force | 先做对应传感器标定、重力/空载补偿与坐标转换，再确定上述符号约定 |
| world-frame force | 先通过 `R_base_from_world @ force_world` 转为 robot base，再确定符号 |
| 任意其它 contact sensor / contact force sum | 先确认采集对象和力的作用方向确实对应原 link7 信号；不能仅根据名字直接套用 |

例如仿真输出的是 local-frame 力，旋转矩阵明确为 source 到 base 时，
`force_base = R_base_from_source @ force_source`。确认是“环境作用在机器人/工具上”的
哪一侧；反作用力会导致整体符号相反。最新 encoder 只有 3 维力，不需要力矩参考点转换。
本训练仓库保存了来源构建代码和信号，但没有仿真框架内 live calibrated-link7 采集器；
该采集接口由仿真侧接入自己的传感器。**基线扣除不能代替运动过程中的重力/惯性补偿。**

### 5.2 保持 10 Hz、使用仿真时间

每 0.1 s 的**仿真时间**读取一帧力、相机、joint/gripper 状态，彼此对齐。
物理仿真可以运行 100/500 Hz，但 encoder 与策略接口应采样为 10 Hz。
不要把所有 physics substep 塞入 encoder；否则 32 帧/10 帧历史的时间跨度会变。

timestamps 为 float 秒，严格递增，每个 episode 可以从 0 开始。
不要使用网络请求返回时的墙钟时间；网络延迟不应改变力变化率。
episode 切换时必须清空历史与基线。

### 5.3 六通道及 32 帧窗口

`sim_adapter.py` 自动完成以下过程，无需仿真侧重写：

1. 收集每个 episode 前 20 帧（约 2 s）的力，逐轴取中位数 `b`。
   前 19 帧返回 `None`，第 20 帧起可请求策略。起始采样应处于与训练相同的空载/起始条件；
   保持位置收集基线。基线之后固定，不随着接触阶段更新。
2. `r[t] = F[t] - b`。
3. `dt[t] = clip(timestamp[t]-timestamp[t-1], 0.02, 0.5)`；
   `d[t] = (r[t]-r[t-1])/dt[t]`，episode 首帧变化率为 0。
4. 按 `[rx, ry, rz, dx, dy, dz]` 拼成 6 通道，除以 checkpoint 的固定 scales：

   ```text
   [3.3949546814, 3.0217967033, 3.5476562977,
    6.2329111099, 4.7157235146, 7.2345128059]
   ```

   然后逐项 clip 到 [-10,10]。前 3 个尺度的单位对应 N，后 3 个对应 N/s。
   不在新 episode 或新仿真数据上重新拟合这些尺度。
5. 当前帧和之前 31 帧的归一化特征组成 `(32,6)`，从旧到新。
   episode 开头不足 32 帧时在左侧重复首帧特征，与训练一致。
6. `model.eval()` / `inference_mode()` 得到当前 32 维 latent。
   重跑每个窗口的 GRU，不跨窗口缓存 GRU hidden state。
7. 保留最新 10 个 latent 组成 `(10,32)` 发给 VLA。第 20 帧确定基线后，会补算
   前 20 帧的 latent，所以第一条请求已有真实的 10 帧历史。

两个窗口不能混淆：**32 帧原始力特征 → 1 个 latent；10 帧 latent → 1 个策略请求。**
维护滑动窗口前先计算变化率，因此窗口最左侧的变化率也保持与整轨迹转换一致。
仓库旧 `runtime.py` 会在每个滚动窗口的最左侧重新置零变化率；本包的在线适配器
已避开这一差异，并用真实/仿真参考序列与 `deploy_infer.py` 验证。

## 6. 仿真代码最小接入

下面使用的是已经对齐的 base XYZ 力；如果拿到 calibrated link7 源，先按第 5 节取负。

```python
import numpy as np
import torch
from sim_adapter import TavlaSimulationAdapter
from openpi_client.websocket_client_policy import WebsocketClientPolicy

torch.set_num_threads(1)  # 小模型 CPU 推理通常不需要很多线程
adapter = TavlaSimulationAdapter(device="cpu")
policy = WebsocketClientPolicy(host="TRAINING_HOST", port=8000)

# 新 episode：reset 仿真、两层力历史，以及服务端 policy RNG。
adapter.reset()
policy.reset()

# 每一个 10 Hz 新采样时刻调用一次；查询策略频率可以更低，但力采样不能停。
history = adapter.update_force(force_xyz_base_n, simulation_time_s)
if history is not None:
    obs = adapter.build_observation(
        front_rgb=front_rgb_uint8,
        wrist_rgb=wrist_rgb_uint8,
        joint_pos_rad=np.asarray(seven_arm_joints_in_training_order, np.float32),
        gripper_pos=normalized_gripper_position,
    )
    action_chunk = np.asarray(policy.infer(obs)["actions"], dtype=np.float32)  # (50,8)
    target = action_chunk[1]
    joint_targets_rad = target[:7]
    gripper_target = float(np.clip(target[7], 0.0, 1.0))
    # 仿真侧：把 joint_targets_rad 交给位置控制器。
    # 如控制器接收米制夹爪宽度，total_width_m = gripper_target * 0.08。
```

完整框架无关闭环例子见 `sim_loop_example.py`。需要仿真环境实现：

| 环境接口 | 定义 |
|---|---|
| `env.reset()` | 初始化机器人、物体、相机与传感器 |
| `env.observe()` | 返回同步的 force/timestamp/images/joints/gripper，字段见示例源码 |
| `env.hold_tick(0.1)` | 保持机器人起始位置并推进 0.1 s 仿真时间，用于基线采样 |
| `env.step_target(joints_rad, gripper_pos, 0.1)` | 执行绝对关节/夹爪位置目标并推进 0.1 s |
| `env.is_done()` | 按仿真任务的成功、失败或超时条件判断结束 |

例子同步等待网络响应；等待期间仿真时间不前进。如果仿真持续实时运行，应在另一条
采样路径中持续维护 10 Hz 力历史，按观测时间选 action chunk 的索引并补偿实际延迟。
不要在执行多步 action chunk 时停止采样，再把同一个力样本重复 10 次冒充历史。
每个并行仿真环境需要自己独立的 adapter、基线、timestamp 和历史。

当前 server 共享一套 policy RNG；`reset()` 会重置该服务的 policy RNG。
本包验证的是单环境接入；并行评测若需要独立可复现实验，应分别运行服务实例。

## 7. 返回动作与执行时序

响应结构：`{"actions": numpy_float_array}`，形状 `(50,8)`。
当前 server 的反归一化会得到 `float64`，客户端在交给仿真控制器前可显式转成
`float32`；包内回放和闭环示例已执行此转换。每行是
`[q0_target,...,q6_target,gripper_target]`。

server 已完成 action 反归一化和 delta→absolute 恢复：
**前 7 维是绝对关节位置目标（rad），不是速度、力矩或关节增量**。
不再加当前 state，不再反归一化。夹爪是同一归一化位置尺度，需转换到仿真控制器接口。

训练数据的 `action/actual/arm` 是同帧状态拷贝，因而 chunk 第 0 行对应当前帧；
第 1 行约对应 t+0.1 s。本包的简单示例每次重规划使用 `actions[1]`。
50 个动作覆盖约 5 s 的训练采样跨度；是否执行更多行及如何补偿网络延迟，由仿真
控制周期决定。不要未经时序处理就把 50 行当成连续 physics substep 命令。

## 8. 已保存仿真观测流的回放

如果先在仿真机保存了观测，用 `.npz` 保存以下数组（`np.savez_compressed`）：

```text
force_xyz_n      float32 (T,3)             已对齐 base XYZ 力，N
timestamps_s    float64 (T,)              仿真采样时间，s
joint_pos_rad   float32 (T,7)             相同关节顺序
gripper_pos     float32 (T,) 或 (T,1)     归一化位置
front_rgb       uint8   (T,H,W,3)         RGB
wrist_rgb       uint8   (T,H2,W2,3)       RGB
```

```bash
python replay_client.py --host TRAINING_HOST --port 8000 \
  --npz simulation_observations.npz --force-source aligned \
  --out policy_predictions.npz
```

若 NPZ 的 `force_xyz_n` 是**同定义的 calibrated link7 base 力**而尚未取负，
改用 `--force-source link7-calibrated`。回放输出 `(N_requests,50,8)` 的动作和原始帧号。
输入第 20 帧前为校准，不发请求。观测回放不能代替在仿真中执行动作后的闭环测试。

## 9. 常见接入问题

| 现象 | 检查项 |
|---|---|
| `Wrong policy/encoder server` | server metadata 的 variant/SHA256 是否与包一致，是否连到了 co-training/旧模型端口 |
| 连接拒绝或等待 server | 训练机监听端口、可达地址、server 日志、SSH 转发；客户端连接拒绝时会每 5 s 重试 |
| `effort must be ... (10,32)` | 是否发了 3/6 维原始力、单个 latent、或转置的 (32,10) |
| 动作几乎不变 | 是否用了 chunk[0]、force 样本重复、缺少对应 wrist 相机或错误 joint 顺序 |
| 接触后 latent 异常 | force 来源/符号/坐标轴、10 Hz 采样、baseline 污染、重复旧仿射或 z-score |
| 夹爪开口异常 | 单指位置与总宽度、米与归一化位置、0.08 m 最大宽度换算 |
| 历史串到下一轨迹 | 每次 env reset 同时调用 adapter.reset()，timestamp 从新 episode 重新开始 |

包内的一致性和网络验证确认的是部署协议与计算匹配。真实的仿真任务成功率需要仿真侧
按自己的机器人、相机和传感器接口接入并执行闭环评测，本包未宣称已完成该评测。
