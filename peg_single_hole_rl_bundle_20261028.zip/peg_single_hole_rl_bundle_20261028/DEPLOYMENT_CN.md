# 单孔 peg RL 部署说明

## 模型

- 权重：`checkpoints/best.pth`，residual PPO，配合 `gated_residual_v2` 门控使用。
- checkpoint SHA256：`45f1f4ade17da7dccaf0cfbb771a7e1351993f28ce1cea7a47dfceef2507e89c`。
- 同一组历史仿真开发场景两轮均为 44/50；尚未验证真机成功率。
- Actor 总输入 156 维；`FusionClient.action` 接收 141 维基础观测、5 维当前名义位姿、5 维未来名义位姿，再加入内部 5 维残差状态。
- 输出为 5 维归一化残差，经门控、限幅与 IK 后修正 XYZ、roll、pitch；不是可直接发给机器人的关节命令。

## 建议放在哪里

远端服务器运行配套的单孔 Encoder TAVLA；真机控制电脑运行本包的 RL Actor、观测组装、门控和 IK。

流程：TAVLA 返回名义动作块 → 控制电脑逐步进行 RL 修正和 IK → 机器人控制器。

保持每个 VLA action_chunk 执行 10 步；RL 状态、力反馈和修正按 10 Hz（每 100 ms）更新。客户端需要保留原始名义动作和未来动作，以构造 Actor 输入。

如果希望 RL 和 TAVLA 放在同一台服务器，需要增加 RL 推理接口，按控制步传输匹配的观测并维护各连接的历史状态。现有 TAVLA 服务不会因复制本 checkpoint 而自动启用 RL。

## 包内内容

- `checkpoints/best.pth`：RL 权重。
- `tavla_rl/ppo_fusion/client.py`：CPU/GPU Actor 加载组件。
- `tavla_rl/ppo_fusion_stable/control.py`：接触停滞门控和残差约束。
- 其他 `tavla_rl/` 文件：观测、网络和相关源码；其中的仿真运行入口仍依赖原项目与 Isaac。
- `reference/historical_single_peg_vla_metadata.json`：历史配套单孔 VLA 的身份及数据合同。
- `reference/sim_force_encoder/`：历史仿真编码器参考，含 encoder 权重；真机侧仍需核对预处理合同。
- `reference/real_alignment_review.md`：真机力、TCP 和孔口标定的核对记录。
- `verify_actor.py`：仅 CPU 加载和有限输出检查，不连接机器人或推理服务器。
- `SHA256SUMS`：包内文件校验值。

本包不含 TAVLA 大模型权重，也不含经真机验收的硬件执行桥。开展闭环测试前，需要对接真机状态与力输入、TCP/孔口标定、门控和 IK。

## 解压后检查

在解压目录执行：

```bash
sha256sum -c SHA256SUMS
python verify_actor.py
```

第二条命令需要已有可导入 PyTorch 和 NumPy 的 Python 环境。通过此检查说明模型可加载且输出形状正确，不表示真机数据对齐或闭环接入已完成。
