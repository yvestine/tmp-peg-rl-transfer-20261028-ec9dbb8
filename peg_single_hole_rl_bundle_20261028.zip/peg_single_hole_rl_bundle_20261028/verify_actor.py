from pathlib import Path
import sys
import torch
root = Path(__file__).resolve().parent
sys.path.insert(0, str(root))
from tavla_rl.ppo_fusion.client import FusionClient
client = FusionClient(root / "checkpoints/best.pth", device="cpu")
action = client.action(torch.zeros(1, 141), torch.zeros(1, 5), torch.zeros(1, 5))
if action.shape != (1, 5) or not bool(torch.isfinite(action).all()):
    raise RuntimeError("Actor shape or finite-value check failed")
print("PASS: actor loaded; output shape (1, 5), finite; no robot/network access")
