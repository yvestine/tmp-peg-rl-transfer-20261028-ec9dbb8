# 单孔 peg RL 真机接入资料

这是模型与源代码的适配资料包，尚不包含经真机验收的硬件执行桥，不可直接控制机器人。

- checkpoints/best.pth：历史 residual PPO 最佳权重；原来与 gated-residual-v2、单孔 VLA 共同运行。
- tavla_rl/：Actor、门控、观测合同等相关源代码；代码内的仿真入口及路径还依赖原项目和 Isaac，不是硬件控制程序。
- reference/sim_force_encoder/：历史仿真力编码器参考，仅用于核对权重与合同；不要直接当作已验证的真机力预处理。
- reference/historical_single_peg_vla_metadata.json：历史匹配 VLA 服务身份与输入输出合同。
- reference/real_alignment_review.md：真机输入与几何标定限制。

用有 PyTorch 的 Python 运行 `python verify_actor.py` 只检查 CPU 加载和有限输出，不连接机器人或推理服务器。结果不证明真实输入、TCP、门控、逆解或真实闭环安全。

接入真机还需：可靠的 10 Hz 同步状态和原始名义动作、匹配训练的真实力预处理/latent、robot-base 与工具/TCP/孔口标定、门控与 IK、真实控制器执行及保护；保持 VLA chunk 执行 10 步。先做仅记录的影子运行，之后核对数据再开展闭环。
