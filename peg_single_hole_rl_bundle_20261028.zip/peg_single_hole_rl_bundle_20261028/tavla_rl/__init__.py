"""Standalone residual RL package. Importing it does not launch Isaac Sim."""

__version__ = "1.0.0"
