"""Hand-over start states: fitted from VLA rollouts, widened by a curriculum for training.

Positions of holes are env-local world coordinates (as in the evaluation manifests); hand-over
offsets, hand tilt and approach motion are robot-base-frame quantities.
"""
import copy
from collections import deque
import json
import math
from pathlib import Path
import numpy as np

DISTRIBUTION_FORMAT = 'tavla_v5_handover_distribution_v1'
STATE_FORMAT = 'tavla_v5_handover_state_v1'
STATE_FILE = 'handover_state.npz'


def recorded_sources():
    """The 40 recorded rollout starts with their source hole centres (CPU only)."""
    from tavla_rl.ppo_v4.data import normalize_record, records
    return [normalize_record(row) for row in records()]


class HandoverDistribution:
    """Empirical samples measured at the deployable chamfer trigger of pure-VLA rollouts."""

    def __init__(self, value):
        if value.get('format') != DISTRIBUTION_FORMAT:
            raise ValueError('Not a V5 hand-over distribution; run tools.fit_handover first')
        self.value = value
        self.xy = np.asarray(value['xy_offset_m'], float)
        self.tilt = np.asarray(value['hand_tilt_rotvec'], float).reshape(-1, 2)
        self.speed = np.asarray(value['approach_speed_m_s'], float)
        self.slip = np.asarray(value['in_hand_slip_deg'], float)
        self.in_hand_offset = np.asarray(value['in_hand_offset_m'], float).reshape(-1, 3)
        self.postures = [(np.asarray(p['q'], float), np.asarray(p['hole_m'], float)) for p in value.get('postures', [])]
        for name, data in (('xy_offset_m', self.xy), ('hand_tilt_rotvec', self.tilt),
                           ('approach_speed_m_s', self.speed)):
            if len(data) < 5 or not np.isfinite(data).all():
                raise ValueError(f'Hand-over distribution needs at least five finite {name} samples')
        if not len(self.slip):
            self.slip = np.zeros(1)
        if not len(self.in_hand_offset):
            self.in_hand_offset = np.zeros((1, 3))

    @classmethod
    def load(cls, path):
        return cls(json.loads(Path(path).read_text()))

    def nearest_posture(self, hole):
        if not self.postures:
            return None
        distances = [np.linalg.norm(h[:2]-hole[:2]) for _, h in self.postures]
        return self.postures[int(np.argmin(distances))][0].copy()

    def summary(self):
        q = lambda v, p: float(np.percentile(v, p))
        return dict(samples=len(self.xy), xy_p50_mm=q(self.xy, 50)*1e3, xy_p90_mm=q(self.xy, 90)*1e3,
                    tilt_p50_deg=q(np.degrees(np.linalg.norm(self.tilt, axis=1)), 50),
                    speed_p50_mm_s=q(self.speed, 50)*1e3, postures=len(self.postures))


def _lerp(easy, train, level):
    return easy+float(level)*(train-easy)


def _clip_norm(vector, limit):
    norm = float(np.linalg.norm(vector))
    return vector if norm <= limit or norm == 0 else vector*limit/norm


def sample_start(rng, distribution, settings, sources, *, level, mode):
    """mode: 'train' (curriculum mixture), 'eval' (fitted, clean) or 'noisy' (fitted, real-like)."""
    if mode not in ('train', 'eval', 'noisy'):
        raise ValueError('Unknown start mode')
    s = settings
    level = float(np.clip(level, 0., 1.)) if mode == 'train' else 1.
    source = sources[int(rng.integers(len(sources)))]
    hole = np.asarray(source['hole_position_m'], float).copy()
    hole[:2] += rng.uniform(-s.hole_xy_half_range_m, s.hole_xy_half_range_m, 2)
    xy_max = _lerp(s.easy_xy_m, s.train_xy_m, level)
    tilt_max = math.radians(_lerp(s.easy_tilt_deg, s.train_tilt_deg, level))
    slip_max = _lerp(s.easy_slip_deg, s.train_slip_deg, level)
    offset_max = _lerp(s.easy_in_hand_offset_m, s.train_in_hand_offset_m, level)
    empirical = mode != 'train' or rng.random() < s.empirical_fraction
    d = distribution
    if empirical:
        xy = float(d.xy[rng.integers(len(d.xy))])
        tilt = d.tilt[rng.integers(len(d.tilt))].copy()
        slip = float(d.slip[rng.integers(len(d.slip))])
        in_hand = d.in_hand_offset[rng.integers(len(d.in_hand_offset))].copy()
        speed = float(np.clip(d.speed[rng.integers(len(d.speed))], *s.descent_speed_range_m_s))
        if mode == 'train':
            xy, tilt = min(xy, xy_max), _clip_norm(tilt, tilt_max)
            slip, in_hand = float(np.clip(slip, -slip_max, slip_max)), np.clip(in_hand, -offset_max, offset_max)
    else:
        xy = xy_max*math.sqrt(rng.random())
        angle = rng.uniform(-math.pi, math.pi)
        tilt = tilt_max*math.sqrt(rng.random())*np.array([math.cos(angle), math.sin(angle)])
        slip = rng.uniform(-slip_max, slip_max)
        in_hand = rng.uniform(-offset_max, offset_max, 3)
        speed = rng.uniform(*s.descent_speed_range_m_s)
    in_hand[1] = 0.  # The two fingers centre the peg along the closing axis.
    direction = rng.uniform(-math.pi, math.pi)
    extra_direction = rng.uniform(-math.pi, math.pi)
    extra = rng.uniform(*s.approach_extra_xy_range_m)
    low, high = s.friction_range
    if mode == 'train':
        friction = rng.uniform(_lerp(s.eval_friction, low, level), _lerp(s.eval_friction, high, level), 3)
        gain = rng.uniform(_lerp(1., s.gain_scale_range[0], level), _lerp(1., s.gain_scale_range[1], level))
        noise_scale = rng.uniform(0., level*s.noise_scale_range[1])
        latency = bool(rng.random() < level*s.force_latency_probability)
        rim_error = rng.uniform(-1., 1.)*level*s.rim_calibration_error_m
    else:
        friction = np.full(3, s.eval_friction)
        gain = 1.
        noisy = mode == 'noisy'
        noise_scale = 1. if noisy else 0.
        latency = bool(noisy and rng.random() < s.force_latency_probability)
        rim_error = rng.uniform(-1., 1.)*s.rim_calibration_error_m if noisy else 0.
    seed_q = d.nearest_posture(hole)
    return dict(kind='synthetic', mode=mode, level=level, profile=int(source['profile']),
                hole_position_m=hole.tolist(),
                seed_q=(seed_q if seed_q is not None else np.asarray(source['joint_pos_rad'], float)).tolist(),
                xy_offset_m=[xy*math.cos(direction), xy*math.sin(direction)],
                extra_xy_m=[extra*math.cos(extra_direction), extra*math.sin(extra_direction)],
                hover_height_m=float(rng.uniform(*s.hover_height_range_m)), descent_speed_m_s=float(speed),
                hand_tilt_rotvec=[float(v) for v in tilt], in_hand_slip_deg=float(slip),
                in_hand_offset_m=[float(v) for v in in_hand], friction=[float(v) for v in friction],
                gain_scale=float(gain), noise_scale=float(noise_scale), latency=latency,
                rim_error_m=float(rim_error), trigger='chamfer', noise_seed=int(rng.integers(0, 2**31)))


class Curriculum:
    def __init__(self, settings, level=0.):
        self.cfg = settings
        self.level = float(level)
        self.window = deque(maxlen=settings.curriculum_window)
        self.history = []

    def record(self, success):
        self.window.append(bool(success))
        if (len(self.window) == self.window.maxlen and self.level < 1. and
                float(np.mean(self.window)) >= self.cfg.curriculum_threshold):
            self.level = min(1., self.level+self.cfg.curriculum_step)
            self.history.append(dict(level=self.level, window_success=float(np.mean(self.window))))
            self.window.clear()

    def state_dict(self):
        return dict(level=self.level, window=list(self.window), history=list(self.history))

    def load_state_dict(self, value):
        self.level = float(value['level'])
        self.window = deque(value['window'], maxlen=self.cfg.curriculum_window)
        self.history = list(value['history'])


class StartSampler:
    """Infinite training stream; its RNG never touches validation or test starts."""

    def __init__(self, seed, distribution, settings, sources=None, curriculum=None):
        self.rng = np.random.default_rng(np.random.SeedSequence([int(seed), 20261021]))
        self.distribution, self.cfg = distribution, settings
        self.sources = sources if sources is not None else recorded_sources()
        self.curriculum = curriculum or Curriculum(settings)
        self.counter = 0
        self.split = 'train'

    def next(self, env_id=None):
        start = sample_start(self.rng, self.distribution, self.cfg, self.sources,
                             level=self.curriculum.level, mode='train')
        start['start_id'] = self.counter
        self.counter += 1
        return start

    def record(self, row):
        if row.get('kind') == 'synthetic' and row.get('mode') == 'train' and not row.get('discarded'):
            self.curriculum.record(row['success'])

    def state_dict(self):
        return dict(rng=self.rng.bit_generator.state, counter=self.counter, curriculum=self.curriculum.state_dict())

    def load_state_dict(self, value):
        self.rng.bit_generator.state = value['rng']
        self.counter = int(value['counter'])
        self.curriculum.load_state_dict(value['curriculum'])


class FixedStarts:
    """A finite, ordered validation set; environments go idle once it is exhausted."""

    def __init__(self, starts, repeats=1, split='validation'):
        self.items = [dict(copy.deepcopy(start), repeat=r, item_id=len(starts)*r+i)
                      for r in range(int(repeats)) for i, start in enumerate(starts)]
        self.counter = 0
        self.split = split

    def __len__(self):
        return len(self.items)

    def next(self, env_id=None):
        if self.counter >= len(self.items):
            return None
        value = copy.deepcopy(self.items[self.counter])
        self.counter += 1
        return value

    def record(self, row):
        pass


def synthetic_validation(distribution, settings, sources=None, *, noisy=False):
    sources = sources if sources is not None else recorded_sources()
    seed = settings.noisy_validation_seed if noisy else settings.synthetic_validation_seed
    rng = np.random.default_rng(np.random.SeedSequence([int(seed), 77]))
    return [dict(sample_start(rng, distribution, settings, sources, level=1., mode='noisy' if noisy else 'eval'),
                 start_id=i) for i in range(settings.synthetic_validation_count)]


def load_recorded_states(root, settings):
    """Hand-over snapshots captured by the end-to-end runner on validation cases only."""
    states = []
    for path in sorted(Path(root).rglob(STATE_FILE)):
        with np.load(path, allow_pickle=False) as data:
            meta = json.loads(str(data['meta']))
            arrays = {k: data[k].copy() for k in data.files if k != 'meta'}
        if meta.get('format') != STATE_FORMAT:
            raise ValueError(f'Unknown hand-over state format: {path}')
        if meta.get('split') == 'test':
            raise ValueError(f'Test-set hand-over states must never enter skill validation: {path}')
        states.append(dict(kind='recorded', mode='recorded', source=str(path), meta=meta, start_id=len(states),
                           friction=[settings.eval_friction]*3, gain_scale=1., noise_scale=0., latency=False,
                           rim_error_m=0., noise_seed=len(states), **arrays))
    return states
