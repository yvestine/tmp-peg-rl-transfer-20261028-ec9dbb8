"""Parallel force-tactile insertion skill environment: no cameras, no VLA.

Every episode reproduces a VLA hand-over: the peg hovers above the hole, the force is tared,
a short VLA-like descent (with lateral convergence) runs until the SAME deployable chamfer
trigger used end to end fires, and only then the skill owns the arm. It keeps it until
success, timeout, lift-out, a physical guard, or (simulator-only) excessive in-hand slip.
Recorded VLA hand-over snapshots can be restored instead of a synthetic approach.

Import only after AppLauncher. No reset advances the physics of other environments.
"""
import math
import time
import numpy as np
import torch
from tacex_tasks.real2sim.realsim_env import RealSimEnv
from tacex_tasks.real2sim.forge_env import ForgeEnv
from tacex_tasks.real2sim.tavla_residual_env import _configure_pi0_rollout_scene
from tacex_tasks.real2sim.sim_data_visual import (load_sim_data_profile, configure_sim_data_visual_scene,
                                                apply_visual_domain_randomization)
from tacex_tasks.real2sim.policy.force_contact_capture import incoming_joint_frame
from tavla_rl.ppo_v4.encoder import BatchedEncoder
from . import observation as contract
from .controller import JointSlew, PoseIntegrator, load_fk, solve_pose
from .geometry import (axis_rotation, from_base, in_hand_pose, leveling_rotation, matrix_quat,
                       peg_pose_from_fingertip, quat_matrix, rotation_angle_deg, rotation_exp, rotation_log,
                       tip_from_tcp, to_base, tool_axis, vertical_tilt_deg)
from .noise import BatchedForceNoise
from .reward import reward
from .settings import ROOT, atomic_json
from .trigger import HandoverMachine

GUARDS = {1: 'slew_infeasible', 2: 'joint_limits', 3: 'joint_velocity', 4: 'force_100N', 5: 'tilt_45deg'}


def tensor(value, device):
    value = value.torch if hasattr(value, 'torch') and not isinstance(value, torch.Tensor) else value
    return torch.as_tensor(value, device=device, dtype=torch.float32)


def build_config(args, settings):
    """V4's scene construction (same assets, servo, slew, 120 Hz / 10 Hz) with every camera removed."""
    from tavla_rl.env_cfg import TavlaRLCfg
    cfg = TavlaRLCfg()
    visual = load_sim_data_profile(ROOT/'sim-data-aligned', 0)
    configure_sim_data_visual_scene(cfg)
    cfg.replay_left_background_visual_shell = False
    apply_visual_domain_randomization(cfg, visual.domain_randomization)
    _configure_pi0_rollout_scene(cfg)
    cfg.enable_cameras = False
    cfg.tiled_camera = None
    cfg.wrist_camera = None
    cfg.scene.num_envs = args.num_envs
    cfg.scene.env_spacing = 3.
    cfg.scene.replicate_physics = True
    cfg.sim.device = args.device
    cfg.seed = 42
    cfg.sim.dt = 1/120
    cfg.decimation = 12
    cfg.sim.render_interval = 12
    cfg.policy_cfg = None
    cfg.action_space = 8
    cfg.episode_length_s = settings.skill_seconds+settings.descent_timeout_s+10.
    cfg.is_finite_horizon = True
    cfg.data_collect_cfg['collect_data'] = False
    cfg.teacher_control_mode = 'aligned_joint'
    cfg.use_implicit_position_servo = False
    cfg.ft_parent_body_name = 'panda_link7'
    cfg.ft_raw_wrench_frame = 'parent_body'
    cfg.ft_raw_torque_reference = 'parent_origin'
    cfg.ft_apply_child_joint_frame_calibration = True
    cfg.task.skip_reset_ik = True
    cfg.task.use_pi0_reset_pose = True
    cfg.task.fixed_asset_init_pos_noise = [0.]*3
    cfg.task.hand_init_pos_noise = [0.]*3
    cfg.task.held_asset_pos_noise = [0.]*3
    cfg.task.success_xy_threshold = settings.success_xy_m
    cfg.task.success_z_threshold = settings.success_z_m
    cfg.events.object_scale_mass = None
    for name in ('held_physics_material', 'fixed_physics_material', 'robot_physics_material'):
        getattr(cfg.events, name).params.update(static_friction_range=(settings.eval_friction,)*2,
                                                dynamic_friction_range=(settings.eval_friction,)*2, num_buckets=1)
    cfg.ctrl.task_prop_gains_noise_level = [0.]*6
    cfg.ctrl.pos_threshold_noise_level = [0.]*3
    cfg.ctrl.rot_threshold_noise_level = [0.]*3
    cfg.ctrl.ema_factor_range = [1., 1.]
    cfg.obs_rand.ft_wrench_noise_std = [0.]*6
    return cfg


class VectorSkillEnv(RealSimEnv):
    CLOSE, SETTLE, TARE, DESCEND, SKILL, IDLE = range(6)

    def __init__(self, args, settings, sampler, noise_model):
        self.settings, self.sampler, self.args = settings, sampler, args
        self.output = args.output
        self._v5_ready = False
        cfg = build_config(args, settings)
        # Forge builds the same Factory articulation/dynamics buffers; RealSimEnv.__init__ would
        # create a remote policy and its own reset loop (as in V4, it is bypassed).
        ForgeEnv.__init__(self, cfg)
        n, d, s = self.num_envs, self.device, settings
        self.fk = load_fk(d)
        self.encoder = BatchedEncoder(n, d)
        self.integrator = PoseIntegrator(n, s, d)
        self.machine = HandoverMachine(n, s, d)
        self.noise = BatchedForceNoise(n, noise_model, d, seed=args.seed)
        self.slew = JointSlew(s)
        self.fields, self.critic_fields = contract.actor_fields(s), contract.critic_fields(s)
        self.actor_dim, self.critic_dim = contract.dim(self.fields), contract.dim(self.critic_fields)
        zeros = lambda *shape: torch.zeros(*shape, device=d)
        self.phase = torch.full((n,), self.IDLE, dtype=torch.long, device=d)
        self.phase_tick = torch.zeros(n, dtype=torch.long, device=d)
        self.steps = torch.zeros_like(self.phase_tick)
        self.episode_id = torch.zeros_like(self.phase_tick)
        self.guard = torch.zeros_like(self.phase_tick)
        self.contact_ticks = torch.zeros_like(self.phase_tick)
        self.returns = zeros(n)
        self.command, self.velocity = zeros(n, 7), zeros(n, 7)
        self.place_q, self.target_q = zeros(n, 7), zeros(n, 7)
        self.handover_q, self.handover_tcp, self.handover_tip = zeros(n, 7), zeros(n, 3), zeros(n, 3)
        self.warm_q = zeros(n, self._robot.num_joints)
        self.descent_time, self.descent_speed, self.hover = zeros(n), zeros(n), zeros(n)
        self.extra_xy = zeros(n, 2)
        self.history = zeros(n, s.force_history_steps, 3)
        self.previous_action = zeros(n, 5)
        self.in_hand_offset = zeros(n, 3)
        self.in_hand_rotation = torch.eye(3, device=d).repeat(n, 1, 1)
        self.in_hand_reference = torch.eye(3, device=d).repeat(n, 1, 1)
        self.rim_base_z, self.rim_error = zeros(n), zeros(n)
        self.friction = torch.full((n, 3), s.eval_friction, device=d)
        self.gain_scale, self.noise_scale = torch.ones(n, device=d), zeros(n)
        self.contact_trigger = torch.zeros(n, dtype=torch.bool, device=d)
        self.max_lateral, self.max_force, self.max_tilt, self.max_slip = zeros(n), zeros(n), zeros(n), zeros(n)
        self.step_lateral, self.step_peak = zeros(n), zeros(n)
        self.height_bias = zeros(n)
        self.starts = [None]*n
        self.rows, self.discarded = [], []
        self.timing, self.global_ticks, self.skill_samples = {}, 0, 0
        self.elapsed_start = time.monotonic()
        limits = tensor(self._robot.data.soft_joint_pos_limits, d)
        self.lower, self.upper = limits[:, :7, 0], limits[:, :7, 1]
        self.link7 = self._robot.body_names.index('panda_link7')
        rotation, meta = incoming_joint_frame(self.sim.stage, self._robot.root_physx_view.link_paths[0][self.link7])
        self.joint_rotation = torch.as_tensor(rotation, device=d, dtype=torch.float32)
        self.joint_offset = torch.as_tensor(meta['child_local_position_m'], device=d, dtype=torch.float32)
        self.mount = float(s.peg_mount_offset_m+float(self.cfg.pi0_peg_mount_depth_adjust_m))
        self.base_kp = torch.as_tensor(self.cfg.joint_target_kp, device=d, dtype=torch.float32)
        self.base_kd = torch.as_tensor(self.cfg.joint_target_kd, device=d, dtype=torch.float32)
        self._write_gains()
        import warp as wp
        self._materials = [wp.to_torch(asset.root_view.get_material_properties()).clone()
                           for asset in (self._held_asset, self._fixed_asset, self._robot)]
        self.scene.write_data_to_sim()
        self.sim.forward()
        self.scene.update(dt=0.)
        self._compute_intermediate_values(self.physics_dt)
        self.base_pos = tensor(self._robot.data.root_pos_w, d)-self.scene.env_origins
        self.base_rot = quat_matrix(tensor(self._robot.data.root_quat_w, d))
        self._v5_ready = True
        self.reset()
        self.contract = dict(version=5, settings=s.contract, observation=contract.contract(s),
            physics='original assets, 120 Hz physics, 10 Hz control, implicit 200/40 joint servo, proportional slew; '
                    'no cameras', peg_mount_m=self.mount, noise_model=noise_model.source,
            starts='synthetic VLA-like approach or restored VLA hand-over snapshot; same chamfer trigger')
        atomic_json(self.output/'environment_contract.json', self.contract)

    # ------------------------------------------------------------------ Isaac hooks
    def _set_default_dynamics_parameters(self):
        super()._set_default_dynamics_parameters()
        import warp as wp
        # Factory's final overwrite sets only dynamic friction; set both (as V4).
        for asset in (self._robot, self._fixed_asset, self._held_asset):
            props = wp.to_torch(asset.root_view.get_material_properties()).clone()
            props[..., :2] = self.settings.eval_friction if hasattr(self, 'settings') else .75
            indices = torch.arange(self.num_envs, dtype=torch.int32, device='cpu')
            asset.root_view.set_material_properties(wp.from_torch(props.contiguous()), wp.from_torch(indices))

    def _compute_intermediate_values(self, dt):
        d = self.device
        self.joint_pos = tensor(self._robot.data.joint_pos, d)
        self.joint_vel = tensor(self._robot.data.joint_vel, d)
        self.fingertip_midpoint_pos = tensor(self._robot.data.body_pos_w, d)[:, self.fingertip_body_idx]-self.scene.env_origins
        self.fingertip_midpoint_quat = tensor(self._robot.data.body_quat_w, d)[:, self.fingertip_body_idx]
        self.held_pos = tensor(self._held_asset.data.root_pos_w, d)-self.scene.env_origins
        self.held_quat = tensor(self._held_asset.data.root_quat_w, d)
        self.fixed_pos = tensor(self._fixed_asset.data.root_pos_w, d)-self.scene.env_origins
        self.fixed_quat = tensor(self._fixed_asset.data.root_quat_w, d)

    def _reset_idx(self, ids):
        if getattr(self, '_v5_ready', False):
            self.reset_ids(ids)

    def reset(self, *, seed=None, options=None):
        self.reset_ids(torch.arange(self.num_envs, device=self.device))
        return self.observe(), {}

    # ------------------------------------------------------------------ randomization
    def _write_gains(self):
        stiffness = tensor(self._robot.data.joint_stiffness, self.device).clone()
        damping = tensor(self._robot.data.joint_damping, self.device).clone()
        stiffness[:, :7] = self.base_kp*self.gain_scale[:, None]
        damping[:, :7] = self.base_kd*torch.sqrt(self.gain_scale)[:, None]
        self._robot.write_joint_stiffness_to_sim(stiffness)
        self._robot.write_joint_damping_to_sim(damping)

    def _write_friction(self, ids):
        import warp as wp
        rows = ids.to('cpu', torch.long)
        values = self.friction[ids].cpu()
        for column, asset in enumerate((self._held_asset, self._fixed_asset, self._robot)):
            props = self._materials[column]
            props[rows, :, 0] = values[:, column, None]
            props[rows, :, 1] = values[:, column, None]
            asset.root_view.set_material_properties(wp.from_torch(props.contiguous()),
                                                    wp.from_torch(rows.to(torch.int32)))

    # ------------------------------------------------------------------ resets
    def reset_ids(self, ids, attempt=0):
        ids = torch.as_tensor(ids, device=self.device, dtype=torch.long).flatten()
        synthetic, recorded = [], []
        for i in ids.cpu().tolist():
            start = self.sampler.next(env_id=i)
            self.starts[i] = start
            self.phase[i] = self.IDLE
            if start is None:
                continue
            (recorded if start['kind'] == 'recorded' else synthetic).append(i)
        active = synthetic+recorded
        if not active:
            return
        rows = torch.tensor(active, device=self.device)
        self.episode_id[rows] += 1
        for value in (self.guard, self.steps, self.phase_tick, self.contact_ticks):
            value[rows] = 0
        for value in (self.returns, self.max_lateral, self.max_force, self.max_tilt, self.max_slip,
                      self.descent_time, self.height_bias):
            value[rows] = 0.
        self.history[rows] = 0.
        self.previous_action[rows] = 0.
        self.encoder.reset(rows)
        self.integrator.reset(rows)
        self.machine.reset(rows)
        starts = [self.starts[i] for i in active]
        self.friction[rows] = torch.as_tensor([st['friction'] for st in starts], device=self.device, dtype=torch.float32)
        self.gain_scale[rows] = torch.as_tensor([st['gain_scale'] for st in starts], device=self.device)
        noise = [st['noise_scale'] if st['kind'] == 'synthetic' or st.get('repeat', 0) == 0 else max(st['noise_scale'], .5)
                 for st in starts]
        self.noise_scale[rows] = torch.as_tensor(noise, device=self.device)
        self.noise.reset(rows, self.noise_scale[rows], [st['latency'] for st in starts])
        self.rim_error[rows] = torch.as_tensor([st['rim_error_m'] for st in starts], device=self.device)
        self.contact_trigger[rows] = torch.as_tensor([st.get('trigger') == 'contact' for st in starts], device=self.device)
        self._write_friction(rows)
        self._write_gains()
        failed = []
        if synthetic:
            failed = self._install_synthetic(synthetic)
        if recorded:
            self._install_recorded(recorded)
        if failed:
            for i in failed:
                self.discarded.append(dict(start=_brief(self.starts[i]), reason='place_ik_failed'))
            if attempt >= 8:
                raise RuntimeError('Placement IK keeps failing; inspect the hand-over distribution postures')
            self.reset_ids(failed, attempt+1)

    def _install_synthetic(self, ids):
        d, s = self.device, self.settings
        rows = torch.tensor(ids, device=d)
        starts = [self.starts[i] for i in ids]
        f32 = lambda key: torch.as_tensor([st[key] for st in starts], device=d, dtype=torch.float32)
        hole = f32('hole_position_m')
        pose = tensor(self._fixed_asset.data.default_root_pose, d)[rows].clone()
        pose[:, :3] = hole+self.scene.env_origins[rows]
        self._fixed_asset.write_root_pose_to_sim(pose, env_ids=rows)
        self._fixed_asset.write_root_velocity_to_sim(torch.zeros(len(ids), 6, device=d), env_ids=rows)
        seed = f32('seed_q')
        _, seed_rotation = self.fk(seed)
        level = leveling_rotation(tool_axis(seed_rotation))@seed_rotation
        tilt = f32('hand_tilt_rotvec')
        goal_rotation = rotation_exp(torch.cat((tilt, torch.zeros_like(tilt[:, :1])), -1))@level
        hole_base = to_base(hole, self.base_pos[rows], self.base_rot[rows])
        tip_goal = hole_base.clone()
        tip_goal[:, :2] += f32('xy_offset_m')+f32('extra_xy_m')
        tip_goal[:, 2] += s.rim_height_m+f32('hover_height_m')
        tcp_goal = tip_goal-tool_axis(goal_rotation)*self.mount
        q, accepted = solve_pose(self.fk, seed, tcp_goal, goal_rotation, self.lower[rows], self.upper[rows])
        self.rim_base_z[rows] = hole_base[:, 2]+s.rim_height_m
        self.descent_speed[rows] = f32('descent_speed_m_s')
        self.hover[rows] = f32('hover_height_m')
        self.extra_xy[rows] = f32('extra_xy_m')
        self.in_hand_offset[rows] = f32('in_hand_offset_m')
        self.in_hand_rotation[rows] = axis_rotation('y', torch.deg2rad(f32('in_hand_slip_deg')))
        warm = tensor(self._robot.data.default_joint_pos, d)[rows].clone()
        warm[:, :7] = q
        warm[:, 7:9] = .04
        self.warm_q[rows] = warm
        self.place_q[rows] = q
        self.command[rows] = q
        self.target_q[rows] = q
        self.velocity[rows] = 0.
        self._robot.write_joint_state_to_sim(warm, torch.zeros_like(warm), env_ids=rows)
        self.phase[rows] = self.CLOSE
        self.scene.write_data_to_sim()
        self.sim.forward()
        self.scene.update(dt=0.)
        self._compute_intermediate_values(self.physics_dt)
        self._snap_peg(rows)
        failed = [i for i, ok in zip(ids, accepted.cpu().tolist()) if not ok]
        if failed:
            self.phase[torch.tensor(failed, device=d)] = self.IDLE
        return failed

    def _install_recorded(self, ids):
        """Restore a VLA hand-over snapshot (stored in the robot base frame) and start the skill."""
        d = self.device
        rows = torch.tensor(ids, device=d)
        starts = [self.starts[i] for i in ids]
        f32 = lambda key: torch.as_tensor(np.stack([np.asarray(st[key], np.float32) for st in starts]), device=d)
        base_pos, base_rot = self.base_pos[rows], self.base_rot[rows]
        fixed_w = from_base(f32('fixed_pos_b'), base_pos, base_rot)
        fixed_r = base_rot@quat_matrix(f32('fixed_quat_b'))
        held_w = from_base(f32('held_pos_b'), base_pos, base_rot)
        held_r = base_rot@quat_matrix(f32('held_quat_b'))
        origins = self.scene.env_origins[rows]
        self._fixed_asset.write_root_pose_to_sim(torch.cat((fixed_w+origins, matrix_quat(fixed_r)), -1), env_ids=rows)
        self._fixed_asset.write_root_velocity_to_sim(torch.zeros(len(ids), 6, device=d), env_ids=rows)
        velocity = torch.cat(((base_rot@f32('held_lin_vel_b')[..., None]).squeeze(-1),
                              (base_rot@f32('held_ang_vel_b')[..., None]).squeeze(-1)), -1)
        self._held_asset.write_root_pose_to_sim(torch.cat((held_w+origins, matrix_quat(held_r)), -1), env_ids=rows)
        self._held_asset.write_root_velocity_to_sim(velocity, env_ids=rows)
        q, qd = f32('q'), f32('qd')
        self._robot.write_joint_state_to_sim(q, qd, env_ids=rows)
        self.warm_q[rows] = q
        self.command[rows] = f32('command')
        self.velocity[rows] = f32('command_velocity')
        self.target_q[rows] = self.command[rows]
        self.place_q[rows] = self.command[rows]
        hole_base = f32('fixed_pos_b')
        self.rim_base_z[rows] = hole_base[:, 2]+self.settings.rim_height_m
        self.scene.write_data_to_sim()
        self.sim.forward()
        self.scene.update(dt=0.)
        self._compute_intermediate_values(self.physics_dt)
        self._replay_encoder(rows, [np.asarray(st['forces'], np.float32) for st in starts])
        offset, relative = in_hand_pose(self.fingertip_midpoint_pos[rows], quat_matrix(self.fingertip_midpoint_quat[rows]),
                                        self.held_pos[rows], quat_matrix(self.held_quat[rows]), self.mount)
        self.in_hand_offset[rows] = offset
        self.in_hand_rotation[rows] = relative
        self._begin_skill(rows)

    def _replay_encoder(self, rows, forces):
        """Feed the recorded 10 Hz force stream through the batched encoder; rebuild the history."""
        n, d = self.num_envs, self.device
        length = max(len(f) for f in forces)
        for k in range(length):
            sample = torch.zeros(n, 3, device=d)
            valid = torch.zeros(n, dtype=torch.bool, device=d)
            for row, force in zip(rows.cpu().tolist(), forces):
                if k < len(force):
                    sample[row] = torch.as_tensor(force[k], device=d)
                    valid[row] = True
            self.encoder.update(sample, valid)
            tared = sample-self.encoder.baseline
            ready = valid & self.encoder.ready
            self.history = torch.where(ready[:, None, None], torch.cat((self.history[:, 1:], tared[:, None]), 1),
                                       self.history)
        if not bool(self.encoder.ready[rows].all()):
            raise ValueError('A recorded hand-over has fewer than 20 force samples')

    def _snap_peg(self, rows):
        position, rotation = peg_pose_from_fingertip(self.fingertip_midpoint_pos[rows],
            quat_matrix(self.fingertip_midpoint_quat[rows]), self.mount, self.in_hand_offset[rows],
            self.in_hand_rotation[rows])
        self._held_asset.write_root_pose_to_sim(torch.cat((position+self.scene.env_origins[rows], matrix_quat(rotation)), -1),
                                                env_ids=rows)
        self._held_asset.write_root_velocity_to_sim(torch.zeros(len(rows), 6, device=self.device), env_ids=rows)

    def _begin_skill(self, rows):
        if len(rows) == 0:
            return
        p_hand, _ = self.fk(self.command[rows])
        p_meas, r_meas = self.fk(self.joint_pos[rows, :7])
        self.handover_q[rows] = self.command[rows]
        self.handover_tcp[rows] = p_hand
        self.handover_tip[rows] = tip_from_tcp(p_meas, r_meas, self.mount)
        self.target_q[rows] = self.command[rows]
        self.integrator.reset(rows)
        mask = torch.zeros(self.num_envs, dtype=torch.bool, device=self.device)
        mask[rows] = True
        self.machine.start(mask)
        self.steps[rows] = 0
        self.previous_action[rows] = 0.
        _, relative = in_hand_pose(self.fingertip_midpoint_pos[rows], quat_matrix(self.fingertip_midpoint_quat[rows]),
                                   self.held_pos[rows], quat_matrix(self.held_quat[rows]), self.mount)
        self.in_hand_reference[rows] = relative
        height = self._height()[rows]
        _, z_true = self._truth()
        self.height_bias[rows] = height+self.settings.rim_height_m-z_true[rows]
        self.phase[rows] = self.SKILL
        self.phase_tick[rows] = 0

    # ------------------------------------------------------------------ measurements
    def _wrench(self):
        raw = tensor(self._robot.root_physx_view.get_link_incoming_joint_force(), self.device)[:, self.link7]
        link = quat_matrix(tensor(self._robot.data.body_quat_w, self.device)[:, self.link7])
        rb = quat_matrix(tensor(self._robot.data.root_quat_w, self.device))
        r = rb.transpose(1, 2)@link@self.joint_rotation
        force = -(r@raw[:, :3, None]).squeeze(-1)
        link_pos = tensor(self._robot.data.body_pos_w, self.device)[:, self.link7]
        k = self.fingertip_midpoint_pos+self.scene.env_origins
        arm = (rb.transpose(1, 2)@(link_pos+(link@self.joint_offset[:, None]).squeeze(-1)-k)[:, :, None]).squeeze(-1)
        torque = -(r@raw[:, 3:, None]).squeeze(-1)+torch.linalg.cross(arm, force, dim=-1)
        return torch.cat((force, torque), -1)

    def _kinematics(self):
        p, r = self.fk(self.joint_pos[:, :7])
        return p, r, tip_from_tcp(p, r, self.mount)

    def _height(self, tip=None):
        if tip is None:
            tip = self._kinematics()[2]
        return tip[:, 2]-(self.rim_base_z+self.rim_error)+self.settings.tip_height_correction_m

    def _truth(self):
        delta = self.held_pos-self.fixed_pos
        return torch.linalg.vector_norm(delta[:, :2], dim=-1), delta[:, 2]

    def _approach_offset(self):
        s, t = self.settings, self.descent_time
        z = torch.maximum(-self.descent_speed*t, -(self.hover+.006))
        converge = 1.-torch.exp(-t/s.approach_time_constant_s)
        offset = torch.zeros(self.num_envs, 5, device=self.device)
        offset[:, :2] = -self.extra_xy*converge[:, None]
        offset[:, 2] = z
        return offset

    def _time(self, stage, started):
        self.timing[stage] = self.timing.get(stage, 0.)+time.monotonic()-started

    # ------------------------------------------------------------------ observation
    def observe(self):
        s, n = self.settings, self.num_envs
        valid = self.phase == self.SKILL
        p, r, tip = self._kinematics()
        height = self._height(tip)
        values = dict(q=self.joint_pos[:, :7], qd=self.joint_vel[:, :7],
                      gripper=(self.joint_pos[:, 7:9].sum(-1, keepdim=True)/.08).clamp(0., 1.),
                      command=self.command, command_velocity=self.velocity, offset=self.integrator.offset,
                      tip_displacement=tip-self.handover_tip, height=height[:, None],
                      gap=self.integrator.commanded_tcp(self.handover_tcp)-p, tilt=tool_axis(r)[:, :2],
                      force_history=self.history.reshape(n, -1), latent=self.encoder.latents[:, -1],
                      previous_action=self.previous_action, elapsed=(self.steps.float()*s.dt)[:, None])
        actor = contract.build(values, self.fields, s)*valid[:, None]
        offset, relative = in_hand_pose(self.fingertip_midpoint_pos, quat_matrix(self.fingertip_midpoint_quat),
                                        self.held_pos, quat_matrix(self.held_quat), self.mount)
        wrench = self._wrench()
        xy, z = self._truth()
        values.update(peg_rel_hole=self.held_pos-self.fixed_pos, peg_quat=self.held_quat, in_hand_offset=offset,
                      in_hand_rotvec=rotation_log(relative), clean_force=wrench[:, :3], clean_torque=wrench[:, 3:],
                      friction=self.friction, gain_scale=self.gain_scale[:, None], noise_scale=self.noise_scale[:, None],
                      xy_true=xy[:, None], z_true=z[:, None],
                      peg_tilt=vertical_tilt_deg(quat_matrix(self.held_quat))[:, None])
        critic = contract.build(values, self.critic_fields, s)*valid[:, None]
        return dict(actor=actor, critic=critic, valid=valid)

    # ------------------------------------------------------------------ step
    def step(self, action):
        s, n, d = self.settings, self.num_envs, self.device
        valid = self.phase == self.SKILL
        descending = self.phase == self.DESCEND
        moving = valid | descending
        action = torch.where(valid[:, None], action.to(d, torch.float32).clamp(-1., 1.), torch.zeros(n, 5, device=d))
        before = self._truth()
        started = time.monotonic()
        p_meas, _ = self.fk(self.joint_pos[:, :7])
        proposed = self.integrator.propose(action, valid, self.handover_tcp, p_meas)
        skill_q, skill_ok = self.fk.ik(self.handover_q, proposed, self.lower, self.upper)
        skill_target = torch.where(skill_ok[:, None], skill_q, self.target_q)
        approach_q, approach_ok = self.fk.ik(self.place_q, self._approach_offset()*descending[:, None],
                                             self.lower, self.upper)
        target = torch.where(valid[:, None], skill_target,
                             torch.where((descending & approach_ok)[:, None], approach_q, self.command))
        command, velocity, _, feasible = self.slew(self.command, self.velocity, target)
        self.integrator.commit(valid & skill_ok & feasible)
        self.target_q = torch.where((valid & skill_ok)[:, None], skill_q, self.target_q)
        self.guard[moving & ~feasible] = 1
        self.command = torch.where(moving[:, None], command, self.command)
        self.velocity = torch.where(moving[:, None], velocity, torch.zeros_like(velocity))
        self._time('control', started)
        self.step_peak.zero_()
        self.step_lateral.zero_()
        # Only the tare rows are held (V4 WARMUP); their warm_q already contains the closed fingers.
        holding = (self.phase == self.TARE).nonzero().flatten()
        if len(holding):
            self._robot.write_joint_state_to_sim(self.warm_q[holding], torch.zeros_like(self.warm_q[holding]),
                                                 env_ids=holding)
        started = time.monotonic()
        for _ in range(self.cfg.decimation):
            closing = (self.phase == self.CLOSE).nonzero().flatten()
            if len(closing):
                self._snap_peg(closing)
            self.ctrl_target_joint_pos[:, :7] = self.command
            self.ctrl_target_joint_pos[:, 7:9] = 0.
            self._robot.set_joint_position_target(self.ctrl_target_joint_pos)
            self._robot.set_joint_effort_target(torch.zeros_like(self.ctrl_target_joint_pos))
            self.scene.write_data_to_sim()
            self.sim.step(render=False)
            self.scene.update(dt=self.physics_dt)
            self._compute_intermediate_values(self.physics_dt)
            wrench = self._wrench()
            force = torch.linalg.vector_norm(wrench[:, :3], dim=-1)
            self.step_peak = torch.maximum(self.step_peak, force)
            self.step_lateral = torch.maximum(self.step_lateral, torch.linalg.vector_norm(wrench[:, :2], dim=-1))
            q, qd = self.joint_pos[:, :7], self.joint_vel[:, :7]
            if not bool(torch.isfinite(torch.cat((q, qd, self.held_pos, self.fixed_pos, wrench), -1)).all()):
                raise FloatingPointError('Non-finite physical state; infrastructure failure')
            self.guard[moving & ((q < self.lower-.02) | (q > self.upper+.02)).any(-1)] = 2
            self.guard[moving & (qd.abs().amax(-1) > 1.)] = 3
            self.guard[moving & (force > 100.)] = 4
            hand = -quat_matrix(self.fingertip_midpoint_quat)[:, 2, 2]
            peg = quat_matrix(self.held_quat)[:, 2, 2].abs()
            self.guard[moving & ((hand < math.cos(math.pi/4)) | (peg < math.cos(math.pi/4)))] = 5
            bad = moving & (self.guard > 0)
            self.command = torch.where(bad[:, None], q, self.command)
        self._time('physics', started)
        self.global_ticks += 1
        self.phase_tick += 1
        # 10 Hz sensing: noise -> encoder (tare = first 20 samples) -> tared history.
        clean = self._wrench()[:, :3]
        sensing = (self.phase == self.TARE) | descending | valid
        measured = self.noise.apply(clean, sensing)
        self.encoder.update(measured, sensing)
        tared = measured-self.encoder.baseline
        ready = sensing & self.encoder.ready
        self.history = torch.where(ready[:, None, None], torch.cat((self.history[:, 1:], tared[:, None]), 1),
                                   self.history)
        p, r, tip = self._kinematics()
        height = self._height(tip)
        after = self._truth()
        # Skill outcome.
        timeout, liftout = self.machine.observe_skill(height)
        success = valid & (after[0] < s.success_xy_m) & (after[1] < s.success_z_m) & (self.guard == 0)
        _, relative = in_hand_pose(self.fingertip_midpoint_pos, quat_matrix(self.fingertip_midpoint_quat),
                                   self.held_pos, quat_matrix(self.held_quat), self.mount)
        slip_deg = rotation_angle_deg(relative, self.in_hand_reference)
        slip = valid & (slip_deg > s.slip_limit_deg)
        guarded = valid & (self.guard > 0)
        done = valid & (success | timeout | liftout | guarded | slip)
        failed = done & ~success
        peg_tilt = vertical_tilt_deg(quat_matrix(self.held_quat))
        rew, terms = reward(before, after, self.step_lateral, self.step_peak, peg_tilt, action,
                            self.previous_action, success, failed, s)
        rew = rew*valid
        self.returns += rew
        self.max_lateral = torch.where(valid, torch.maximum(self.max_lateral, self.step_lateral), self.max_lateral)
        self.max_force = torch.where(valid, torch.maximum(self.max_force, self.step_peak), self.max_force)
        self.max_tilt = torch.where(valid, torch.maximum(self.max_tilt, peg_tilt), self.max_tilt)
        self.max_slip = torch.where(valid, torch.maximum(self.max_slip, slip_deg), self.max_slip)
        self.previous_action = torch.where(valid[:, None], action, self.previous_action)
        self.steps[valid] += 1
        self.skill_samples += int(valid.sum())
        # Approach: deployable trigger (chamfer depth, or contact force for probes), or abandon.
        self.descent_time = torch.where(descending, self.descent_time+s.dt, self.descent_time)
        chamfer = self.machine.observe_approach(height, descending & ~self.contact_trigger)
        loaded = torch.linalg.vector_norm(tared, dim=-1) >= 1.
        self.contact_ticks = torch.where(descending & self.contact_trigger & loaded, self.contact_ticks+1,
                                         torch.zeros_like(self.contact_ticks))
        fire = (chamfer | (self.contact_ticks >= s.trigger_confirm_steps)) & (self.guard == 0)
        abandon = descending & ((self.descent_time > s.descent_timeout_s) | (self.guard > 0)) & ~fire
        self._advance_startup()
        terminal = self.observe()
        episodes = []
        for i in done.nonzero().flatten().cpu().tolist():
            reason = ('success' if bool(success[i]) else GUARDS.get(int(self.guard[i]), 'guard') if bool(guarded[i])
                      else 'slip' if bool(slip[i]) else 'liftout' if bool(liftout[i]) else 'timeout')
            row = dict(env_id=i, episode_id=int(self.episode_id[i]), success=bool(success[i]), reason=reason,
                       steps=int(self.steps[i]), seconds=int(self.steps[i])*s.dt, return_value=float(self.returns[i]),
                       xy_m=float(after[0][i]), z_m=float(after[1][i]), peak_force_n=float(self.max_force[i]),
                       max_lateral_force_n=float(self.max_lateral[i]), max_peg_tilt_deg=float(self.max_tilt[i]),
                       max_slip_deg=float(self.max_slip[i]), height_bias_mm=float(self.height_bias[i])*1e3,
                       **_brief(self.starts[i]))
            episodes.append(row)
            self.rows.append(row)
            self.sampler.record(row)
        for i in abandon.nonzero().flatten().cpu().tolist():
            self.discarded.append(dict(start=_brief(self.starts[i]), reason=GUARDS.get(int(self.guard[i]), 'descent_timeout'),
                                       descent_s=float(self.descent_time[i])))
        fire_rows = (fire & ~abandon).nonzero().flatten()
        self._begin_skill(fire_rows)
        finished = (done | abandon).nonzero().flatten()
        if len(finished):
            mask = torch.zeros(n, dtype=torch.bool, device=d)
            mask[finished] = True
            self.machine.stop(mask)
            self.reset_ids(finished)
        return self.observe(), rew, done, dict(valid=valid, actor_valid=valid, episodes=episodes, terms=terms,
                                               terminal_observation=terminal)

    def _advance_startup(self):
        closed = (self.phase == self.CLOSE) & (self.phase_tick >= 6)
        if bool(closed.any()):
            rows = closed.nonzero().flatten()
            self._snap_peg(rows)
            self.phase[rows] = self.SETTLE
            self.phase_tick[rows] = 0
        settled = (self.phase == self.SETTLE) & (self.phase_tick >= 2)
        if bool(settled.any()):
            rows = settled.nonzero().flatten()
            self.warm_q[rows] = self.joint_pos[rows]
            self.command[rows] = self.joint_pos[rows, :7]
            self.place_q[rows] = self.joint_pos[rows, :7]
            self.target_q[rows] = self.joint_pos[rows, :7]
            self.velocity[rows] = 0.
            self.encoder.reset(rows)
            self.history[rows] = 0.
            self.phase[rows] = self.TARE
            self.phase_tick[rows] = 0
        tared = (self.phase == self.TARE) & (self.phase_tick >= 20) & self.encoder.ready
        if bool(tared.any()):
            rows = tared.nonzero().flatten()
            self.descent_time[rows] = 0.
            self.phase[rows] = self.DESCEND
            self.phase_tick[rows] = 0

    # ------------------------------------------------------------------ bookkeeping
    def set_sampler(self, sampler):
        """Switch the start stream (training <-> a fixed validation set); aborts every running episode."""
        self.sampler = sampler
        self.machine.stop(torch.ones(self.num_envs, dtype=torch.bool, device=self.device))
        self.reset_ids(torch.arange(self.num_envs, device=self.device))
        return self.observe()

    def idle(self):
        return bool((self.phase == self.IDLE).all())

    def progress(self):
        elapsed = time.monotonic()-self.elapsed_start
        return dict(physical_ticks=self.global_ticks, skill_steps=self.skill_samples, elapsed_seconds=elapsed,
                    skill_steps_per_second=self.skill_samples/max(elapsed, 1e-6), stages=dict(self.timing),
                    episodes=len(self.rows), discarded=len(self.discarded),
                    phases={name: int((self.phase == value).sum()) for name, value in
                            (('close', self.CLOSE), ('settle', self.SETTLE), ('tare', self.TARE),
                             ('descend', self.DESCEND), ('skill', self.SKILL), ('idle', self.IDLE))})


def _brief(start):
    if start is None:
        return {}
    keys = ('kind', 'mode', 'level', 'start_id', 'item_id', 'repeat', 'profile', 'gain_scale', 'noise_scale',
            'latency', 'rim_error_m', 'in_hand_slip_deg', 'descent_speed_m_s')
    out = {k: start[k] for k in keys if k in start}
    if 'xy_offset_m' in start:
        out['xy_offset_mm'] = float(np.linalg.norm(start['xy_offset_m']))*1e3
        out['hand_tilt_deg'] = float(np.degrees(np.linalg.norm(start['hand_tilt_rotvec'])))
        out['friction'] = list(start['friction'])
    if start.get('kind') == 'recorded':
        out['source'] = start['source']
        out['case_id'] = start['meta'].get('case_id')
    return out
