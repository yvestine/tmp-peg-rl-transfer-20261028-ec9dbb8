"""Skill-environment evaluation: gate 2, RL-vs-scripted comparison, ablations and stiffness probes.

All sets are finite FixedStarts; actors are deterministic. Starts that never reach the trigger
(approach timeout / placement failure) are reported separately as 'not_triggered'.
"""
import copy
import math
import time
import numpy as np
import torch
from . import observation as contract
from .analysis import mcnemar_exact, wilson
from .starts import FixedStarts, synthetic_validation


def run_fixed(env, actor, starts, repeats=1, *, label='validation', deadline=None):
    """Run each start `repeats` times; returns (episode rows, not-triggered rows) keyed by item_id."""
    previous = env.sampler
    fixed = FixedStarts(starts, repeats, split=label)
    discarded_before = len(env.discarded)
    obs = env.set_sampler(fixed)
    expected = len(fixed)
    episodes = []
    try:
        while True:
            not_triggered = [r for r in env.discarded[discarded_before:] if 'item_id' in r['start']]
            if len(episodes)+len(not_triggered) >= expected:
                break
            if env.idle():
                raise RuntimeError(f'{label}: environments idle with {expected-len(episodes)-len(not_triggered)} starts missing')
            if deadline is not None and time.monotonic() > deadline:
                raise TimeoutError(f'{label}: wall budget reached during validation')
            obs, _, _, info = env.step(actor(obs))
            episodes.extend(info['episodes'])
    finally:
        env.set_sampler(previous)
    not_triggered = [dict(r['start'], reason=r['reason']) for r in env.discarded[discarded_before:] if 'item_id' in r['start']]
    return sorted(episodes, key=lambda r: r['item_id']), sorted(not_triggered, key=lambda r: r['item_id'])


def summarize(label, episodes, not_triggered):
    n = len(episodes)
    successes = sum(r['success'] for r in episodes)
    rate = successes/n if n else None
    reasons = {}
    for row in episodes:
        reasons[row['reason']] = reasons.get(row['reason'], 0)+1
    success_rows = [r for r in episodes if r['success']]
    return dict(label=label, episodes=n, successes=successes, success_rate=rate,
                wilson95=wilson(successes, n) if n else None, not_triggered=len(not_triggered),
                not_triggered_fraction=len(not_triggered)/max(1, n+len(not_triggered)), reasons=reasons,
                mean_success_seconds=float(np.mean([r['seconds'] for r in success_rows])) if success_rows else None,
                mean_peak_force_n=float(np.mean([r['peak_force_n'] for r in episodes])) if n else None,
                mean_max_lateral_force_n=float(np.mean([r['max_lateral_force_n'] for r in episodes])) if n else None,
                height_bias_mm_p50=float(np.median([r['height_bias_mm'] for r in episodes])) if n else None)


def ppo_actor(policy):
    return lambda obs: policy.deterministic(obs['actor'])


def scripted_actor(env, settings):
    from .policy import ScriptedInsertion
    scripted = ScriptedInsertion(env.num_envs, settings, env.device)
    return lambda obs: scripted(obs['actor']), scripted


def zero_actor(env):
    return lambda obs: torch.zeros(env.num_envs, 5, device=env.device)


def evaluate_sets(env, actor, settings, distribution, recorded, *, sources=None, noisy=True, deadline=None):
    """Gate-2 sets: fitted synthetic (clean), recorded VLA hand-overs x repeats, fitted synthetic with real noise."""
    result, rows = {}, {}
    synthetic = synthetic_validation(distribution, settings, sources)
    rows['synthetic'] = run_fixed(env, actor, synthetic, 1, label='synthetic', deadline=deadline)
    result['synthetic'] = summarize('synthetic', *rows['synthetic'])
    if recorded:
        rows['recorded'] = run_fixed(env, actor, recorded, settings.recorded_repeats, label='recorded', deadline=deadline)
        result['recorded'] = summarize('recorded', *rows['recorded'])
    if noisy:
        noisy_set = synthetic_validation(distribution, settings, sources, noisy=True)
        rows['noisy'] = run_fixed(env, actor, noisy_set, 1, label='noisy', deadline=deadline)
        result['noisy'] = summarize('noisy', *rows['noisy'])
    result['gate'] = gate_status(result, settings)
    return result, rows


def gate_status(result, settings):
    s = settings
    synthetic = result.get('synthetic', {})
    recorded = result.get('recorded')
    checks = dict(
        synthetic=(synthetic.get('success_rate') or 0.) >= s.gate_synthetic,
        synthetic_triggered=synthetic.get('not_triggered_fraction', 1.) <= .05,
        recorded_available=recorded is not None and recorded['episodes'] > 0,
        recorded=recorded is not None and (recorded.get('success_rate') or 0.) >= s.gate_recorded)
    return dict(passed=all(checks.values()), checks=checks, synthetic_threshold=s.gate_synthetic,
                recorded_threshold=s.gate_recorded)


def selection_key(result, settings):
    """Gate-normalized success first, then mean success, faster insertion, lower peak force."""
    s = settings
    synthetic = result['synthetic']['success_rate'] or 0.
    recorded = result['recorded']['success_rate'] if 'recorded' in result else None
    ratios = [synthetic/s.gate_synthetic]+([recorded/s.gate_recorded] if recorded is not None else [])
    mean = float(np.mean([synthetic]+([recorded] if recorded is not None else [])))
    seconds = result['synthetic']['mean_success_seconds'] or s.skill_seconds
    force = result['synthetic']['mean_peak_force_n'] or 0.
    return (bool(result['gate']['passed']), min(ratios), mean, -seconds, -force)


def paired(rows_a, rows_b):
    """McNemar on item-matched outcomes (same start, same repeat seed)."""
    a = {r['item_id']: r['success'] for r in rows_a}
    b = {r['item_id']: r['success'] for r in rows_b}
    common = sorted(set(a) & set(b))
    both = sum(a[i] and b[i] for i in common)
    only_a = sum(a[i] and not b[i] for i in common)
    only_b = sum(b[i] and not a[i] for i in common)
    neither = len(common)-both-only_a-only_b
    return dict(items=len(common), both=both, only_first=only_a, only_second=only_b, neither=neither,
                mcnemar_p=mcnemar_exact(only_a, only_b))


class ProbeActor:
    """Scripted stiffness probe. Vertical: stepwise push on the flat top. Lateral: push in the bore, then step X."""

    def __init__(self, env, settings, kind, hold=15):
        self.env, self.cfg, self.kind, self.hold = env, settings, kind, hold
        self.fields = contract.actor_fields(settings)
        self.records = []

    def target(self, step):
        k = step//self.hold
        target = torch.zeros(len(step), 5, device=step.device)
        if self.kind == 'vertical':
            target[:, 2] = -.002*(k+1).clamp(max=8).float()
        else:
            target[:, 2] = -.010
            target[:, 0] = .0005*(k.clamp(min=1, max=5)-1).float()
        return target

    def __call__(self, obs):
        v = contract.decode(obs['actor'], self.fields, self.cfg)
        step = torch.round(v['elapsed'][:, 0]/self.cfg.dt).long()
        valid = obs['valid']
        record = valid & (step > 0) & (step % self.hold == self.hold-1)
        force = v['force_history'].reshape(len(step), self.cfg.force_history_steps, 3)[:, -1]
        for i in record.nonzero().flatten().cpu().tolist():
            self.records.append(dict(kind=self.kind, env_id=i, step=int(step[i]), gap_m=v['gap'][i].cpu().tolist(),
                                     force_n=force[i].cpu().tolist(), offset=v['offset'][i].cpu().tolist(),
                                     height_m=float(v['height'][i, 0])))
        step_size = self.env.integrator.step
        action = ((self.target(step)-v['offset'])/step_size).clamp(-1., 1.)
        return torch.where(valid[:, None], action, torch.zeros_like(action))


def stiffness_probe(env, settings, distribution, sources, count=32):
    """Phase-0 identification of the effective Cartesian stiffness behind the gap bounds."""
    starts = synthetic_validation(distribution, settings, sources)[:count]
    vertical, lateral = [], []
    for start in starts:
        flat = copy.deepcopy(start)
        angle = math.atan2(flat['xy_offset_m'][1], flat['xy_offset_m'][0]) if any(flat['xy_offset_m']) else 0.
        # 10 mm: the 8 mm peg rests entirely on the flat top, outside the 11 mm chamfer opening.
        flat['xy_offset_m'] = [.010*math.cos(angle), .010*math.sin(angle)]
        flat['extra_xy_m'] = [0., 0.]
        flat['trigger'] = 'contact'
        vertical.append(flat)
        bore = copy.deepcopy(start)
        bore['xy_offset_m'], bore['extra_xy_m'] = [0., 0.], [0., 0.]
        lateral.append(bore)
    report = {}
    for kind, items in (('vertical', vertical), ('lateral', lateral)):
        actor = ProbeActor(env, settings, kind)
        rows, missing = run_fixed(env, actor, items, 1, label=f'probe_{kind}')
        axis = 2 if kind == 'vertical' else 0
        gap = np.asarray([r['gap_m'][axis] for r in actor.records])
        force = np.asarray([r['force_n'][axis] for r in actor.records])
        # Contact samples only (the bore has 0.5 mm radial clearance before the wall is reached).
        loaded = np.abs(force) > .5
        stiffness = None
        if loaded.sum() >= 3 and np.ptp(gap[loaded]) > 1e-4:
            stiffness = float(-np.polyfit(gap[loaded], force[loaded], 1)[0])
        report[kind] = dict(samples=int(loaded.sum()), stiffness_n_per_m=stiffness, episodes=len(rows),
                            not_triggered=len(missing), records=actor.records)
    vertical_k = report['vertical']['stiffness_n_per_m']
    report['suggested_gap_z_down_m_for_10n'] = 10./vertical_k if vertical_k and vertical_k > 0 else None
    report['note'] = ('Force sign: positive base-frame Fz is the reaction of a downward push, so stiffness = '
                      '-F/gap. Update gap_z_down_m in a NEW settings file before training if needed.')
    return report
