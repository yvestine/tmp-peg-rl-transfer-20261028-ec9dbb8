# PPO V5：VLA 送到孔口，力触 RL 技能在倒角处接管

独立版本，不修改 V1–V4、不修改任何已有文件。V4 只被引用（`BatchedFK`、`BatchedEncoder`、`PPO`/`gae`），本目录不改动它。

## 设计（10-21 确认）

| 项 | 决定 |
|---|---|
| 控制 | TAVLA 用视觉把 peg 送到孔口；peg 落入倒角后 RL 技能接管，直到成功或交还 |
| 切换 | 正运动学估计的 peg 端部低于标定孔口平面 0.5 mm，连续 2 步（0.1 s/步） |
| 交还 | 接管 15 s 未成功，或端部高出孔口平面 2 mm 持续 0.5 s；交还时向 8001 重新请求；必须先抬出孔口才允许再次接管；每回合最多 2 次 |
| 力觉输入 | 最近 2 s 去零 XYZ 力（10 Hz）+ 冻结 TAVLA encoder 的 32 维 latent |
| 动作 | 每 0.1 s 一个 5 维增量 `[dx, dy, dz, roll, pitch]`，累加到交接时的指令位姿；IK → 原比例限速 → 200/40 关节伺服；偏航固定 |
| 训练 | 并行环境、不开相机、不连 VLA；起点按 VLA 交接分布合成并逐步放宽；真机力噪声随机化 |
| 验收 | 关卡①吞吐 → 关卡②技能单独验证（合成 ≥95%、真实交接状态 ≥90%）→ 端到端 2 组 × 100 case × 1 次 |

物理事实：孔的碰撞网格是 Ø9.0 mm 孔 + 1 mm 45° 倒角，peg Ø7.98 mm，单边间隙约 0.5 mm（不是配置里的 8.1 mm）。

## 文件

| 文件 | 内容 |
|---|---|
| `settings.py` / `config.json` | 冻结合同与全部参数；`variant` 为 `main` / `no_latent` / `no_raw_force` |
| `geometry.py` | 帧变换、正运动学端部高度、倾斜、in-hand 位姿 |
| `trigger.py` | 批量触发/交还状态机（技能环境与端到端共用） |
| `controller.py` | 5D 增量积分器（每步、累计、指令—实测差距三重限幅）、全位姿 IK、原比例限速 |
| `noise.py` | 真机力噪声：每回合偏置 + AR(1) 漂移 + 可选 0.1 s 延迟，加在去零与 encoder 之前 |
| `starts.py` | 交接分布、课程、固定验证集、真实交接快照加载（拒绝测试集快照） |
| `observation.py` / `reward.py` | 观测合同（141 维，固定物理尺度）与奖励 |
| `policy.py` / `learner.py` | 非对称 Actor-Critic；规则力引导插入基线；PPO 更新复用 V4 |
| `skill_env.py` | 并行技能环境：悬空去零 → 类 VLA 下降 → 倒角触发 → 技能 |
| `validation.py` | 固定集评测、关卡②、RL 与规则组配对、刚度探测 |
| `worker.py` / `cli.py` | Isaac 入口：`benchmark` / `train` / `validate` / `compare` / `probe` |
| `cases.py` | 冻结 case 集：`original50`（v6 原样）、`new50`（种子 17201–17205）、`validation40`（17301–17305） |
| `e2e_env.py` / `e2e.py` | 端到端：继承 v6 的 `FixedBackendRandomEnv`，加触发、接管、交还、快照；逐 case 新进程 |
| `analysis.py` | McNemar、Wilson、失败分类、最终报告与预先写定的验收 |
| `tools/` | 第 0 阶段离线工具 |

## 运行顺序

以下命令都在 `/home/gujiawei/isaac_env` 下执行，Python 为 `/home/gujiawei/env_isaaclab/bin/python`（下文记作 `PY`）。Isaac 进程的输出留在 tmux 里。

### 第 0 阶段：事实与输入（CPU，除刚度探测外不需要 GPU）

```bash
PY -B -m tavla_rl.ppo_v5.tools.make_cases          # 冻结 new50 与 validation40
PY -B -m tavla_rl.ppo_v5.tools.fit_force_noise     # 40 条真机轨迹 → phase0/force_noise.json
PY -B -m tavla_rl.ppo_v5.tools.fit_handover        # v6 纯 8001 轨迹 → phase0/handover_distribution.json
PY -B -m tavla_rl.ppo_v5.tools.lift_timing         # 43–44 s 抬起现象
```

刚度探测（GPU，决定 `gap_z_down_m`）：

```bash
PY -u -B -m tavla_rl.ppo_v5.worker probe --num-envs 64 --no-noisy \
  --output outputs/tavla_rl/ppo_v5/phase0/probe
```

`stiffness.json` 给出竖直/横向有效刚度和"压出 10 N 需要的 Z 差距"。如需改 `gap_z_down_m`、`tip_height_correction_m` 等，复制 `config.json` 成新文件并用 `--settings` 指定；改参数后要重新做关卡①。

### 第 1 阶段：采集真实交接状态（8001 在环，约 2–3 小时）

只在 validation40 上跑纯 VLA，并在第一次触发时保存完整状态：

```bash
PY -B -m tavla_rl.ppo_v5.e2e run --sets validation40 --arms vla --capture-states \
  --output-root outputs/tavla_rl/ppo_v5/e2e/validation40
```

拿到快照后可以重新拟合交接分布，用精确的 in-hand 位姿替代近似值（输出到新文件）：

```bash
PY -B -m tavla_rl.ppo_v5.tools.fit_handover --states outputs/tavla_rl/ppo_v5/e2e/validation40 \
  --output outputs/tavla_rl/ppo_v5/phase0/handover_distribution_v2.json
```

### 第 2 阶段：技能训练

关卡①（每个环境数单独测，默认要求 ≥500 技能步/秒、重置隔离、显存 <80%）：

```bash
for n in 64 256 512 1024; do
  PY -u -B -m tavla_rl.ppo_v5.worker benchmark --num-envs $n --output outputs/tavla_rl/ppo_v5/benchmark_$n
done
```

训练（读取同环境数的 benchmark 报告；累计墙钟上限 24 小时，按验证成功率选模）：

```bash
PY -u -B -m tavla_rl.ppo_v5.worker train --num-envs 512 \
  --benchmark-report outputs/tavla_rl/ppo_v5/benchmark_512/benchmark.json \
  --output outputs/tavla_rl/ppo_v5/train_main
```

中断后续训必须换新目录，预算按累计计算：

```bash
PY -u -B -m tavla_rl.ppo_v5.worker train --num-envs 512 \
  --benchmark-report outputs/tavla_rl/ppo_v5/benchmark_512/benchmark.json \
  --resume outputs/tavla_rl/ppo_v5/train_main/checkpoints/last.pth --output outputs/tavla_rl/ppo_v5/train_main_r1
```

关卡②（合成留出集 ≥95%、真实交接状态 ×5 ≥90%，另报加真机噪声后的成功率）：

```bash
PY -u -B -m tavla_rl.ppo_v5.worker validate --num-envs 512 \
  --checkpoint outputs/tavla_rl/ppo_v5/train_main/checkpoints/best.pth --output outputs/tavla_rl/ppo_v5/gate2_main
```

RL 与规则组配对比较（验收条件 2 的数据来源）：

```bash
PY -u -B -m tavla_rl.ppo_v5.worker compare --num-envs 512 \
  --checkpoint outputs/tavla_rl/ppo_v5/train_main/checkpoints/best.pth --output outputs/tavla_rl/ppo_v5/compare_main
```

消融（主模型过关卡②后再做；各 ≤8 小时，只在技能环境比较）：

```bash
PY -u -B -m tavla_rl.ppo_v5.worker train --variant no_latent --num-envs 512 \
  --benchmark-report outputs/tavla_rl/ppo_v5/benchmark_512/benchmark.json --output outputs/tavla_rl/ppo_v5/train_no_latent
PY -u -B -m tavla_rl.ppo_v5.worker train --variant no_raw_force --num-envs 512 \
  --benchmark-report outputs/tavla_rl/ppo_v5/benchmark_512/benchmark.json --output outputs/tavla_rl/ppo_v5/train_no_raw_force
```

### 第 3 阶段：端到端验收（约 200 条，每条 3–4 分钟）

关卡②通过后才跑：

```bash
PY -B -m tavla_rl.ppo_v5.e2e run --sets original50 new50 --arms vla rl \
  --checkpoint outputs/tavla_rl/ppo_v5/train_main/checkpoints/best.pth \
  --output-root outputs/tavla_rl/ppo_v5/e2e/final
PY -B -m tavla_rl.ppo_v5.e2e summarize outputs/tavla_rl/ppo_v5/e2e/final \
  --skill-comparison outputs/tavla_rl/ppo_v5/compare_main/comparison.json
```

`--dry-run` 只打印 worker 命令。中断后用同一命令续跑，已完成的 case 会跳过；代码、参数或 checkpoint 变了会拒绝写入同一目录。

验收标准（事先写定，见 `analysis.py`）：100 个配对 case 上 VLA + RL 显著高于纯 VLA（双侧精确 McNemar p<0.05）；技能环境里 RL 在真实交接状态上不低于规则组。原 50 个只算历史回归，新 50 个才是未见测试。

## 检查

```bash
PY -B -m unittest discover -s tavla_rl/ppo_v5/tests -v
```

CPU 检查不启动 Isaac、不连 8001。重置隔离、相机关闭后的场景、吞吐和接管时序必须由关卡①和端到端冒烟确认。

## 已知限制

- 技能环境沿用 V4 的场景构建（去掉相机），端到端沿用 v6 的 `TavlaRLEnv`；两者物理配置的一致性由关卡②的真实交接状态间接检验。
- 部署用的端部高度估计＝正运动学 TCP + 固定安装长度；仿真里与真值的偏差记录在每个回合的 `height_bias_mm`，必要时写入 `tip_height_correction_m`。
- 恢复记录状态时 peg 正处于接触中，PhysX 的接触缓存无法恢复；重复 1–4 次叠加 0.5 倍真机噪声以产生差异。
- 真机噪声模型来自 10 Hz 记录；更高频的力波动未建模。
