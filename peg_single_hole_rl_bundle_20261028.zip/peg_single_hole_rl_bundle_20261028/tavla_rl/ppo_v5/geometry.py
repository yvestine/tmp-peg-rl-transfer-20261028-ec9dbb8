"""Batched frames and deployable geometry estimates (torch only, no Isaac).

Conventions: quaternions are XYZW (Isaac Lab 3 data and the V4 helpers); the FK and
fingertip frames have +Z pointing from the hand towards the peg tip.
"""
import math
import torch
from tavla_rl.ppo_v4.controller import quat_matrix, rotation_exp, rotation_log

DOWN = (0., 0., -1.)


def tool_axis(rotation):
    return rotation[..., :, 2]


def tilt_deg(axis):
    """Angle between a tool axis and straight down."""
    down = axis.new_tensor(DOWN)
    cosine = (axis*down).sum(-1)/torch.linalg.vector_norm(axis, dim=-1).clamp_min(1e-9)
    return torch.rad2deg(torch.acos(cosine.clamp(-1., 1.)))


def vertical_tilt_deg(rotation):
    """Unsigned angle between a body Z axis and the vertical (peg/hole axis symmetry)."""
    return torch.rad2deg(torch.acos(rotation[..., 2, 2].abs().clamp(0., 1.)))


def leveling_rotation(axis):
    """Smallest base-frame rotation taking each tool axis onto straight down."""
    a = axis/torch.linalg.vector_norm(axis, dim=-1, keepdim=True).clamp_min(1e-9)
    down = a.new_tensor(DOWN).expand_as(a)
    cross = torch.linalg.cross(a, down, dim=-1)
    sine = torch.linalg.vector_norm(cross, dim=-1, keepdim=True)
    cosine = (a*down).sum(-1, keepdim=True)
    angle = torch.atan2(sine, cosine)
    vector = torch.where(sine > 1e-9, cross/sine.clamp_min(1e-12)*angle, torch.zeros_like(cross))
    return rotation_exp(vector.reshape(-1, 3)).reshape(*axis.shape[:-1], 3, 3)


def tilt_rotvec(axis):
    """Base-frame XY rotation vector that would level the tool (small-angle exact form)."""
    a = axis/torch.linalg.vector_norm(axis, dim=-1, keepdim=True).clamp_min(1e-9)
    down = a.new_tensor(DOWN).expand_as(a)
    cross = torch.linalg.cross(a, down, dim=-1)
    sine = torch.linalg.vector_norm(cross, dim=-1, keepdim=True)
    angle = torch.atan2(sine, (a*down).sum(-1, keepdim=True))
    return torch.where(sine > 1e-9, cross/sine.clamp_min(1e-12)*angle, torch.zeros_like(cross))[..., :2]


def tip_from_tcp(position, rotation, mount_m):
    """Deployable peg-tip estimate: the calibrated mount length along the tool axis."""
    return position+tool_axis(rotation)*mount_m


def to_base(points_w, base_pos_w, base_rot_w):
    return (base_rot_w.transpose(-1, -2)@(points_w-base_pos_w)[..., None]).squeeze(-1)


def from_base(points_b, base_pos_w, base_rot_w):
    return base_pos_w+(base_rot_w@points_b[..., None]).squeeze(-1)


def rotation_angle_deg(a, b):
    relative = a@b.transpose(-1, -2)
    cosine = ((relative.diagonal(dim1=-2, dim2=-1).sum(-1)-1.)/2.).clamp(-1., 1.)
    return torch.rad2deg(torch.acos(cosine))


def matrix_quat(matrix):
    """Rotation matrix -> XYZW quaternion, the inverse of quat_matrix."""
    m = matrix
    trace = m[..., 0, 0]+m[..., 1, 1]+m[..., 2, 2]
    candidates = torch.stack((
        torch.stack((m[..., 2, 1]-m[..., 1, 2], m[..., 0, 2]-m[..., 2, 0], m[..., 1, 0]-m[..., 0, 1], 1.+trace), -1),
        torch.stack((1.+m[..., 0, 0]-m[..., 1, 1]-m[..., 2, 2], m[..., 0, 1]+m[..., 1, 0], m[..., 0, 2]+m[..., 2, 0],
                     m[..., 2, 1]-m[..., 1, 2]), -1),
        torch.stack((m[..., 0, 1]+m[..., 1, 0], 1.+m[..., 1, 1]-m[..., 0, 0]-m[..., 2, 2], m[..., 1, 2]+m[..., 2, 1],
                     m[..., 0, 2]-m[..., 2, 0]), -1),
        torch.stack((m[..., 0, 2]+m[..., 2, 0], m[..., 1, 2]+m[..., 2, 1], 1.+m[..., 2, 2]-m[..., 0, 0]-m[..., 1, 1],
                     m[..., 1, 0]-m[..., 0, 1]), -1)), -2)
    selector = torch.stack((trace, m[..., 0, 0], m[..., 1, 1], m[..., 2, 2]), -1).argmax(-1)
    quat = torch.gather(candidates, -2, selector[..., None, None].expand(*selector.shape, 1, 4)).squeeze(-2)
    quat = quat/torch.linalg.vector_norm(quat, dim=-1, keepdim=True).clamp_min(1e-12)
    return torch.where(quat[..., 3:4] < 0, -quat, quat)


def axis_rotation(axis, angle):
    """Rotations about one local axis ('x', 'y' or 'z'); angle is a tensor in radians."""
    c, s = torch.cos(angle), torch.sin(angle)
    one, zero = torch.ones_like(angle), torch.zeros_like(angle)
    if axis == 'x':
        rows = ((one, zero, zero), (zero, c, -s), (zero, s, c))
    elif axis == 'y':
        rows = ((c, zero, s), (zero, one, zero), (-s, zero, c))
    elif axis == 'z':
        rows = ((c, -s, zero), (s, c, zero), (zero, zero, one))
    else:
        raise ValueError('axis must be x, y or z')
    return torch.stack([torch.stack(row, -1) for row in rows], -2)


MOUNT_FLIP = (0., 1., 0., 0.)  # XYZW, identical to the V4 _snap_peg flip quaternion


def peg_pose_from_fingertip(fingertip_pos, fingertip_rot, mount_m, in_hand_offset, in_hand_rotation):
    """Peg root (bottom) pose for a gripped peg, with an explicit in-hand perturbation."""
    nominal = torch.zeros_like(fingertip_pos)
    nominal[..., 2] = mount_m
    position = fingertip_pos+(fingertip_rot@(nominal+in_hand_offset)[..., None]).squeeze(-1)
    flip = quat_matrix(fingertip_pos.new_tensor(MOUNT_FLIP).expand(*fingertip_pos.shape[:-1], 4))
    return position, fingertip_rot@in_hand_rotation@flip


def in_hand_pose(fingertip_pos, fingertip_rot, peg_pos, peg_rot, mount_m):
    """Inverse of peg_pose_from_fingertip: (offset in fingertip frame, relative rotation)."""
    flip = quat_matrix(fingertip_pos.new_tensor(MOUNT_FLIP).expand(*fingertip_pos.shape[:-1], 4))
    local = (fingertip_rot.transpose(-1, -2)@(peg_pos-fingertip_pos)[..., None]).squeeze(-1)
    local[..., 2] -= mount_m
    return local, fingertip_rot.transpose(-1, -2)@peg_rot@flip.transpose(-1, -2)


def degrees(value):
    return value*math.pi/180.


__all__ = ['quat_matrix', 'rotation_exp', 'rotation_log', 'tool_axis', 'tilt_deg', 'vertical_tilt_deg',
           'leveling_rotation', 'tilt_rotvec', 'tip_from_tcp', 'to_base', 'from_base', 'rotation_angle_deg',
           'matrix_quat', 'axis_rotation', 'peg_pose_from_fingertip', 'in_hand_pose', 'degrees']
