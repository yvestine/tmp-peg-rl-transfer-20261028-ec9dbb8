"""CPU checks for V5; no Isaac launch, GPU or network. Run: python -B -m unittest discover -s tavla_rl/ppo_v5/tests"""
