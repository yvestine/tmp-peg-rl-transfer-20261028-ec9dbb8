import json
import math
from dataclasses import replace
from itertools import count
from pathlib import Path
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch
import numpy as np
import torch
from tavla_rl.ppo_v5 import observation as contract
from tavla_rl.ppo_v5.analysis import compare_arms, failure_category, mcnemar_exact, wilson
from tavla_rl.ppo_v5.controller import JointSlew, PoseIntegrator, load_fk, load_proportional_joint_step
from tavla_rl.ppo_v5.geometry import (axis_rotation, in_hand_pose, leveling_rotation, matrix_quat,
                                      peg_pose_from_fingertip, quat_matrix, rotation_exp, tilt_deg, tilt_rotvec,
                                      tool_axis)
from tavla_rl.ppo_v5.noise import BatchedForceNoise, NoiseModel, fit_noise_model
from tavla_rl.ppo_v5.policy import Policy, ScriptedInsertion
from tavla_rl.ppo_v5.reward import potential, reward
from tavla_rl.ppo_v5.settings import PACKAGE, Settings, from_mapping, load_settings, to_jsonable
from tavla_rl.ppo_v5.starts import (Curriculum, FixedStarts, HandoverDistribution, DISTRIBUTION_FORMAT,
                                    sample_start)
from tavla_rl.ppo_v5.trigger import HandoverMachine

torch.set_num_threads(1)


def distribution(n=20):
    rng = np.random.default_rng(0)
    return HandoverDistribution(dict(
        format=DISTRIBUTION_FORMAT, xy_offset_m=rng.uniform(0, .0015, n).tolist(),
        hand_tilt_rotvec=rng.normal(0, .05, (n, 2)).tolist(), approach_speed_m_s=rng.uniform(.004, .006, n).tolist(),
        in_hand_slip_deg=rng.normal(0, 1, n).tolist(), in_hand_offset_m=rng.normal(0, .0003, (n, 3)).tolist(),
        postures=[dict(q=[0.]*7, hole_m=[.4, 0., .12])]))


SOURCES = [dict(profile=i, joint_pos_rad=[0.]*7, hole_position_m=[.4+.01*i, 0., .12394]) for i in range(4)]


class SettingsTests(unittest.TestCase):
    def test_default_file_matches_dataclass_and_variants(self):
        self.assertEqual(load_settings(), Settings())
        self.assertEqual(from_mapping(to_jsonable(Settings())), Settings())
        self.assertFalse(load_settings(variant='no_latent').use_latent)
        self.assertFalse(load_settings(variant='no_raw_force').use_raw_force)
        self.assertEqual(json.loads((PACKAGE/'config.json').read_text()), to_jsonable(Settings()))

    def test_invalid_contracts_are_rejected(self):
        with self.assertRaises(ValueError):
            replace(Settings(), use_latent=False)  # main variant must keep both inputs
        with self.assertRaises(ValueError):
            replace(Settings(), success_reward=10.)  # terminal outcome must dominate
        with self.assertRaises(ValueError):
            replace(Settings(), dt=.05)
        with self.assertRaises(ValueError):
            replace(Settings(), eval_friction=1.2)

    def test_terminal_dominates_running_costs(self):
        s = Settings()
        self.assertGreater(s.success_reward+s.failure_penalty, s.episode_cost_bound()+s.potential_span())


class TriggerTests(unittest.TestCase):
    def test_confirmation_limit_timeout_and_liftout(self):
        s = Settings()
        m = HandoverMachine(2, s)
        inside = torch.tensor([-.001, -.001])
        eligible = torch.tensor([True, False])
        self.assertFalse(bool(m.observe_approach(inside, eligible)[0]))
        fire = m.observe_approach(inside, eligible)
        self.assertEqual(fire.tolist(), [True, False])
        m.start(fire)
        for _ in range(s.liftout_confirm_steps-1):
            _, lift = m.observe_skill(torch.tensor([.003, 0.]))
            self.assertFalse(bool(lift[0]))
        _, lift = m.observe_skill(torch.tensor([.003, 0.]))
        self.assertTrue(bool(lift[0]))
        m.stop(lift)
        m.start(torch.tensor([True, False]))
        self.assertEqual(int(m.takeovers[0]), 2)
        for _ in range(s.skill_steps-1):
            timeout, _ = m.observe_skill(torch.tensor([-.005, 0.]))
        self.assertFalse(bool(timeout[0]))
        timeout, _ = m.observe_skill(torch.tensor([-.005, 0.]))
        self.assertTrue(bool(timeout[0]))
        m.stop(timeout)
        # max_takeovers reached: no third hand-over
        for _ in range(3):
            fire = m.observe_approach(inside, torch.tensor([True, True]))
        self.assertFalse(bool(fire[0]))


class ControllerTests(unittest.TestCase):
    def test_step_total_and_gap_bounds(self):
        s = Settings()
        c = PoseIntegrator(2, s)
        handover = torch.zeros(2, 3)
        measured = torch.zeros(2, 3)
        action = torch.tensor([[1., 0., -1., 1., 0.], [0., 0., 0., 0., 0.]])
        c.propose(action, torch.tensor([True, True]), handover, measured)
        c.commit(torch.tensor([True, True]))
        self.assertAlmostEqual(float(c.offset[0, 0]), s.step_xy_m, places=7)
        self.assertAlmostEqual(float(c.offset[0, 2]), -s.step_z_m, places=7)
        for _ in range(100):
            c.propose(action, torch.tensor([True, True]), handover, measured)
            c.commit(torch.tensor([True, True]))
        # Stuck peg (measured never moves): pushing stops at the gap bound, lateral at the gap bound.
        self.assertAlmostEqual(float(c.offset[0, 2]), -s.gap_z_down_m, places=6)
        self.assertAlmostEqual(float(c.offset[0, 0]), s.gap_xy_m, places=6)
        self.assertAlmostEqual(float(c.offset[0, 3]), math.radians(s.offset_angle_deg), places=6)
        torch.testing.assert_close(c.offset[1], torch.zeros(5))
        # A descending peg lets the command follow down to the total Z authority.
        c.reset([0])
        for k in range(100):
            c.propose(action, torch.tensor([True, False]), handover, torch.tensor([[0., 0., -.001*k], [0., 0., 0.]]))
            c.commit(torch.tensor([True, False]))
        self.assertAlmostEqual(float(c.offset[0, 2]), -s.offset_z_down_m, places=6)

    def test_rejected_ik_does_not_wind_up(self):
        c = PoseIntegrator(1, Settings())
        c.propose(torch.ones(1, 5), torch.tensor([True]), torch.zeros(1, 3), torch.zeros(1, 3))
        c.commit(torch.tensor([False]))
        torch.testing.assert_close(c.offset, torch.zeros(1, 5))

    def test_slew_matches_original_function_and_limits(self):
        s = Settings()
        slew = JointSlew(s)
        original = load_proportional_joint_step()
        command = torch.zeros(3, 7)
        velocity = torch.zeros(3, 7)
        target = torch.tensor([[.01]*7, [0.]*7, [-.002]+[0.]*6])
        q, v, f, feasible = slew(command, velocity, target)
        self.assertTrue(bool(feasible.all()))
        q0, v0, _ = original(command, target, velocity, torch.full((1, 7), .03), torch.full((1, 7), .7), .1)
        torch.testing.assert_close(q, q0)
        self.assertLessEqual(float((q-command).abs().max()), .003+1e-7)


class GeometryTests(unittest.TestCase):
    def test_fk_uses_physical_tcp_in_background(self):
        fk = load_fk()
        # Native PhysX TCP is 107 + 146 mm below link7; the visual asset
        # instead has 107 + 112.071 mm and previously misplaced every reset.
        torch.testing.assert_close((fk.tip@fk.inv7)[3, :3], torch.tensor([0., 0., .253]),
                                   atol=1e-6, rtol=0.)

    def test_quaternion_roundtrip_and_leveling(self):
        torch.manual_seed(0)
        q = torch.nn.functional.normalize(torch.randn(16, 4), dim=-1)
        q = torch.where(q[:, 3:] < 0, -q, q)
        torch.testing.assert_close(matrix_quat(quat_matrix(q)), q, atol=1e-5, rtol=0)
        r = rotation_exp(torch.tensor([[.1, -.05, .3]]))@quat_matrix(torch.tensor([[1., 0., 0., 0.]]))
        level = leveling_rotation(tool_axis(r))@r
        self.assertLess(float(tilt_deg(tool_axis(level))[0]), 1e-3)
        restore = rotation_exp(torch.cat((-tilt_rotvec(tool_axis(r)), torch.zeros(1, 1)), -1))@level
        torch.testing.assert_close(tool_axis(restore), tool_axis(r), atol=1e-5, rtol=0)

    def test_in_hand_pose_inverts_peg_mount(self):
        fingertip = torch.tensor([[.3, .1, .2]])
        rotation = rotation_exp(torch.tensor([[0., .05, .02]]))
        offset = torch.tensor([[.0003, 0., -.0004]])
        slip = axis_rotation('y', torch.tensor([math.radians(4.)]))
        position, peg = peg_pose_from_fingertip(fingertip, rotation, .037, offset, slip)
        local, relative = in_hand_pose(fingertip, rotation, position, peg, .037)
        torch.testing.assert_close(local, offset, atol=1e-6, rtol=0)
        torch.testing.assert_close(relative, slip, atol=1e-6, rtol=0)


class NoiseTests(unittest.TestCase):
    def test_fit_recovers_ar_process_and_zero_model_is_identity(self):
        rng = np.random.default_rng(1)
        rows = []
        for k in range(12):
            n = 300
            drift = np.zeros((n, 3))
            for t in range(1, n):
                drift[t] = .8*drift[t-1]+rng.normal(0, .3, 3)
            z = np.linspace(.2, 0., n)
            rows.append(dict(name=f'traj_{k}', force=drift+rng.normal(0, .05, (n, 3)), z=z, time=np.arange(n)*.1))
        model = fit_noise_model(rows)
        np.testing.assert_allclose(model.ar_phi, [.8]*3, atol=.08)
        noise = BatchedForceNoise(4, NoiseModel.zero())
        noise.reset(torch.arange(4), torch.zeros(4), [False]*4)
        force = torch.randn(4, 3)
        torch.testing.assert_close(noise.apply(force, torch.ones(4, dtype=torch.bool)), force)

    def test_latency_delays_one_sample(self):
        noise = BatchedForceNoise(1, NoiseModel.zero())
        noise.reset(torch.arange(1), torch.zeros(1), [True])
        valid = torch.ones(1, dtype=torch.bool)
        first = noise.apply(torch.tensor([[1., 0., 0.]]), valid)
        second = noise.apply(torch.tensor([[2., 0., 0.]]), valid)
        self.assertEqual(float(first[0, 0]), 1.)
        self.assertEqual(float(second[0, 0]), 1.)


class ObservationRewardTests(unittest.TestCase):
    def test_dimensions_and_roundtrip(self):
        for variant, expected in (('main', 141), ('no_latent', 109), ('no_raw_force', 81)):
            s = load_settings(variant=variant)
            fields = contract.actor_fields(s)
            self.assertEqual(contract.dim(fields), expected)
            values = {name: torch.rand(3, size)*.01 for name, size in fields}
            built = contract.build(values, fields, s)
            decoded = contract.decode(built, fields, s)
            for name, _ in fields:
                torch.testing.assert_close(decoded[name], values[name], atol=1e-6, rtol=1e-4)

    def test_progress_telescopes_and_hovering_earns_nothing(self):
        s = Settings()
        xy = torch.tensor([.001])
        path = [torch.tensor([v]) for v in (.0245, .020, .010, .0029)]
        total = sum(float(potential(xy, b, s)-potential(xy, a, s)) for a, b in zip(path, path[1:]))
        self.assertAlmostEqual(total, float(potential(xy, path[-1], s)-potential(xy, path[0], s)), places=4)
        zero = torch.zeros(1, 5)
        value, terms = reward((xy, path[0]), (xy, path[0]), torch.zeros(1), torch.zeros(1), torch.zeros(1), zero, zero,
                              torch.zeros(1, dtype=torch.bool), torch.zeros(1, dtype=torch.bool), s)
        self.assertEqual(float(terms['progress']), 0.)
        self.assertAlmostEqual(float(value), -s.time_cost, places=6)


class StartTests(unittest.TestCase):
    def test_modes_and_curriculum(self):
        s = Settings()
        d = distribution()
        a = sample_start(np.random.default_rng(3), d, s, SOURCES, level=0., mode='train')
        b = sample_start(np.random.default_rng(3), d, s, SOURCES, level=0., mode='train')
        self.assertEqual(a, b)
        self.assertLessEqual(np.linalg.norm(a['xy_offset_m']), s.easy_xy_m+1e-12)
        e = sample_start(np.random.default_rng(4), d, s, SOURCES, level=0., mode='eval')
        self.assertEqual(e['noise_scale'], 0.)
        self.assertEqual(e['friction'], [s.eval_friction]*3)
        curriculum = Curriculum(replace(s, curriculum_window=4))
        for _ in range(4):
            curriculum.record(True)
        self.assertAlmostEqual(curriculum.level, s.curriculum_step)
        fixed = FixedStarts([a, e], repeats=2)
        items = [fixed.next() for _ in range(4)]
        self.assertIsNone(fixed.next())
        self.assertEqual([i['item_id'] for i in items], [0, 1, 2, 3])


class PolicyTests(unittest.TestCase):
    def test_policy_starts_at_zero_and_scripted_pushes(self):
        s = Settings()
        fields = contract.actor_fields(s)
        policy = Policy(contract.dim(fields), contract.dim(contract.critic_fields(s)), s)
        obs = torch.zeros(2, contract.dim(fields))
        torch.testing.assert_close(policy.deterministic(obs), torch.zeros(2, 5))
        scripted = ScriptedInsertion(2, s)
        values = {name: torch.zeros(2, size) for name, size in fields}
        values['height'][:] = -.001
        history = torch.zeros(2, s.force_history_steps, 3)
        history[1, -1] = torch.tensor([2., 0., 8.])  # loaded, lateral force along +x
        values['force_history'] = history.reshape(2, -1)
        values['elapsed'][:] = .3
        action = scripted(contract.build(values, fields, s))
        self.assertEqual(float(action[0, 2]), -1.)   # no load: push down
        self.assertGreater(float(action[1, 2]), 0.)  # overload: relax
        self.assertGreater(float(action[1, 0]), 0.)  # follow the lateral contact force


class AnalysisTests(unittest.TestCase):
    def test_statistics_and_categories(self):
        self.assertAlmostEqual(mcnemar_exact(10, 6), .4544, places=3)
        self.assertEqual(mcnemar_exact(0, 0), 1.)
        self.assertLess(mcnemar_exact(1, 12), .01)
        low, high = wilson(40, 50)
        self.assertTrue(.66 < low < .7 and .88 < high < .9)
        self.assertEqual(failure_category(dict(success=False, guard=None, xy_m=.001, z_m=.0245)), 'chamfer_stall')
        self.assertEqual(failure_category(dict(success=False, guard=None, xy_m=.0005, z_m=.010)), 'in_bore_stall')
        self.assertEqual(failure_category(dict(success=False, guard=None, xy_m=.001, z_m=.032)), 'above_rim')
        a = {0: dict(success=True), 1: dict(success=False), 2: dict(success=True)}
        b = {0: dict(success=True), 1: dict(success=True), 2: dict(success=False)}
        self.assertEqual(compare_arms(a, b)['only_first'], 1)


class TrainingTests(unittest.TestCase):
    def test_resume_restores_cuda_rng_from_cpu_bytes(self):
        from tavla_rl.ppo_v5 import worker, validation, policy, learner

        cpu_rng = torch.get_rng_state()
        device_rng = Mock()
        device_rng.cpu.return_value = cpu_rng
        saved = dict(policy={}, learner={}, sampler={}, validations=[], best=None,
                     steps=1, actor_steps=1, elapsed_seconds=1., updates=1, episodes=0, successes=0,
                     torch_rng=cpu_rng, cuda_rng=[device_rng], numpy_rng=np.random.get_state(),
                     python_rng=worker.random.getstate())
        args = SimpleNamespace(seed=1, device='cpu', resume=Path('/unused/last.pth'), output=Path('/unused'),
                               total_steps=1, stop_on_gate=False, no_noisy=True)
        env = SimpleNamespace(actor_dim=1, critic_dim=1, sampler=Mock(),
                              set_sampler=lambda sampler: {}, observe=lambda: {})
        env.sampler.curriculum.level = 0.
        result = dict(synthetic=dict(success_rate=.5, mean_success_seconds=1., mean_peak_force_n=1.),
                      gate=dict(passed=False))
        stub_policy = Mock()
        stub_policy.to.return_value = stub_policy
        with (patch.object(worker, 'input_identity', return_value={}),
              patch.object(worker, 'save_checkpoint'), patch.object(worker, 'atomic_json'),
              patch.object(torch, 'load', return_value=saved),
              patch.object(torch.cuda, 'is_available', return_value=True),
              patch.object(torch.cuda, 'manual_seed_all'),
              patch.object(torch.cuda, 'set_rng_state_all') as restore,
              patch.object(policy, 'Policy', return_value=stub_policy), patch.object(learner, 'PPO'),
              patch.object(validation, 'evaluate_sets', return_value=(result, {})), patch('builtins.print')):
            worker.train(args, Settings(), env, None, [], [])
        device_rng.cpu.assert_called_once()
        self.assertIs(restore.call_args.args[0][0], cpu_rng)

    def test_progress_and_summary_override_saved_elapsed_seconds(self):
        from tavla_rl.ppo_v5 import worker, validation

        settings = replace(Settings(), horizon=1, update_epochs=1, minibatch=2)
        spec = contract.contract(settings)
        valid = torch.ones(2, dtype=torch.bool)
        obs = dict(actor=torch.zeros(2, spec['actor_dim']), critic=torch.zeros(2, spec['critic_dim']), valid=valid)
        env = SimpleNamespace(
            actor_dim=spec['actor_dim'], critic_dim=spec['critic_dim'],
            sampler=SimpleNamespace(curriculum=Curriculum(settings)), observe=lambda: obs,
            step=lambda action: (obs, torch.ones(2)*.01, ~valid,
                                 dict(valid=valid, actor_valid=valid, episodes=[])),
            progress=lambda: dict(skill_steps_per_second=1.))
        args = SimpleNamespace(seed=1, device='cpu', resume=None, output=Path('/unused'),
                               total_steps=2, stop_on_gate=False, no_noisy=True)
        result = dict(synthetic=dict(success_rate=.5, mean_success_seconds=1., mean_peak_force_n=1.),
                      gate=dict(passed=False))
        reports = {}
        clock = count(0., 31.)  # Exercise the 30-second progress branch without waiting.
        with (patch.object(worker, 'input_identity', return_value={}),
              patch.object(worker, 'save_checkpoint'),
              patch.object(worker, 'atomic_json', side_effect=lambda path, value: reports.update({path.name: value})),
              patch.object(worker.time, 'monotonic', side_effect=lambda: next(clock)),
              patch.object(validation, 'evaluate_sets', return_value=(result, {})),
              patch('builtins.print')):
            worker.train(args, settings, env, None, [], [])
        for name in ('training_progress.json', 'training_summary.json'):
            self.assertEqual(reports[name]['steps'], 2)
            self.assertGreater(reports[name]['elapsed_seconds'], 0.)
        self.assertEqual(reports['training_summary.json']['status'], 'COMPLETE')


if __name__ == '__main__':
    unittest.main()
