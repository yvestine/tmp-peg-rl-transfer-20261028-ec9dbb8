"""Isaac worker for the V5 skill: benchmark (gate 1), train, validate (gate 2), compare, probe.

Run explicitly, e.g.  python -u -B -m tavla_rl.ppo_v5.worker train --num-envs 512 --output ...
Help and argument errors never start Isaac.
"""
from contextlib import contextmanager
import json
import os
from pathlib import Path
import random
import tempfile
import time
import numpy as np
import torch
from .cli import parse
from .settings import ROOT, atomic_json, file_sha256, skill_sources, to_jsonable
from . import observation as contract

CHECKPOINT_FORMAT = 'tavla_v5_skill_v1'


@contextmanager
def environment(args, settings, sampler, noise_model):
    from pxr import Usd, UsdGeom
    from .skill_env import VectorSkillEnv
    old = os.environ.get('TACEX_BACKGROUND_USD')
    fd, name = tempfile.mkstemp(prefix='tavla_v5_background_', suffix='.usd')
    os.close(fd)
    env = None
    try:
        stage = Usd.Stage.CreateNew(name)
        root = UsdGeom.Xform.Define(stage, '/World')
        root.GetPrim().GetReferences().AddReference(str(ROOT/'franka_env_background_edit/franka_env.usd'), '/World')
        stage.SetDefaultPrim(root.GetPrim())
        stage.OverridePrim('/World/PhysicsScene').SetActive(False)
        stage.GetRootLayer().Save()
        os.environ['TACEX_BACKGROUND_USD'] = name
        env = VectorSkillEnv(args, settings, sampler, noise_model)
        yield env
    finally:
        if env is not None:
            env.close()
        if old is None:
            os.environ.pop('TACEX_BACKGROUND_USD', None)
        else:
            os.environ['TACEX_BACKGROUND_USD'] = old
        Path(name).unlink(missing_ok=True)


def load_inputs(args, settings):
    from .noise import NoiseModel
    from .starts import HandoverDistribution, load_recorded_states, recorded_sources
    distribution = HandoverDistribution.load(args.distribution)
    noise = NoiseModel.load(args.noise_model) if args.noise_model.is_file() else NoiseModel.zero()
    recorded = load_recorded_states(args.recorded_states, settings) if args.recorded_states.exists() else []
    return distribution, noise, recorded, recorded_sources()


def input_identity(args):
    paths = dict(distribution=args.distribution, noise_model=args.noise_model)
    value = {k: (file_sha256(p) if p and Path(p).is_file() else None) for k, p in paths.items()}
    states = sorted(Path(args.recorded_states).rglob('handover_state.npz')) if args.recorded_states.exists() else []
    value['recorded_states'] = {str(p): file_sha256(p) for p in states}
    return value


def save_checkpoint(path, policy, ppo, sampler, settings, counters, history, best, inputs):
    value = dict(format=CHECKPOINT_FORMAT, settings=to_jsonable(settings), sources=skill_sources(),
                 observation=contract.contract(settings), policy=policy.state_dict(), learner=ppo.state_dict(),
                 sampler=sampler.state_dict(), validations=history, best=best, inputs=inputs, **counters,
                 torch_rng=torch.get_rng_state(),
                 cuda_rng=torch.cuda.get_rng_state_all() if torch.cuda.is_available() else [],
                 numpy_rng=np.random.get_state(), python_rng=random.getstate())
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix('.tmp.pth')
    torch.save(value, temporary)
    temporary.replace(path)


def train(args, settings, env, distribution, recorded, sources):
    from .learner import PPO
    from .policy import Policy
    from .validation import evaluate_sets, ppo_actor, selection_key
    torch.manual_seed(args.seed)
    policy = Policy(env.actor_dim, env.critic_dim, settings).to(args.device)
    ppo = PPO(policy, settings)
    inputs = input_identity(args)
    counters = dict(steps=0, actor_steps=0, elapsed_seconds=0., updates=0, episodes=0, successes=0)
    history, best = [], None
    if args.resume:
        saved = torch.load(args.resume, map_location=args.device, weights_only=False)
        policy.load_state_dict(saved['policy'])
        ppo.load_state_dict(saved['learner'])
        env.sampler.load_state_dict(saved['sampler'])
        counters.update({k: saved[k] for k in counters})
        history, best = saved['validations'], saved['best']
        torch.set_rng_state(saved['torch_rng'].cpu())
        if saved['cuda_rng'] and torch.cuda.is_available():
            torch.cuda.set_rng_state_all([state.cpu() for state in saved['cuda_rng']])
        np.random.set_state(saved['numpy_rng'])
        random.setstate(saved['python_rng'])
        obs = env.set_sampler(env.sampler)  # fresh physical episodes; no partial rollout is reused
    else:
        obs = env.observe()
    hours = settings.training_hours if settings.variant == 'main' else settings.ablation_hours
    started = time.monotonic()
    deadline = started+hours*3600-counters['elapsed_seconds']
    every = settings.validation_every_steps
    next_validation = (counters['steps']//every+1)*every
    last_report = started
    checkpoints = args.output/'checkpoints'

    def elapsed():
        return counters['elapsed_seconds']+time.monotonic()-started

    def run_validation(final=False):
        nonlocal best, obs
        result, rows = evaluate_sets(env, ppo_actor(policy), settings, distribution, recorded, sources=sources,
                                     noisy=final and not args.no_noisy)
        entry = dict(steps=counters['steps'], elapsed_seconds=elapsed(), level=env.sampler.curriculum.level,
                     final=final, **{k: v for k, v in result.items()})
        name = f"val_{counters['steps']:010d}.pth"
        key = list(selection_key(result, settings))
        entry.update(checkpoint=str(checkpoints/name), selection_key=key)
        history.append(entry)
        if best is None or key > best['selection_key']:
            best = dict(entry)
        save_checkpoint(checkpoints/name, policy, ppo, env.sampler, settings, dict(counters, elapsed_seconds=elapsed()),
                        history, best, inputs)
        if best['checkpoint'] == entry['checkpoint']:
            save_checkpoint(checkpoints/'best.pth', policy, ppo, env.sampler, settings,
                            dict(counters, elapsed_seconds=elapsed()), history, best, inputs)
        atomic_json(args.output/'validation_history.json', history)
        atomic_json(args.output/f"validation_rows/{counters['steps']:010d}.json", rows)
        print(f"[V5 validate] steps={counters['steps']} synthetic={result['synthetic']['success_rate']} "
              f"recorded={result.get('recorded', {}).get('success_rate')} gate={result['gate']['passed']}", flush=True)
        obs = env.observe()
        return result

    while time.monotonic() < deadline and (not args.total_steps or counters['steps'] < args.total_steps):
        rows, sampled = [], 0
        for _ in range(settings.horizon):
            action, log_prob, value = policy.act(obs)
            action = torch.where(obs['valid'][:, None], action, torch.zeros_like(action))
            next_obs, reward, done, info = env.step(action)
            with torch.no_grad():
                next_value = policy.value(next_obs['critic'])
            rows.append(dict(actor=obs['actor'], critic=obs['critic'], action=action, log_prob=log_prob, value=value,
                             next_value=next_value, reward=reward, done=done, valid=info['valid'],
                             actor_valid=info['actor_valid']))
            sampled += int(info['valid'].sum())
            if info['episodes']:
                counters['episodes'] += len(info['episodes'])
                counters['successes'] += sum(r['success'] for r in info['episodes'])
                with (args.output/'episodes.jsonl').open('a') as handle:
                    for row in info['episodes']:
                        handle.write(json.dumps(dict(row, steps_total=counters['steps']+sampled), allow_nan=False)+'\n')
            obs = next_obs
        metrics = ppo.update(rows)
        counters['steps'] += sampled
        counters['actor_steps'] += sampled
        counters['updates'] = ppo.updates
        save_checkpoint(checkpoints/'last.pth', policy, ppo, env.sampler, settings,
                        dict(counters, elapsed_seconds=elapsed()), history, best, inputs)
        if counters['steps'] >= next_validation:
            next_validation += every
            result = run_validation()
            if args.stop_on_gate and result['gate']['passed']:
                break
        if time.monotonic()-last_report >= 30:
            last_report = time.monotonic()
            report = dict(counters, status='RUNNING', elapsed_seconds=elapsed(), budget_hours=hours,
                          level=env.sampler.curriculum.level, metrics=metrics, progress=env.progress(),
                          best=None if best is None else {k: best[k] for k in ('steps', 'checkpoint', 'selection_key')})
            atomic_json(args.output/'training_progress.json', report)
            print(f"[V5 train] steps={counters['steps']} episodes={counters['episodes']} "
                  f"success={counters['successes']} level={env.sampler.curriculum.level:.2f} "
                  f"kl={metrics.get('kl', 0.):.4f} skill_steps/s={env.progress()['skill_steps_per_second']:.0f}",
                  flush=True)
    final = run_validation(final=True)
    complete = time.monotonic() >= deadline or (args.total_steps and counters['steps'] >= args.total_steps)
    summary = dict(counters, status='COMPLETE' if complete else 'STOPPED_ON_GATE', variant=settings.variant,
                   elapsed_seconds=elapsed(), budget_hours=hours, curriculum=env.sampler.curriculum.state_dict(),
                   best=best, final_gate=final['gate'], gate_passed_by_best=bool(best and best['gate']['passed']),
                   resume_from=str(checkpoints/'last.pth'))
    atomic_json(args.output/'training_summary.json', summary)


def actor_for(args, env, settings):
    from .policy import load_policy
    from .validation import ppo_actor, scripted_actor, zero_actor
    if args.policy == 'ppo':
        policy, trained, _ = load_policy(args.checkpoint, env.device)
        if contract.contract(trained) != contract.contract(settings):
            raise ValueError('Environment and checkpoint observation contracts differ')
        return ppo_actor(policy)
    if args.policy == 'scripted':
        return scripted_actor(env, settings)[0]
    return zero_actor(env)


def validate(args, settings, env, distribution, recorded, sources):
    from .validation import evaluate_sets
    result, rows = evaluate_sets(env, actor_for(args, env, settings), settings, distribution, recorded,
                                 sources=sources, noisy=not args.no_noisy)
    identity = dict(policy=args.policy, checkpoint=str(args.checkpoint) if args.checkpoint else None,
                    checkpoint_sha256=file_sha256(args.checkpoint) if args.checkpoint else None,
                    variant=settings.variant, inputs=input_identity(args))
    atomic_json(args.output/'gate2.json', dict(identity, **result))
    atomic_json(args.output/'episodes.json', rows)
    print(f"[V5 gate2] {json.dumps(result['gate'])}", flush=True)


def compare(args, settings, env, distribution, recorded, sources):
    from .policy import load_policy
    from .validation import evaluate_sets, paired, ppo_actor, scripted_actor
    policy, _, _ = load_policy(args.checkpoint, env.device)
    rl, rl_rows = evaluate_sets(env, ppo_actor(policy), settings, distribution, recorded, sources=sources,
                                noisy=not args.no_noisy)
    scripted, scripted_rows = evaluate_sets(env, scripted_actor(env, settings)[0], settings, distribution, recorded,
                                            sources=sources, noisy=not args.no_noisy)
    value = dict(checkpoint=str(args.checkpoint), checkpoint_sha256=file_sha256(args.checkpoint),
                 inputs=input_identity(args), rl=rl, scripted=scripted)
    for name in rl_rows:
        value[name] = dict(rl_success_rate=rl[name]['success_rate'], scripted_success_rate=scripted[name]['success_rate'],
                           paired=paired(rl_rows[name][0], scripted_rows[name][0]))
    atomic_json(args.output/'comparison.json', value)
    atomic_json(args.output/'episodes.json', dict(rl=rl_rows, scripted=scripted_rows))
    print('[V5 compare] '+json.dumps({k: value[k] for k in rl_rows}), flush=True)


def probe(args, settings, env, distribution, recorded, sources):
    from .validation import stiffness_probe
    report = stiffness_probe(env, settings, distribution, sources, count=args.probe_count)
    atomic_json(args.output/'stiffness.json', report)
    print(f"[V5 probe] vertical K={report['vertical']['stiffness_n_per_m']} N/m, lateral "
          f"K={report['lateral']['stiffness_n_per_m']} N/m, gap for 10 N={report['suggested_gap_z_down_m_for_10n']}",
          flush=True)


def benchmark(args, settings, env, distribution, recorded, sources):
    """Gate 1: throughput, reset isolation and GPU memory at this environment count."""
    zero = torch.zeros(env.num_envs, 5, device=env.device)
    torch.cuda.reset_peak_memory_stats()
    obs = env.observe()
    warm, isolation = 0, None
    while warm < 400 and int(obs['valid'].sum()) < max(1, env.num_envs//2):
        obs, _, _, _ = env.step(zero)
        warm += 1
    if env.num_envs > 1:
        rows = torch.arange(1, env.num_envs, device=env.device)
        snapshot = (env.joint_pos[rows].clone(), env.encoder.features[rows].clone(), env.steps[rows].clone(),
                    env.phase[rows].clone(), env.command[rows].clone())
        env.reset_ids(torch.tensor([0], device=env.device))
        after = (env.joint_pos[rows], env.encoder.features[rows], env.steps[rows], env.phase[rows], env.command[rows])
        isolation = all(torch.equal(a, b) for a, b in zip(snapshot, after))
        if not isolation:
            raise RuntimeError('Reset isolation failed: resetting env 0 changed other environments')
        obs = env.observe()
    started, steps0, ticks = time.monotonic(), env.skill_samples, 0
    for _ in range(args.benchmark_steps):
        obs, _, _, _ = env.step(zero)
        ticks += 1
    seconds = time.monotonic()-started
    skill = env.skill_samples-steps0
    free, total = torch.cuda.mem_get_info()
    rate = skill/seconds
    report = dict(status='PASS' if rate >= settings.minimum_steps_per_second and (total-free)/total < settings.max_gpu_memory_fraction
                  and isolation is not False else 'FAIL',
                  num_envs=env.num_envs, ticks=ticks, seconds=seconds, skill_steps=skill,
                  skill_steps_per_second=rate, env_ticks_per_second=ticks*env.num_envs/seconds,
                  minimum_steps_per_second=settings.minimum_steps_per_second,
                  gpu_memory_fraction=(total-free)/total, torch_peak_allocated_bytes=torch.cuda.max_memory_allocated(),
                  reset_isolation=isolation if env.num_envs > 1 else True, warmup_ticks=warm,
                  height_bias_mm_p50=float(np.median([r['height_bias_mm'] for r in env.rows])) if env.rows else None,
                  progress=env.progress(), settings=to_jsonable(settings), sources=skill_sources())
    atomic_json(args.output/'benchmark.json', report)
    print(f"[V5 benchmark] envs={env.num_envs} skill_steps/s={rate:.0f} memory={(total-free)/total:.1%} "
          f"status={report['status']}", flush=True)


def check_benchmark(args, settings):
    report = json.loads(Path(args.benchmark_report).read_text()) if Path(args.benchmark_report).is_file() else {}
    if (report.get('status') != 'PASS' or report.get('num_envs') != args.num_envs
            or report.get('sources') != skill_sources()
            or {k: v for k, v in report.get('settings', {}).items() if k not in ('variant', 'use_latent', 'use_raw_force')}
            != {k: v for k, v in to_jsonable(settings).items() if k not in ('variant', 'use_latent', 'use_raw_force')}):
        raise ValueError(f'Gate 1 not passed for {args.num_envs} environments with the current code/settings: '
                         f'{args.benchmark_report}')


def run(args, settings):
    from .starts import FixedStarts, StartSampler
    torch.set_num_threads(1)
    torch.manual_seed(args.seed)
    np.random.seed(args.seed)
    random.seed(args.seed)
    torch.cuda.manual_seed_all(args.seed)
    distribution, noise, recorded, sources = load_inputs(args, settings)
    if args.mode in ('train', 'benchmark'):
        sampler = StartSampler(args.seed, distribution, settings, sources)
    else:
        sampler = FixedStarts([])
    atomic_json(args.output/'inputs.json', dict(input_identity(args), distribution_summary=distribution.summary(),
                                                recorded_states=len(recorded), noise_model=noise.source))
    with environment(args, settings, sampler, noise) as env:
        {'train': train, 'benchmark': benchmark, 'validate': validate, 'compare': compare,
         'probe': probe}[args.mode](args, settings, env, distribution, recorded, sources)


def main():
    args, settings = parse()
    if args.mode == 'train':
        check_benchmark(args, settings)
    if args.resume:
        saved = torch.load(args.resume, map_location='cpu', weights_only=False)
        if saved.get('format') != CHECKPOINT_FORMAT or saved['settings'] != to_jsonable(settings):
            raise ValueError('Resume checkpoint has different V5 settings')
        if saved['sources'] != skill_sources():
            raise ValueError('V5 skill code changed since this checkpoint; start a new, versioned run')
    if args.output.exists() and any(args.output.iterdir()):
        raise FileExistsError(f'Choose a new, empty --output: {args.output}')
    args.output.mkdir(parents=True, exist_ok=True)
    identity = dict(arguments={k: str(v) if isinstance(v, Path) else v for k, v in vars(args).items()},
                    settings=to_jsonable(settings), sources=skill_sources(),
                    checkpoint_sha256=file_sha256(args.checkpoint) if args.checkpoint else None,
                    resume_sha256=file_sha256(args.resume) if args.resume else None)
    atomic_json(args.output/'run_manifest.json', identity)
    from isaaclab.app import AppLauncher
    app, exit_code = None, 0
    try:
        app = AppLauncher(headless=args.headless, enable_cameras=False, device=args.device).app
        run(args, settings)
    except BaseException as exc:
        import traceback
        exit_code = 1
        atomic_json(args.output/'failure.json', dict(status='INFRASTRUCTURE_FAILURE', error=f'{type(exc).__name__}: {exc}'))
        traceback.print_exc()
    finally:
        if app is not None:
            try:
                app.close()
            except SystemExit as exc:
                if exc.code and not exit_code:
                    exit_code = int(exc.code)
            except BaseException:
                exit_code = 1
    raise SystemExit(exit_code)


if __name__ == '__main__':
    main()
