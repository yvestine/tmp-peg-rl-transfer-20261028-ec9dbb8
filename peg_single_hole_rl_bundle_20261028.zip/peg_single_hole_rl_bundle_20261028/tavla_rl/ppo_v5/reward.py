"""Skill reward. Simulator truth is used here and in the critic only, never by the actor.

progress = potential(after) - potential(before), potential = depth - lateral_weight * lateral excess.
Hovering or pushing without moving earns nothing; the terminal outcome dominates all running costs.
"""
import torch


def potential(xy, z, settings):
    s = settings
    depth = (s.rim_height_m-z).clamp(-.005, s.rim_height_m)
    lateral = (xy-s.lateral_free_m).clamp(0., s.offset_xy_m+s.gap_xy_m)
    return (depth-s.lateral_weight*lateral)/.001


def reward(before, after, lateral_force, peak_force, peg_tilt_deg, action, previous_action, success, failed,
           settings):
    s = settings

    def bounded(value):
        return value.clamp(0., 1.).square()

    terms = dict(
        progress=potential(*after, s)-potential(*before, s),
        terminal=s.success_reward*success.float()-s.failure_penalty*failed.float(),
        time_cost=torch.full_like(after[0], s.time_cost),
        lateral_force_cost=s.lateral_force_cost*bounded((lateral_force-s.lateral_force_free_n)/s.lateral_force_scale_n),
        tilt_cost=s.tilt_cost*bounded((peg_tilt_deg-s.tilt_free_deg)/s.tilt_scale_deg),
        peak_force_cost=s.peak_force_cost*bounded((peak_force-s.peak_force_free_n)/s.peak_force_scale_n),
        smooth_cost=s.smooth_cost*(action.clamp(-1, 1)-previous_action.clamp(-1, 1)).square().mean(-1))
    total = terms['progress']+terms['terminal']-sum(v for k, v in terms.items() if k.endswith('cost'))
    if not bool(torch.isfinite(total).all()):
        raise FloatingPointError('Non-finite V5 reward')
    return total, terms
