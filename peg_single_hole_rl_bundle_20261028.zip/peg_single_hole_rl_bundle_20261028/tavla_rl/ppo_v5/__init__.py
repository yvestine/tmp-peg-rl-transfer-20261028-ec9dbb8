"""PPO V5: TAVLA brings the peg to the hole; a force-tactile RL skill takes over inside the chamfer."""
