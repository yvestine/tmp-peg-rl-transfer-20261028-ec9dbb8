"""Statistics and the final V5 report. CPU-only; reads result JSON written by e2e.py and worker.py.

Pre-registered acceptance (fixed before any end-to-end run):
  1. On all 100 paired cases (original 50 + new 50, one run each), VLA + RL succeeds more often than
     pure VLA and the two-sided exact McNemar p < 0.05.
  2. In the skill environment, RL is not worse than the scripted baseline on the recorded VLA
     hand-over states (point estimate RL >= scripted).
The original 50 cases are reported as a historical regression; only the new 50 are unseen.
"""
import argparse
import csv
import json
import math
from pathlib import Path


def mcnemar_exact(only_first, only_second):
    """Two-sided exact McNemar p-value from the discordant counts."""
    n = int(only_first)+int(only_second)
    if n == 0:
        return 1.
    k = min(int(only_first), int(only_second))
    tail = sum(math.comb(n, i) for i in range(k+1))/2**n
    return float(min(1., 2.*tail))


def wilson(successes, total, z=1.959963984540054):
    if total <= 0:
        return None
    p = successes/total
    denominator = 1+z*z/total
    centre = (p+z*z/(2*total))/denominator
    half = z*math.sqrt(p*(1-p)/total+z*z/(4*total*total))/denominator
    return [max(0., centre-half), min(1., centre+half)]


def failure_category(row, rim_mm=25.):
    if row.get('success'):
        return 'success'
    if row.get('guard'):
        return 'guard'
    xy, z = row['xy_m']*1e3, row['z_m']*1e3
    if xy >= 3. and z >= rim_mm-2.5:
        return 'xy_miss'
    if z < rim_mm-2.5:
        return 'in_bore_stall'
    if z <= rim_mm+.5:
        return 'chamfer_stall'
    return 'above_rim'


def load_arm(root):
    """case_id -> result row for one (case set, arm) directory."""
    rows = {}
    for path in sorted(Path(root).glob('case_*/result.json')):
        value = json.loads(path.read_text())
        if value.get('status') != 'COMPLETE':
            continue
        row = value['result']
        rows[int(value['case_id'])] = row
    return rows


def compare_arms(first, second):
    common = sorted(set(first) & set(second))
    a = {i: bool(first[i]['success']) for i in common}
    b = {i: bool(second[i]['success']) for i in common}
    both = sum(a[i] and b[i] for i in common)
    only_first = sum(a[i] and not b[i] for i in common)
    only_second = sum(b[i] and not a[i] for i in common)
    return dict(cases=len(common), both=both, only_first=only_first, only_second=only_second,
                neither=len(common)-both-only_first-only_second, mcnemar_p=mcnemar_exact(only_first, only_second),
                first_successes=sum(a.values()), second_successes=sum(b.values()))


def arm_summary(rows):
    n = len(rows)
    successes = sum(bool(r['success']) for r in rows.values())
    categories = {}
    for row in rows.values():
        key = failure_category(row)
        categories[key] = categories.get(key, 0)+1
    v5 = [r.get('v5', {}) for r in rows.values()]
    takeovers = [x.get('takeovers', 0) for x in v5]
    return dict(cases=n, successes=successes, success_rate=successes/n if n else None, wilson95=wilson(successes, n),
                categories=categories, episodes_with_trigger=sum(1 for x in v5 if x.get('first_trigger_s') is not None),
                episodes_with_takeover=sum(1 for t in takeovers if t), handbacks=sum(len(x.get('handbacks', [])) for x in v5),
                mean_success_seconds=(sum(r['formal_seconds'] for r in rows.values() if r['success'])/successes
                                      if successes else None),
                mean_peak_force_n=sum(r['peak_force_n'] for r in rows.values())/n if n else None)


def report(root, sets=('original50', 'new50'), arms=('vla', 'rl'), skill_comparison=None):
    root = Path(root)
    data = {s: {a: load_arm(root/s/a) for a in arms} for s in sets}
    out = dict(sets={}, acceptance={})
    combined = {a: {} for a in arms}
    for s in sets:
        out['sets'][s] = {a: arm_summary(data[s][a]) for a in arms}
        if 'vla' in arms and 'rl' in arms:
            out['sets'][s]['vla_vs_rl'] = compare_arms(data[s]['vla'], data[s]['rl'])
        for a in arms:
            combined[a].update({f'{s}:{k}': v for k, v in data[s][a].items()})
    out['combined'] = {a: arm_summary(combined[a]) for a in arms}
    if 'vla' in arms and 'rl' in arms:
        paired = compare_arms(combined['vla'], combined['rl'])
        out['combined']['vla_vs_rl'] = paired
        expected = 50*len(sets)
        complete = paired['cases'] == expected
        criterion_1 = (complete and paired['second_successes'] > paired['first_successes']
                       and paired['mcnemar_p'] < .05)
        out['acceptance']['criterion_1_rl_beats_vla'] = dict(passed=bool(criterion_1), complete=complete,
            cases=paired['cases'], expected=expected, vla=paired['first_successes'], rl=paired['second_successes'],
            p=paired['mcnemar_p'])
    if skill_comparison:
        value = json.loads(Path(skill_comparison).read_text())
        recorded = value.get('recorded') or {}
        rl, scripted = recorded.get('rl_success_rate'), recorded.get('scripted_success_rate')
        out['acceptance']['criterion_2_rl_not_worse_than_scripted'] = dict(
            passed=rl is not None and scripted is not None and rl >= scripted, rl=rl, scripted=scripted,
            paired=recorded.get('paired'))
    out['acceptance']['passed'] = bool(out['acceptance']) and all(
        v['passed'] for k, v in out['acceptance'].items() if isinstance(v, dict))
    return out, data


def write_report(root, output=None, **kwargs):
    root = Path(root)
    output = Path(output or root/'report')
    output.mkdir(parents=True, exist_ok=True)
    summary, data = report(root, **kwargs)
    (output/'summary.json').write_text(json.dumps(summary, indent=2, ensure_ascii=False)+'\n')
    with (output/'per_case.csv').open('w', newline='') as handle:
        writer = csv.writer(handle)
        writer.writerow(['set', 'case_id', 'arm', 'success', 'category', 'formal_seconds', 'xy_mm', 'z_mm',
                         'peak_force_n', 'guard', 'takeovers', 'handbacks', 'first_trigger_s'])
        for set_name, arms in data.items():
            for arm, rows in arms.items():
                for case_id, row in sorted(rows.items()):
                    v5 = row.get('v5', {})
                    writer.writerow([set_name, case_id, arm, int(bool(row['success'])), failure_category(row),
                                     row['formal_seconds'], row['xy_m']*1e3, row['z_m']*1e3, row['peak_force_n'],
                                     row.get('guard'), v5.get('takeovers'), len(v5.get('handbacks', [])),
                                     v5.get('first_trigger_s')])
    lines = ['# V5 端到端评测报告', '',
             '验收标准在任何端到端运行之前固定：100 个配对 case 上 VLA + RL 显著高于纯 VLA（双侧精确 McNemar p<0.05），'
             '且技能环境里 RL 不低于规则组。原 50 个 case 只算历史回归，新 50 个才是未见测试。', '']
    for set_name, value in list(summary['sets'].items())+[('combined', summary['combined'])]:
        lines.append(f'## {set_name}')
        lines.append('|组别|case|成功|成功率|95% CI|卡倒角|孔内卡住|孔口上方|XY 偏离|保护|')
        lines.append('|---|---:|---:|---:|---|---:|---:|---:|---:|---:|')
        for arm in ('vla', 'rl'):
            if arm not in value:
                continue
            a = value[arm]
            c = a['categories']
            ci = a['wilson95']
            lines.append(f"|{arm}|{a['cases']}|{a['successes']}|"
                         f"{(a['success_rate'] or 0)*100:.1f}%|{'' if ci is None else f'{ci[0]*100:.0f}–{ci[1]*100:.0f}%'}|"
                         f"{c.get('chamfer_stall', 0)}|{c.get('in_bore_stall', 0)}|{c.get('above_rim', 0)}|"
                         f"{c.get('xy_miss', 0)}|{c.get('guard', 0)}|")
        if 'vla_vs_rl' in value:
            p = value['vla_vs_rl']
            lines.append('')
            lines.append(f"配对：都成功 {p['both']}，只有 VLA 成功 {p['only_first']}，只有 RL 成功 {p['only_second']}，"
                         f"都失败 {p['neither']}；McNemar p = {p['mcnemar_p']:.3g}")
        lines.append('')
    lines.append('## 验收')
    for key, value in summary['acceptance'].items():
        if isinstance(value, dict):
            lines.append(f"- {key}: {'通过' if value['passed'] else '未通过'} — "
                         f"{json.dumps({k: v for k, v in value.items() if k != 'passed'}, ensure_ascii=False)}")
    lines.append(f"- 总体：{'通过' if summary['acceptance'].get('passed') else '未通过'}")
    (output/'report.md').write_text('\n'.join(lines)+'\n')
    return summary


def main():
    p = argparse.ArgumentParser(description='Summarize V5 end-to-end results')
    p.add_argument('root', type=Path, help='E2E output root with <set>/<arm>/case_XXXX/result.json')
    p.add_argument('--output', type=Path)
    p.add_argument('--sets', nargs='+', default=['original50', 'new50'])
    p.add_argument('--arms', nargs='+', default=['vla', 'rl'])
    p.add_argument('--skill-comparison', type=Path, help='comparison.json from worker compare')
    args = p.parse_args()
    summary = write_report(args.root, args.output, sets=tuple(args.sets), arms=tuple(args.arms),
                           skill_comparison=args.skill_comparison)
    print(json.dumps(summary['acceptance'], indent=2, ensure_ascii=False))


if __name__ == '__main__':
    main()
