"""Batched 5D pose-increment integrator, full-pose IK for resets and the original joint slew.

Execution path (identical to the VLA): integrated TCP offset -> IK from the hand-over joints ->
original proportional joint slew (0.03 rad/s, 0.7 rad/s^2) -> 200/40 joint position servo.
"""
import importlib.util
import math
import torch
from tavla_rl.ppo_v4.controller import BatchedFK, rotation_log
from .settings import ROOT

JOINT_SLEW = ROOT/'source/tacex_tasks/tacex_tasks/real2sim/policy/joint_slew.py'


def load_proportional_joint_step():
    """Load the unchanged slew function by path: no tacex package (and no Isaac) import."""
    spec = importlib.util.spec_from_file_location('_v5_joint_slew', JOINT_SLEW)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.proportional_joint_step


def load_fk(device='cpu'):
    """Use the physical TCP joint from the composed background, not the asset's visual TCP."""
    from pxr import Gf, Usd, UsdGeom, UsdPhysics

    fk = BatchedFK.from_asset(device)
    background = Usd.Stage.Open(str(ROOT/'franka_env_background_edit/franka_env.usd'), load=Usd.Stage.LoadNone)
    joint = UsdPhysics.FixedJoint(background.GetPrimAtPath(
        '/World/Robot/franka/joints/panda_fingertip_centered_joint'))
    asset = Usd.Stage.Open(str(ROOT/'assets/Factory/franka_mimic.usd'), load=Usd.Stage.LoadNone)
    hand = UsdGeom.Xformable(asset.GetPrimAtPath('/panda/panda_hand')).GetLocalTransformation()

    def frame(position, quaternion):
        rotation = Gf.Quatd(float(quaternion.GetReal()), Gf.Vec3d(*quaternion.GetImaginary()))
        return Gf.Matrix4d(Gf.Matrix3d(rotation), Gf.Vec3d(*position))

    parent = frame(joint.GetLocalPos0Attr().Get(), joint.GetLocalRot0Attr().Get())
    child = frame(joint.GetLocalPos1Attr().Get(), joint.GetLocalRot1Attr().Get())
    # The live background's hand-to-TCP distance is 146 mm; the standalone
    # visual asset uses 112.071 mm. Keep reset IK, height and deployment in one frame.
    fk.tip = fk.tip.new_tensor(list(child.GetInverse()*parent*hand))
    return fk


class PoseIntegrator:
    """Offsets of the commanded TCP from the hand-over pose; bounded per step, in total and by gap."""

    def __init__(self, count, settings, device='cpu'):
        s = settings
        self.cfg = s
        self.offset = torch.zeros(count, 5, device=device)
        self.proposed = torch.zeros_like(self.offset)
        angle = math.radians(s.offset_angle_deg)
        self.lower = self.offset.new_tensor([-s.offset_xy_m, -s.offset_xy_m, -s.offset_z_down_m, -angle, -angle])
        self.upper = self.offset.new_tensor([s.offset_xy_m, s.offset_xy_m, s.offset_z_up_m, angle, angle])
        self.step = self.offset.new_tensor([s.step_xy_m, s.step_xy_m, s.step_z_m]+[math.radians(s.step_angle_deg)]*2)

    def reset(self, ids):
        self.offset[ids] = 0.
        self.proposed[ids] = 0.

    def gap_bounds(self, handover_tcp, measured_tcp):
        """Offset bounds that keep (commanded - measured) TCP inside the force-limiting gap."""
        s = self.cfg
        moved = measured_tcp-handover_tcp
        lower = torch.cat((moved[:, :2]-s.gap_xy_m, moved[:, 2:3]-s.gap_z_down_m), -1)
        upper = torch.cat((moved[:, :2]+s.gap_xy_m, moved[:, 2:3]+s.gap_z_up_m), -1)
        return lower, upper

    def propose(self, action, valid, handover_tcp, measured_tcp):
        if action.shape != self.offset.shape or not bool(torch.isfinite(action).all()):
            raise ValueError('Expected finite N x 5 V5 actions')
        proposed = self.offset+action.clamp(-1., 1.)*self.step
        lower, upper = self.gap_bounds(handover_tcp, measured_tcp)
        translation = torch.maximum(torch.minimum(proposed[:, :3], upper), lower)
        proposed = torch.cat((translation, proposed[:, 3:]), -1)
        proposed = torch.maximum(torch.minimum(proposed, self.upper), self.lower)
        self.proposed = torch.where(valid[:, None], proposed, self.offset)
        return self.proposed.clone()

    def commit(self, accepted):
        """Only increments whose IK target was accepted enter the integrator (no wind-up)."""
        self.offset = torch.where(accepted[:, None], self.proposed, self.offset)
        return self.offset.clone()

    def commanded_tcp(self, handover_tcp):
        return handover_tcp+self.offset[:, :3]


class JointSlew:
    """Per-row feasibility, then the original proportional_joint_step (as in V4's _slew)."""

    def __init__(self, settings):
        self.step_fn = load_proportional_joint_step()
        self.velocity_limit = float(settings.velocity_limit_rad_s)
        self.acceleration_limit = float(settings.acceleration_limit_rad_s2)
        self.dt = float(settings.dt)

    def __call__(self, command, velocity, target):
        budget = self.acceleration_limit*self.dt
        direction = (target-command)/self.dt
        nonzero = direction != 0
        divisor = torch.where(nonzero, direction, torch.ones_like(direction))
        a, b = (velocity-budget)/divisor, (velocity+budget)/divisor
        low = torch.where(nonzero, torch.minimum(a, b), torch.zeros_like(a)).amax(-1).clamp_min(0)
        high = torch.minimum(torch.where(nonzero, torch.maximum(a, b), torch.ones_like(a)),
                             torch.where(nonzero, self.velocity_limit/direction.abs().clamp_min(1e-12),
                                         torch.ones_like(a))).amin(-1).clamp_max(1)
        feasible = (high >= low) & (high >= 0) & (nonzero | (velocity.abs() <= budget)).all(-1)
        result, new_velocity = command.clone(), torch.zeros_like(command)
        fraction = torch.zeros(len(command), device=command.device)
        ids = feasible.nonzero().flatten()
        if len(ids):
            q, v, f = self.step_fn(command[ids], target[ids], velocity[ids],
                                   target.new_full((1, 7), self.velocity_limit),
                                   target.new_full((1, 7), self.acceleration_limit), self.dt)
            result[ids], new_velocity[ids], fraction[ids] = q, v, f[:, 0]
        return result, new_velocity, fraction, feasible


def solve_pose(fk, seed, goal_position, goal_rotation, lower, upper, iterations=96,
               position_tolerance=1e-5, rotation_tolerance=.002):
    """Damped least-squares IK to a full TCP pose (resets only; V4's IK fixes yaw offsets to zero)."""
    q = seed.clone()
    weights = q.new_tensor([1., 1., 1., .15, .15, .15])
    for _ in range(iterations):
        p, r = fk(q)
        position_error = goal_position-p
        rotation_error = rotation_log(goal_rotation@r.transpose(-1, -2))
        done = ((torch.linalg.vector_norm(position_error, dim=-1) <= position_tolerance) &
                (torch.linalg.vector_norm(rotation_error, dim=-1) <= rotation_tolerance))
        if bool(done.all()):
            break
        jacobian = fk.jacobian(q)*weights[None, :, None]
        error = torch.cat((position_error, rotation_error), -1)*weights
        system = jacobian@jacobian.transpose(1, 2)+torch.eye(6, device=q.device, dtype=q.dtype)*1e-5
        dq = (jacobian.transpose(1, 2)@torch.linalg.solve(system, error[:, :, None])).squeeze(-1)
        dq = dq*(.04/dq.abs().amax(-1, keepdim=True).clamp_min(1e-12)).clamp_max(1.)
        q = torch.where(done[:, None], q, (q+dq).clamp(lower, upper))
    p, r = fk(q)
    accepted = ((torch.linalg.vector_norm(goal_position-p, dim=-1) <= 1e-4) &
                (torch.linalg.vector_norm(rotation_log(goal_rotation@r.transpose(-1, -2)), dim=-1) <= .005))
    return q, accepted
