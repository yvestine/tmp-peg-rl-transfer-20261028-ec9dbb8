"""V5 reuses the V4 asymmetric PPO update and chronological GAE without modification.

V4 masks critic samples by `valid` and actor samples by `actor_valid`, never bootstraps
terminal transitions, and stops epochs on a KL limit. V5 passes its own Settings, which
provide learning_rate, gamma, gae_lambda, clip, target_kl, update_epochs and minibatch.
"""
from tavla_rl.ppo_v4.learner import PPO, RunningNorm, gae

__all__ = ['PPO', 'RunningNorm', 'gae']
