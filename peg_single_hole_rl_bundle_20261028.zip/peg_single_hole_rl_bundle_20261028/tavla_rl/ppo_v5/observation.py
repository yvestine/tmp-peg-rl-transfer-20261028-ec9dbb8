"""Skill observation contract. The skill and end-to-end environments build it with this module only.

Every actor field is available on the real robot; the critic additionally reads simulator truth.
Values are divided by fixed physical scales (no running normalization) and clipped to +-10.
"""
import math
import torch

LATENT_DIM = 32
RADIANS_5 = math.radians(5.)


def actor_fields(settings):
    fields = [('q', 7), ('qd', 7), ('gripper', 1), ('command', 7), ('command_velocity', 7), ('offset', 5),
              ('tip_displacement', 3), ('height', 1), ('gap', 3), ('tilt', 2)]
    if settings.use_raw_force:
        fields.append(('force_history', 3*settings.force_history_steps))
    if settings.use_latent:
        fields.append(('latent', LATENT_DIM))
    return fields+[('previous_action', 5), ('elapsed', 1)]


CRITIC_EXTRA = (('peg_rel_hole', 3), ('peg_quat', 4), ('in_hand_offset', 3), ('in_hand_rotvec', 3),
                ('clean_force', 3), ('clean_torque', 3), ('friction', 3), ('gain_scale', 1), ('noise_scale', 1),
                ('xy_true', 1), ('z_true', 1), ('peg_tilt', 1))


def critic_fields(settings):
    return actor_fields(settings)+list(CRITIC_EXTRA)


def dim(fields):
    return sum(size for _, size in fields)


def scales(settings):
    """Physical scale per field (a float or one value per element)."""
    s = settings
    return dict(q=1., qd=.1, gripper=1., command=1., command_velocity=s.velocity_limit_rad_s,
                offset=(s.offset_xy_m, s.offset_xy_m, s.offset_z_down_m, RADIANS_5, RADIANS_5),
                tip_displacement=.005, height=.01, gap=(s.gap_xy_m, s.gap_xy_m, s.gap_z_down_m), tilt=.1,
                force_history=s.force_scale_n, latent=1., previous_action=1., elapsed=s.skill_seconds,
                peg_rel_hole=.03, peg_quat=1., in_hand_offset=.005, in_hand_rotvec=.2, clean_force=s.force_scale_n,
                clean_torque=.5, friction=1., gain_scale=1., noise_scale=1., xy_true=s.success_xy_m,
                z_true=s.rim_height_m, peg_tilt=10.)


def build(values, fields, settings):
    """values: name -> (N, size) physical tensors. Returns the scaled (N, D) observation."""
    table = scales(settings)
    parts = []
    for name, size in fields:
        value = values[name]
        if value.ndim != 2 or value.shape[-1] != size:
            raise ValueError(f'Observation field {name} must be (N, {size}), got {tuple(value.shape)}')
        scale = table[name]
        scale = value.new_tensor(scale if isinstance(scale, (tuple, list)) else [scale]*size)
        parts.append(value/scale)
    result = torch.cat(parts, -1).float().clamp(-10., 10.)
    if not bool(torch.isfinite(result).all()):
        raise FloatingPointError('Non-finite V5 observation')
    return result


def decode(observation, fields, settings):
    """Inverse of build for the fields a scripted controller needs (physical units)."""
    table = scales(settings)
    out, start = {}, 0
    for name, size in fields:
        value = observation[:, start:start+size]
        scale = table[name]
        scale = value.new_tensor(scale if isinstance(scale, (tuple, list)) else [scale]*size)
        out[name] = value*scale
        start += size
    return out


def contract(settings):
    return dict(actor_fields=actor_fields(settings), critic_fields=critic_fields(settings),
                actor_dim=dim(actor_fields(settings)), critic_dim=dim(critic_fields(settings)),
                scales={k: (list(v) if isinstance(v, tuple) else v) for k, v in scales(settings).items()},
                frames='robot base frame; FK of measured joints; force tared by the first 20 samples',
                force_history='oldest first, one sample per 0.1 s, the last force_history_steps samples')
