"""Real-robot force-noise model, fitted from the 40 recorded H5 trajectories.

measured = true force (optionally one 0.1 s tick late) + scale * (episode bias + AR(1) drift).
The noise enters BEFORE the 20-sample tare, the TAVLA encoder and the raw history, as on the robot.
"""
from dataclasses import asdict, dataclass
import json
from pathlib import Path
import numpy as np
import torch

FORCE_KEY = 'obs/state/ee_force_base'
POSE_KEY = 'obs/state/ee_pose'


@dataclass(frozen=True)
class NoiseModel:
    static_std_n: tuple
    bias_mean_n: tuple
    bias_std_n: tuple
    ar_phi: tuple
    ar_innovation_std_n: tuple
    sample_period_s: float
    source: dict

    def __post_init__(self):
        for name in ('static_std_n', 'bias_mean_n', 'bias_std_n', 'ar_phi', 'ar_innovation_std_n'):
            value = np.asarray(getattr(self, name), float)
            if value.shape != (3,) or not np.isfinite(value).all():
                raise ValueError(f'{name} must be three finite values')
        if np.any(np.asarray(self.static_std_n) < 0) or np.any(np.asarray(self.bias_std_n) < 0) or \
                np.any(np.asarray(self.ar_innovation_std_n) < 0) or np.any(np.abs(self.ar_phi) >= 1):
            raise ValueError('Noise scales must be nonnegative and the AR(1) process stationary')

    @classmethod
    def load(cls, path):
        value = json.loads(Path(path).read_text())
        if value.get('format') != 'tavla_v5_force_noise_v1':
            raise ValueError('Not a V5 force-noise model; run tools.fit_force_noise first')
        model = value['model']
        return cls(**{k: tuple(v) if isinstance(v, list) else v for k, v in model.items()})

    def save(self, path):
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        Path(path).write_text(json.dumps(dict(format='tavla_v5_force_noise_v1', model=asdict(self)),
                                         indent=2, allow_nan=False)+'\n')

    @classmethod
    def zero(cls):
        z = (0., 0., 0.)
        return cls(z, z, z, z, z, .1, dict(kind='zero'))


def load_real_trajectories(root):
    import h5py
    rows = []
    for path in sorted(Path(root).glob('traj_*/data.h5'), key=lambda p: int(p.parent.name.split('_')[1])):
        with h5py.File(path, 'r') as data:
            rows.append(dict(name=path.parent.name, force=np.asarray(data[FORCE_KEY], float),
                             z=np.asarray(data[POSE_KEY], float)[:, 2], time=np.asarray(data['timestamps'], float)))
    if not rows:
        raise FileNotFoundError(f'No real trajectories under {root}')
    return rows


def fit_noise_model(trajectories, *, tare_samples=20, free_height_m=.03):
    """Static tare noise, per-episode bias and AR(1) drift during free approach motion.

    Free motion is every post-tare sample at least free_height_m above that trajectory's final
    end-effector height (the inserted pose), so contact force does not enter the fit.
    """
    static, biases, current, previous, dts = [], [], [], [], []
    used = []
    for row in trajectories:
        force, z, time = row['force'], row['z'], row['time']
        if force.ndim != 2 or force.shape[1] != 3 or len(force) <= tare_samples+5 or len(z) != len(force):
            raise ValueError(f"Invalid real trajectory {row.get('name')}")
        baseline = np.median(force[:tare_samples], axis=0)
        static.append(force[:tare_samples]-baseline)
        free = np.zeros(len(force), bool)
        free[tare_samples:] = (z[tare_samples:]-z[-1]) >= free_height_m
        if free.sum() < 5:
            continue
        residual = force-baseline
        bias = residual[free].mean(0)
        biases.append(bias)
        centered = residual-bias
        pairs = free[1:] & free[:-1]
        current.append(centered[1:][pairs])
        previous.append(centered[:-1][pairs])
        dts.append(np.diff(time))
        used.append(row.get('name'))
    if len(biases) < 5:
        raise ValueError('Too few trajectories with a free-motion segment for a noise fit')
    static = np.concatenate(static)
    current, previous = np.concatenate(current), np.concatenate(previous)
    phi = (current*previous).sum(0)/np.maximum((previous*previous).sum(0), 1e-12)
    phi = np.clip(phi, -.98, .98)
    innovation = current-phi*previous
    biases = np.asarray(biases)
    dt = np.concatenate(dts)
    return NoiseModel(static_std_n=tuple(static.std(0)), bias_mean_n=tuple(biases.mean(0)),
                      bias_std_n=tuple(biases.std(0)), ar_phi=tuple(phi),
                      ar_innovation_std_n=tuple(innovation.std(0)), sample_period_s=float(np.median(dt)),
                      source=dict(trajectories=used, tare_samples=tare_samples, free_height_m=free_height_m,
                                  free_pairs=int(len(current)), force_key=FORCE_KEY,
                                  sample_period_p5_p95_s=[float(np.percentile(dt, 5)), float(np.percentile(dt, 95))]))


class BatchedForceNoise:
    """Per-environment noise state. Scale 0 and latency 0 reproduce the clean simulator force."""

    def __init__(self, count, model, device='cpu', seed=0):
        self.model = model
        self.generator = torch.Generator(device='cpu').manual_seed(int(seed))
        as_tensor = lambda v: torch.as_tensor(v, dtype=torch.float32, device=device)
        self.bias_mean, self.bias_std = as_tensor(model.bias_mean_n), as_tensor(model.bias_std_n)
        self.phi, self.innovation = as_tensor(model.ar_phi), as_tensor(model.ar_innovation_std_n)
        self.scale = torch.zeros(count, 1, device=device)
        self.latency = torch.zeros(count, dtype=torch.bool, device=device)
        self.bias = torch.zeros(count, 3, device=device)
        self.drift = torch.zeros(count, 3, device=device)
        self.previous = torch.zeros(count, 3, device=device)
        self.started = torch.zeros(count, dtype=torch.bool, device=device)

    def _normal(self, shape):
        return torch.randn(shape, generator=self.generator).to(self.scale.device)

    def reset(self, ids, scale, latency):
        ids = torch.as_tensor(ids, device=self.scale.device, dtype=torch.long)
        n = len(ids)
        if n == 0:
            return
        self.scale[ids] = torch.as_tensor(scale, dtype=torch.float32, device=self.scale.device).reshape(n, 1)
        self.latency[ids] = torch.as_tensor(latency, dtype=torch.bool, device=self.scale.device).reshape(n)
        self.bias[ids] = self.bias_mean+self.bias_std*self._normal((n, 3))
        stationary = self.innovation/torch.sqrt((1-self.phi.square()).clamp_min(1e-6))
        self.drift[ids] = stationary*self._normal((n, 3))
        self.previous[ids] = 0.
        self.started[ids] = False

    def apply(self, force, valid):
        """Advance valid rows by one 0.1 s sample; returns the measured force for every row."""
        self.drift = torch.where(valid[:, None], self.phi*self.drift+self.innovation*self._normal(self.drift.shape),
                                 self.drift)
        delayed = torch.where((self.latency & self.started)[:, None], self.previous, force)
        measured = delayed+self.scale*(self.bias+self.drift)
        self.previous = torch.where(valid[:, None], force, self.previous)
        self.started |= valid
        return measured
