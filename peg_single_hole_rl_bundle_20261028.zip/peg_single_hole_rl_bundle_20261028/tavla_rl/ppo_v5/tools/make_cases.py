"""Phase 0: generate and freeze the V5 case sets new50 (unseen test) and validation40 (CPU only).

python -m tavla_rl.ppo_v5.tools.make_cases
"""
import argparse
import json
from pathlib import Path
from ..cases import CASE_ROOT, write_manifests


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root', type=Path, default=CASE_ROOT)
    args = p.parse_args()
    print(json.dumps(write_manifests(args.root), indent=2))


if __name__ == '__main__':
    main()
