"""Phase 0: fit the real-robot force-noise model from real_data/traj_*/data.h5 (CPU only).

python -m tavla_rl.ppo_v5.tools.fit_force_noise --output outputs/tavla_rl/ppo_v5/phase0/force_noise.json
"""
import argparse
import json
from pathlib import Path
from ..noise import fit_noise_model, load_real_trajectories
from ..settings import ROOT


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--real-root', type=Path, default=ROOT/'real_data')
    p.add_argument('--output', type=Path, default=ROOT/'outputs/tavla_rl/ppo_v5/phase0/force_noise.json')
    p.add_argument('--free-height-m', type=float, default=.03)
    args = p.parse_args()
    if args.output.exists():
        raise FileExistsError(f'{args.output} exists; phase-0 inputs are frozen once written')
    model = fit_noise_model(load_real_trajectories(args.real_root), free_height_m=args.free_height_m)
    model.save(args.output)
    print(json.dumps({k: v for k, v in model.__dict__.items() if k != 'source'}, indent=2))
    print(f'[V5 phase0] force-noise model: {args.output}')


if __name__ == '__main__':
    main()
