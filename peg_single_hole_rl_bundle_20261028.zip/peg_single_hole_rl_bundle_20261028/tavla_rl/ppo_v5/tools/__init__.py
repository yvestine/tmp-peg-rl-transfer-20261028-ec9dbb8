"""Phase-0 offline tools (CPU only)."""
