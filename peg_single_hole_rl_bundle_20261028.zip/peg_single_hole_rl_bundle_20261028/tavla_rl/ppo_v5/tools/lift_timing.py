"""Phase 0: why do several pure-8001 chamfer stalls lift off at 43-44 s? (CPU only, read-only)

python -m tavla_rl.ppo_v5.tools.lift_timing --output outputs/tavla_rl/ppo_v5/phase0/lift_timing

For each failed pure-VLA rollout that reached the hole and later rose >= 5 mm: lift time, time since
first rim contact, TAVLA request count and chunk phase at the lift, the nominal-target Z trend of the
chunk that started the lift, the latent change across that request, and the tared force before it.
A lift tied to absolute time (not to contact duration) points at a time-dependent input, not physics.
"""
import argparse
import csv
import glob
import json
from pathlib import Path
import numpy as np
import torch
from ..settings import ROOT

DEFAULT = ['outputs/peg_three_models_v6/eval/port_8001/full/case_*/episode_0000.npz',
           'outputs/peg_three_models_v6/eval/port_8005/full/case_*/episode_0000.npz']


def analyse(trace, fk, rim_mm=25.):
    data = np.load(trace, allow_pickle=True)
    z, xy = data['z_m']*1e3, data['xy_m']*1e3
    if xy[-1] < 3 and z[-1] < 3:
        return None
    reached = np.nonzero((z <= rim_mm+.5) & (xy < 20))[0]
    if not len(reached):
        return None
    first = int(reached[0])
    lowest = first+int(np.argmin(z[first:]))
    rise = np.nonzero(z[lowest:] >= z[lowest]+5.)[0]
    if not len(rise):
        return None
    lift = lowest+int(rise[0])
    start = lift
    while start > lowest and z[start-1] < z[start]-1e-3:
        start -= 1
    requests = data['request_times'] if 'request_times' in data.files else np.zeros(0)
    t_lift = 2.+start*.1  # trace time_s includes the 2 s startup
    before = int(np.sum(requests <= t_lift+1e-6))
    chunks = data['action_chunks'] if 'action_chunks' in data.files else None
    trend = None
    if chunks is not None and before:
        chunk = torch.as_tensor(chunks[before-1, 1:11, :7], dtype=torch.float32)
        heights = fk(chunk)[0][:, 2].numpy()
        trend = float((heights[-1]-heights[0])*1e3)
    latent_change = None
    if 'sent_effort' in data.files and before >= 2:
        latent_change = float(np.linalg.norm(data['sent_effort'][before-1, -1]-data['sent_effort'][before-2, -1]))
    force = data['force_xyz'][max(0, start-10):start+1]
    return dict(trace=str(Path(trace).relative_to(ROOT)), first_rim_s=first*.1, lift_start_s=start*.1,
                stall_seconds=(start-first)*.1, requests_before_lift=before,
                chunk_phase=float(data['action_index'][start]) if 'action_index' in data.files else None,
                lift_chunk_dz_mm=trend, latent_change_at_lift=latent_change,
                mean_force_before_n=np.linalg.norm(force, axis=1).mean().item(), z_min_mm=float(z[lowest]),
                xy_at_min_mm=float(xy[lowest]))


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--traces', nargs='+', default=DEFAULT)
    p.add_argument('--output', type=Path, default=ROOT/'outputs/tavla_rl/ppo_v5/phase0/lift_timing')
    args = p.parse_args()
    from ..controller import load_fk
    fk = load_fk('cpu')
    rows = []
    for pattern in args.traces:
        for trace in sorted(glob.glob(str(ROOT/pattern))):
            row = analyse(trace, fk)
            if row:
                rows.append(row)
    args.output.mkdir(parents=True, exist_ok=True)
    if rows:
        with (args.output/'lifts.csv').open('w', newline='') as handle:
            writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)
    starts = np.asarray([r['lift_start_s'] for r in rows])
    stalls = np.asarray([r['stall_seconds'] for r in rows])
    summary = dict(lifts=len(rows),
                   lift_start_s=dict(p10=float(np.percentile(starts, 10)), p50=float(np.median(starts)),
                                     p90=float(np.percentile(starts, 90))) if rows else None,
                   stall_seconds=dict(p10=float(np.percentile(stalls, 10)), p50=float(np.median(stalls)),
                                      p90=float(np.percentile(stalls, 90))) if rows else None,
                   absolute_time_spread_s=float(starts.std()) if rows else None,
                   stall_duration_spread_s=float(stalls.std()) if rows else None,
                   reading='A smaller spread in absolute lift time than in stall duration suggests a time-dependent '
                           'policy input rather than a contact-driven retreat.')
    (args.output/'summary.json').write_text(json.dumps(dict(summary, rows=rows), indent=2)+'\n')
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
