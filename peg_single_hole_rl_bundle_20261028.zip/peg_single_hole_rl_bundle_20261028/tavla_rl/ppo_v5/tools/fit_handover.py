"""Phase 0: fit the hand-over start distribution from pure-VLA rollouts (CPU only).

python -m tavla_rl.ppo_v5.tools.fit_handover --output outputs/tavla_rl/ppo_v5/phase0/handover_distribution.json

For every rollout, the hand-over is the first instant the peg tip is >= trigger_depth below the
hole-top plane for trigger_confirm_steps ticks (simulator geometry is used to locate it offline).
Recorded there: true XY offset, FK hand tilt, approach speed over the previous second, and the
joint posture with its hole (IK seeds). In-hand peg pose comes from captured hand-over snapshots
(exact, base frame) or, before any exist, from traces with 120 Hz peg poses (approximate).
"""
import argparse
import glob
import hashlib
import json
from pathlib import Path
import numpy as np
import torch
from ..geometry import in_hand_pose, quat_matrix, rotation_log, tilt_rotvec, tip_from_tcp, tool_axis
from ..settings import ROOT, load_settings
from ..starts import DISTRIBUTION_FORMAT, STATE_FILE

DEFAULT_TRACES = ['outputs/peg_three_models_v6/eval/port_8001/full/case_*/episode_0000.npz']
DEFAULT_HELD = ['outputs/tavla_rl/ppo_pose_v3_resume/eval_best_recent_return_50_reset/case_*/attempt_*/episode_0000.npz']
MOUNT = .050-.017608+.005  # peg_mount_offset_m + pi0_peg_mount_depth_adjust_m


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def trigger_index(z_mm, xy_mm, settings):
    inside = (z_mm <= settings.rim_height_m*1e3-settings.trigger_depth_m*1e3) & (xy_mm < 20.)
    run = 0
    for i, flag in enumerate(inside):
        run = run+1 if flag else 0
        if run >= settings.trigger_confirm_steps:
            return i
    return None


def hole_for(trace):
    folder = Path(trace).parent
    for name in ('random_case_reset.json', 'initialization.json'):
        path = folder/name
        if path.is_file():
            value = json.loads(path.read_text())
            hole = value.get('actual_hole_position_m') or value.get('hole_measured_m') or value['case']['hole_position_m']
            return np.asarray(hole, float), value['case']['case_id']
    raise FileNotFoundError(f'No case/hole metadata next to {trace}')


def kabsch(a, b):
    """R, t with b ~= R a + t."""
    ca, cb = a.mean(0), b.mean(0)
    u, _, vt = np.linalg.svd((a-ca).T@(b-cb))
    d = np.sign(np.linalg.det(vt.T@u.T))
    r = vt.T@np.diag([1., 1., d])@u.T
    return r, cb-r@ca


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--traces', nargs='+', default=DEFAULT_TRACES, help='Pure-VLA episode NPZ globs (relative to ROOT)')
    p.add_argument('--held-traces', nargs='+', default=DEFAULT_HELD, help='NPZ globs with physics_held_pose')
    p.add_argument('--states', nargs='*', default=[], help='Directories with captured handover_state.npz (validation)')
    p.add_argument('--settings', type=Path)
    p.add_argument('--output', type=Path, default=ROOT/'outputs/tavla_rl/ppo_v5/phase0/handover_distribution.json')
    args = p.parse_args()
    if args.output.exists():
        raise FileExistsError(f'{args.output} exists; phase-0 inputs are frozen once written')
    s = load_settings(args.settings)
    from ..controller import load_fk
    fk = load_fk('cpu')
    xy, tilt, speed, postures, used = [], [], [], [], []
    for pattern in args.traces:
        for trace in sorted(glob.glob(str(ROOT/pattern))):
            data = np.load(trace, allow_pickle=True)
            z_mm, xy_mm = data['z_m']*1e3, data['xy_m']*1e3
            i = trigger_index(z_mm, xy_mm, s)
            if i is None:
                continue
            hole, case_id = hole_for(trace)
            q = torch.as_tensor(data['q'][i:i+1, :7], dtype=torch.float32)
            _, r = fk(q)
            xy.append(float(xy_mm[i])/1e3)
            tilt.append((-tilt_rotvec(tool_axis(r))[0]).tolist())
            j = max(0, i-10)
            speed.append(max(0., float(z_mm[j]-z_mm[i])/1e3/max(.1, (i-j)*.1)))
            postures.append(dict(q=data['q'][i, :7].astype(float).tolist(), hole_m=hole.tolist(), case_id=case_id,
                                 source=str(Path(trace).relative_to(ROOT))))
            used.append(dict(path=str(Path(trace).relative_to(ROOT)), sha256=sha(trace), trigger_s=i*.1))
    slip, in_hand, in_hand_sources = [], [], []
    for directory in args.states:
        for path in sorted(Path(directory).rglob(STATE_FILE)):
            with np.load(path, allow_pickle=False) as data:
                meta = json.loads(str(data['meta']))
                if meta.get('split') == 'test':
                    raise ValueError(f'Test-set state {path} must not shape the training distribution')
                q = torch.as_tensor(data['q'][None, :7], dtype=torch.float32)
                p_tcp, r_tcp = fk(q)
                held_p = torch.as_tensor(data['held_pos_b'][None], dtype=torch.float32)
                held_r = quat_matrix(torch.as_tensor(data['held_quat_b'][None], dtype=torch.float32))
            offset, relative = in_hand_pose(p_tcp, r_tcp, held_p, held_r, meta['mount_m'])
            slip.append(float(np.degrees(rotation_log(relative)[0, 1])))
            in_hand.append(offset[0].tolist())
            in_hand_sources.append(dict(path=str(path), sha256=sha(path), exact=True))
    if not slip:
        # Approximate fallback: rigid base transform fitted on the free approach (first 1.5 s).
        for pattern in args.held_traces:
            for trace in sorted(glob.glob(str(ROOT/pattern))):
                data = np.load(trace, allow_pickle=True)
                if 'physics_held_pose' not in data.files:
                    continue
                n = len(data['z_m'])
                held = data['physics_held_pose'][11::12][:n].astype(float)
                q = torch.as_tensor(data['q'][:n, :7], dtype=torch.float32)
                p_tcp, r_tcp = fk(q)
                tips = tip_from_tcp(p_tcp, r_tcp, MOUNT).numpy()
                early = slice(0, min(15, n))
                rot, trans = kabsch(held[early, :3], tips[early])
                i = trigger_index(data['z_m']*1e3, data['xy_m']*1e3, s)
                if i is None:
                    continue
                held_b = torch.as_tensor(rot@held[i, :3]+trans, dtype=torch.float32)[None]
                held_r = torch.as_tensor(rot, dtype=torch.float32)[None]@quat_matrix(
                    torch.as_tensor(held[i, 3:7], dtype=torch.float32)[None])
                offset, relative = in_hand_pose(p_tcp[i:i+1], r_tcp[i:i+1], held_b, held_r, MOUNT)
                slip.append(float(np.degrees(rotation_log(relative)[0, 1])))
                in_hand.append(offset[0].tolist())
                in_hand_sources.append(dict(path=str(Path(trace).relative_to(ROOT)), sha256=sha(trace), exact=False))
    if len(xy) < 5:
        raise ValueError('Fewer than five hand-overs found; check --traces')
    value = dict(format=DISTRIBUTION_FORMAT, xy_offset_m=xy, hand_tilt_rotvec=tilt, approach_speed_m_s=speed,
                 in_hand_slip_deg=slip, in_hand_offset_m=in_hand, postures=postures,
                 trigger=dict(depth_m=s.trigger_depth_m, confirm_steps=s.trigger_confirm_steps,
                              located_with='simulator z (offline); deployment uses the FK estimate'),
                 sources=dict(traces=used, in_hand=in_hand_sources),
                 summary=dict(handovers=len(xy), xy_p50_mm=float(np.percentile(xy, 50))*1e3,
                              xy_p90_mm=float(np.percentile(xy, 90))*1e3,
                              tilt_p50_deg=float(np.degrees(np.median(np.linalg.norm(tilt, axis=1)))),
                              speed_p50_mm_s=float(np.median(speed))*1e3, in_hand_samples=len(slip),
                              slip_abs_p90_deg=float(np.percentile(np.abs(slip), 90)) if slip else None))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(value, indent=2, allow_nan=False)+'\n')
    print(json.dumps(value['summary'], indent=2))
    print(f'[V5 phase0] hand-over distribution: {args.output}')


if __name__ == '__main__':
    main()
