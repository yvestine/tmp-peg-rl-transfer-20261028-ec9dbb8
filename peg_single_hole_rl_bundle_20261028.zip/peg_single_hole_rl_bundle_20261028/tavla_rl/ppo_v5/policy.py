"""Skill policies: the PPO actor-critic and the scripted force-guided insertion baseline."""
import math
from pathlib import Path
import torch
from torch import nn
from torch.distributions import Normal
from tavla_rl.ppo_v4.learner import RunningNorm
from . import observation as obs_contract
from .settings import from_mapping

CHECKPOINT_FORMAT = 'tavla_v5_skill_v1'


def _mlp(inputs, outputs, hidden):
    layers, width = [], inputs
    for size in hidden:
        layers += [nn.Linear(width, size), nn.ELU()]
        width = size
    layers.append(nn.Linear(width, outputs))
    return nn.Sequential(*layers)


class Policy(nn.Module):
    """Gaussian actor on fixed-scale deployable inputs; privileged critic with running normalization.

    Interface matches tavla_rl.ppo_v4.learner.PPO (actor, critic, log_std, critic_norm,
    distribution, value), so the V4 update is reused unchanged.
    """

    def __init__(self, actor_dim, critic_dim, settings):
        super().__init__()
        self.actor = _mlp(actor_dim, 5, settings.hidden)
        self.critic = _mlp(critic_dim, 1, settings.hidden)
        nn.init.zeros_(self.actor[-1].weight)
        nn.init.zeros_(self.actor[-1].bias)
        self.log_std = nn.Parameter(torch.full((5,), float(settings.initial_log_std)))
        self.critic_norm = RunningNorm(critic_dim)

    def distribution(self, actor_obs):
        return Normal(self.actor(actor_obs), self.log_std.clamp(-5., 1.).exp())

    def value(self, critic_obs):
        return self.critic(self.critic_norm(critic_obs)).squeeze(-1)

    @torch.no_grad()
    def act(self, observation, deterministic=False):
        dist = self.distribution(observation['actor'])
        action = dist.mean if deterministic else dist.sample()
        return action, dist.log_prob(action).sum(-1), self.value(observation['critic'])

    @torch.no_grad()
    def deterministic(self, actor_obs):
        return self.actor(actor_obs).clamp(-1., 1.)


def load_policy(path, device='cpu'):
    """Rebuild a trained skill from its checkpoint, with the settings it was trained with."""
    saved = torch.load(Path(path), map_location=device, weights_only=False)
    if saved.get('format') != CHECKPOINT_FORMAT:
        raise ValueError(f'{path} is not a V5 skill checkpoint')
    settings = from_mapping(saved['settings'])
    contract = obs_contract.contract(settings)
    if saved['observation'] != contract:
        raise ValueError('Checkpoint observation contract differs from the current V5 observation module')
    policy = Policy(contract['actor_dim'], contract['critic_dim'], settings).to(device)
    policy.load_state_dict(saved['policy'])
    policy.eval()
    return policy, settings, saved


class ScriptedInsertion:
    """Force-guided baseline with the same trigger, observation and action interface as the RL skill.

    Chamfer: move along the filtered lateral contact force (or spiral when it is too small) while
    keeping a moderate push. Bore: zero the lateral command gap (lateral compliance), level the
    tool, keep pushing, and back off 1 mm when stuck.
    """

    def __init__(self, count, settings, device='cpu', *, push_n=4., force_band_n=1., ema=.3,
                 direction_min_n=.5, lateral_step_m=.0003, spiral_radius_m=.0015, spiral_pitch_m=.0003,
                 spiral_rate=.6, bore_depth_m=.0015, level_above_deg=1., stuck_window=15,
                 stuck_progress_m=.0003, stuck_force_n=3., max_backoffs=3):
        if not settings.use_raw_force:
            raise ValueError('The scripted baseline reads the raw force history')
        self.cfg = settings
        self.fields = obs_contract.actor_fields(settings)
        self.p = dict(push=push_n, band=force_band_n, ema=ema, direction_min=direction_min_n,
                      lateral_step=lateral_step_m, spiral_radius=spiral_radius_m, spiral_pitch=spiral_pitch_m,
                      spiral_rate=spiral_rate, bore_depth=bore_depth_m, level_sine=math.sin(math.radians(level_above_deg)),
                      stuck_window=stuck_window, stuck_progress=stuck_progress_m, stuck_force=stuck_force_n,
                      max_backoffs=max_backoffs)
        self.ema = torch.zeros(count, 2, device=device)
        self.phase = torch.zeros(count, device=device)
        self.heights = torch.zeros(count, stuck_window+1, device=device)
        self.backoff = torch.zeros(count, dtype=torch.long, device=device)
        self.backoffs = torch.zeros(count, dtype=torch.long, device=device)

    @property
    def parameters(self):
        return dict(self.p)

    def reset(self, rows, height):
        self.ema[rows] = 0.
        self.phase[rows] = 0.
        self.heights[rows] = height[rows, None]
        self.backoff[rows] = 0
        self.backoffs[rows] = 0

    @torch.no_grad()
    def __call__(self, actor_obs):
        s, p = self.cfg, self.p
        v = obs_contract.decode(actor_obs, self.fields, s)
        height = v['height'][:, 0]
        new = v['elapsed'][:, 0] < .5*s.dt
        self.reset(new, height)
        force = v['force_history'].reshape(len(actor_obs), s.force_history_steps, 3)[:, -1]
        self.ema = (1-p['ema'])*self.ema+p['ema']*force[:, :2]
        self.heights = torch.cat((self.heights[:, 1:], height[:, None]), 1)
        in_bore = height < -(s.trigger_depth_m+p['bore_depth'])
        action = torch.zeros(len(actor_obs), 5, device=actor_obs.device)
        # Z: hold a moderate push; positive base-frame Fz is the reaction of a downward push.
        fz = force[:, 2]
        action[:, 2] = torch.where(fz < p['push']-p['band'], -1., torch.where(fz > p['push']+p['band'], .5, 0.))
        # XY on the chamfer: follow the filtered lateral force, else an Archimedean spiral.
        magnitude = torch.linalg.vector_norm(self.ema, dim=-1, keepdim=True)
        follow = self.ema/magnitude.clamp_min(1e-6)*(magnitude/2.).clamp(max=1.)*(p['lateral_step']/s.step_xy_m)
        self.phase = torch.where(in_bore | (magnitude[:, 0] >= p['direction_min']), self.phase, self.phase+p['spiral_rate'])
        radius = (p['spiral_pitch']*self.phase/(2*math.pi)).clamp(max=p['spiral_radius'])
        target = torch.stack((radius*torch.cos(self.phase), radius*torch.sin(self.phase)), -1)
        spiral = ((target-v['tip_displacement'][:, :2])/s.step_xy_m).clamp(-.6, .6)
        chamfer_xy = torch.where(magnitude >= p['direction_min'], follow, spiral)
        # XY in the bore: drive the command onto the measured pose, i.e. no lateral load.
        bore_xy = (-.5*v['gap'][:, :2]/s.step_xy_m).clamp(-1., 1.)
        action[:, :2] = torch.where(in_bore[:, None], bore_xy, chamfer_xy)
        # Level the tool beyond a small margin: rotation vector ~ (-tilt_y, tilt_x).
        tilt = v['tilt']
        level = torch.stack((-tilt[:, 1], tilt[:, 0]), -1)/math.radians(s.step_angle_deg)*.5
        tilted = torch.linalg.vector_norm(tilt, dim=-1, keepdim=True) > p['level_sine']
        action[:, 3:] = torch.where(tilted, level.clamp(-1., 1.), torch.zeros_like(level))
        # Stuck under load: back off 1 mm once, then resume (at most max_backoffs times).
        progress = self.heights[:, 0]-self.heights[:, -1]
        loaded = torch.linalg.vector_norm(force, dim=-1) > p['stuck_force']
        stuck = (v['elapsed'][:, 0] > p['stuck_window']*s.dt) & (progress < p['stuck_progress']) & loaded
        start = stuck & (self.backoff == 0) & (self.backoffs < p['max_backoffs'])
        self.backoff = torch.where(start, torch.full_like(self.backoff, 2), self.backoff)
        self.backoffs += start.long()
        lifting = self.backoff == 2
        holding = self.backoff == 1
        action[:, 2] = torch.where(lifting, 1., torch.where(holding, 0., action[:, 2]))
        self.backoff = (self.backoff-1).clamp_min(0)
        return action.clamp(-1., 1.)
