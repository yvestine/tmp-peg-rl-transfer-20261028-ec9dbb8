"""Frozen V5 contract. CPU-only: importing this module never starts Isaac, pxr or networking."""
from dataclasses import asdict, dataclass, fields, replace
import hashlib
import json
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
PACKAGE = Path(__file__).resolve().parent
TUPLE_FIELDS = ('hidden', 'friction_range', 'gain_scale_range', 'noise_scale_range',
                'hover_height_range_m', 'descent_speed_range_m_s', 'approach_extra_xy_range_m')
VARIANTS = ('main', 'no_latent', 'no_raw_force')


@dataclass(frozen=True)
class Settings:
    version: int = 5
    revision: int = 1
    variant: str = 'main'
    # Control clock: the unchanged VLA execution contract (10 Hz, proportional joint slew).
    dt: float = .1
    skill_seconds: float = 15.
    velocity_limit_rad_s: float = .03
    acceleration_limit_rad_s2: float = .7
    # Deployable geometry. Physics mesh: 9.0 mm bore, 1 mm 45 degree chamfer, 7.98 mm peg.
    rim_height_m: float = .025
    peg_mount_offset_m: float = .050-.017608
    tip_height_correction_m: float = 0.
    success_xy_m: float = .003
    success_z_m: float = .003
    # Trigger: the estimated peg tip is this far below the calibrated hole-top plane.
    trigger_depth_m: float = .0005
    trigger_confirm_steps: int = 2
    # Handback (end to end) / failure (skill training).
    liftout_height_m: float = .002
    liftout_confirm_steps: int = 5
    max_takeovers: int = 2
    # Action: one 5D increment [dx, dy, dz, roll, pitch] per 0.1 s; yaw stays fixed.
    step_xy_m: float = .0005
    step_z_m: float = .001
    step_angle_deg: float = .3
    offset_xy_m: float = .003
    offset_z_down_m: float = .030
    offset_z_up_m: float = .005
    offset_angle_deg: float = 5.
    # Commanded-minus-measured TCP bounds. With the position servo they bound contact force.
    gap_xy_m: float = .002
    gap_z_down_m: float = .015
    gap_z_up_m: float = .005
    # Observation.
    force_history_steps: int = 20
    force_scale_n: float = 7.5
    use_latent: bool = True
    use_raw_force: bool = True
    # Reward (initial values; tune only with skill-environment validation sets).
    lateral_free_m: float = .0005
    lateral_weight: float = 2.
    success_reward: float = 100.
    failure_penalty: float = 50.
    time_cost: float = .1
    lateral_force_free_n: float = 2.
    lateral_force_scale_n: float = 5.
    lateral_force_cost: float = .1
    tilt_free_deg: float = 3.
    tilt_scale_deg: float = 5.
    tilt_cost: float = .1
    peak_force_free_n: float = 20.
    peak_force_scale_n: float = 20.
    peak_force_cost: float = .2
    smooth_cost: float = .02
    slip_limit_deg: float = 15.
    # Start distribution and randomization.
    eval_friction: float = .75
    friction_range: tuple = (.5, 1.)
    gain_scale_range: tuple = (.85, 1.15)
    noise_scale_range: tuple = (0., 1.5)
    force_latency_probability: float = .5
    rim_calibration_error_m: float = .0005
    hover_height_range_m: tuple = (.001, .003)
    descent_speed_range_m_s: tuple = (.003, .007)
    approach_extra_xy_range_m: tuple = (0., .002)
    approach_time_constant_s: float = .4
    hole_xy_half_range_m: float = .05
    descent_timeout_s: float = 4.
    # Curriculum: level 0 -> 1 interpolates the easy limits to the training maxima.
    easy_xy_m: float = .0005
    train_xy_m: float = .003
    easy_tilt_deg: float = 2.
    train_tilt_deg: float = 8.
    easy_slip_deg: float = .5
    train_slip_deg: float = 6.
    easy_in_hand_offset_m: float = .0002
    train_in_hand_offset_m: float = .001
    empirical_fraction: float = .5
    curriculum_window: int = 256
    curriculum_threshold: float = .9
    curriculum_step: float = .1
    # PPO: asymmetric actor-critic; the update itself is the unchanged V4 learner.
    hidden: tuple = (256, 256, 128)
    initial_log_std: float = -1.
    learning_rate: float = 3e-4
    gamma: float = .99
    gae_lambda: float = .95
    clip: float = .2
    target_kl: float = .015
    horizon: int = 32
    update_epochs: int = 5
    minibatch: int = 4096
    # Gates and budget.
    minimum_steps_per_second: float = 500.
    max_gpu_memory_fraction: float = .8
    training_hours: float = 24.
    ablation_hours: float = 8.
    validation_every_steps: int = 2_000_000
    synthetic_validation_count: int = 512
    synthetic_validation_seed: int = 52021
    noisy_validation_seed: int = 52022
    recorded_repeats: int = 5
    gate_synthetic: float = .95
    gate_recorded: float = .9

    def __post_init__(self):
        if self.version != 5 or self.revision != 1:
            raise ValueError('Expected V5 settings revision 1')
        if self.variant not in VARIANTS:
            raise ValueError(f'variant must be one of {VARIANTS}')
        if self.variant == 'main' and not (self.use_latent and self.use_raw_force):
            raise ValueError('The main variant keeps both force inputs; ablations name their variant')
        if self.variant == 'no_latent' and (self.use_latent or not self.use_raw_force):
            raise ValueError('no_latent removes only the TAVLA latent')
        if self.variant == 'no_raw_force' and (self.use_raw_force or not self.use_latent):
            raise ValueError('no_raw_force removes only the raw force history')
        values = asdict(self)
        for name, value in values.items():
            if name in ('variant',):
                continue
            items = value if isinstance(value, (tuple, list)) else (value,)
            if any(isinstance(v, bool) for v in items) and name not in ('use_latent', 'use_raw_force'):
                raise ValueError(f'{name} must be numeric')
            if not all(isinstance(v, (int, float)) and math.isfinite(v) for v in items):
                raise ValueError(f'{name} must be finite')
        for name in ('trigger_confirm_steps', 'liftout_confirm_steps', 'max_takeovers', 'force_history_steps',
                     'curriculum_window', 'horizon', 'update_epochs', 'minibatch', 'validation_every_steps',
                     'synthetic_validation_count', 'recorded_repeats'):
            if type(values[name]) is not int or values[name] <= 0:
                raise ValueError(f'{name} must be a positive integer')
        if not math.isclose(self.dt, .1) or abs(self.skill_seconds/self.dt-round(self.skill_seconds/self.dt)) > 1e-9:
            raise ValueError('V5 keeps the 0.1 s control period; skill_seconds must be a multiple of it')
        positive = ('skill_seconds', 'velocity_limit_rad_s', 'acceleration_limit_rad_s2', 'rim_height_m',
                    'peg_mount_offset_m', 'success_xy_m', 'success_z_m', 'trigger_depth_m', 'liftout_height_m',
                    'step_xy_m', 'step_z_m', 'step_angle_deg', 'offset_xy_m', 'offset_z_down_m', 'offset_z_up_m',
                    'offset_angle_deg', 'gap_xy_m', 'gap_z_down_m', 'gap_z_up_m', 'force_scale_n',
                    'lateral_force_scale_n', 'tilt_scale_deg', 'peak_force_scale_n', 'slip_limit_deg',
                    'eval_friction', 'approach_time_constant_s', 'hole_xy_half_range_m', 'descent_timeout_s',
                    'learning_rate', 'clip', 'target_kl', 'minimum_steps_per_second', 'training_hours',
                    'ablation_hours', 'curriculum_step')
        if any(values[k] <= 0 for k in positive):
            raise ValueError('Scales, limits and budgets must be positive')
        if any(v < 0 for k, v in values.items() if k not in ('initial_log_std', 'tip_height_correction_m', 'variant')
               and not isinstance(v, (tuple, list)) and not isinstance(v, bool)):
            raise ValueError('Negative V5 setting')
        if self.trigger_depth_m >= self.rim_height_m or self.offset_z_down_m <= self.rim_height_m:
            raise ValueError('The trigger must lie inside the hole and Z authority must reach its bottom')
        for name in TUPLE_FIELDS:
            value = values[name]
            if name == 'hidden':
                if not value or any(type(v) is not int or v <= 0 for v in value):
                    raise ValueError('hidden must list positive layer widths')
                continue
            if len(value) != 2 or value[0] > value[1] or value[0] < 0:
                raise ValueError(f'{name} must be an ordered nonnegative (low, high) pair')
        if not self.friction_range[0] <= self.eval_friction <= self.friction_range[1]:
            raise ValueError('Evaluation friction must lie inside the training range')
        if not self.gain_scale_range[0] <= 1. <= self.gain_scale_range[1]:
            raise ValueError('Nominal joint gains must lie inside the training range')
        for easy, train in (('easy_xy_m', 'train_xy_m'), ('easy_tilt_deg', 'train_tilt_deg'),
                            ('easy_slip_deg', 'train_slip_deg'), ('easy_in_hand_offset_m', 'train_in_hand_offset_m')):
            if not 0 <= values[easy] <= values[train]:
                raise ValueError(f'{easy} must not exceed {train}')
        if self.train_xy_m > self.offset_xy_m+self.gap_xy_m:
            raise ValueError('Training XY offsets must stay correctable by the action bounds')
        for name in ('empirical_fraction', 'curriculum_threshold', 'force_latency_probability', 'gamma',
                     'gae_lambda', 'gate_synthetic', 'gate_recorded', 'max_gpu_memory_fraction'):
            if not 0 <= values[name] <= 1:
                raise ValueError(f'{name} must be in [0, 1]')
        if self.success_reward+self.failure_penalty <= self.episode_cost_bound()+self.potential_span():
            raise ValueError('Terminal outcomes must dominate bounded running costs and the shaping span')

    @property
    def skill_steps(self):
        return int(round(self.skill_seconds/self.dt))

    def potential_span(self):
        return ((self.rim_height_m+.005)+self.lateral_weight*(self.offset_xy_m+self.gap_xy_m))/.001

    def episode_cost_bound(self):
        per_step = (self.time_cost+self.lateral_force_cost+self.tilt_cost+self.peak_force_cost+4*self.smooth_cost)
        return self.skill_steps*per_step

    @property
    def contract(self):
        return dict(settings=to_jsonable(self),
            control='VLA approach; deployable chamfer trigger; RL skill owns the arm until success, timeout or lift-out',
            trigger=f'FK peg-tip estimate <= hole-top plane - {self.trigger_depth_m*1000:.1f} mm for '
                    f'{self.trigger_confirm_steps} consecutive 0.1 s ticks',
            action='[dx, dy, dz, roll, pitch] increments integrated from the hand-over command pose; '
                   'IK -> original proportional slew -> 200/40 joint position servo; yaw fixed',
            observation='deployable robot state, FK geometry, tared XYZ force history and the frozen TAVLA latent',
            critic='actor plus simulator truth (peg/hole pose, in-hand pose, clean wrench, randomization)',
            reward='potential(depth, lateral) difference + terminal outcome - bounded running costs',
            success=f'unchanged: XY < {self.success_xy_m*1000:.0f} mm and Z < {self.success_z_m*1000:.0f} mm at one instant')


def to_jsonable(settings):
    return json.loads(json.dumps(asdict(settings)))


def from_mapping(value):
    value = dict(value)
    for name in TUPLE_FIELDS:
        if name in value:
            value[name] = tuple(value[name])
    known = {f.name for f in fields(Settings)}
    unknown = set(value)-known
    if unknown:
        raise ValueError(f'Unknown V5 settings: {sorted(unknown)}')
    return Settings(**value)


def load_settings(path=None, variant=None):
    path = Path(path) if path else PACKAGE/'config.json'
    settings = from_mapping(json.loads(path.read_text()))
    if variant and variant != settings.variant:
        settings = replace(settings, variant=variant, use_latent=variant != 'no_latent',
                           use_raw_force=variant != 'no_raw_force')
    return settings


def atomic_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix+'.tmp')
    temporary.write_text(json.dumps(value, indent=2, ensure_ascii=False, default=str, allow_nan=False)+'\n')
    temporary.replace(path)


def read_json(path):
    return json.loads(Path(path).read_text())


def file_sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, allow_nan=False).encode()).hexdigest()


CORE = ('settings.py', 'geometry.py', 'trigger.py', 'controller.py', 'noise.py', 'starts.py',
        'observation.py', 'reward.py', 'policy.py', 'learner.py', 'config.json')
SKILL = ('skill_env.py', 'validation.py', 'worker.py', 'cli.py')
E2E = ('e2e_env.py', 'e2e.py', 'cases.py')
SOURCE = ROOT/'source/tacex_tasks/tacex_tasks/real2sim'
SHARED = [ROOT/'tavla_rl/ppo_v4/controller.py', ROOT/'tavla_rl/ppo_v4/learner.py',
          ROOT/'tavla_rl/ppo_v4/encoder.py', ROOT/'tavla_rl/runtime.py', ROOT/'tavla_rl/contracts.py',
          ROOT/'tavla_rl/env_cfg.py',
          SOURCE/'realsim_env.py', SOURCE/'forge_env.py', SOURCE/'tavla_residual_env.py',
          SOURCE/'realsim_env_cfg.py', SOURCE/'tavla_residual_env_cfg.py', SOURCE/'realsim_tasks_cfg.py',
          SOURCE/'sim_data_visual.py', SOURCE/'pi0_env.py', SOURCE/'pi0_env_cfg.py', SOURCE/'pi0_static_right_arm.py',
          SOURCE/'policy/joint_slew.py', SOURCE/'policy/force_contact_capture.py',
          SOURCE/'policy/force_align_diagnostics.py',
          ROOT/'force_align_latent_sim_bundle_20261004/sim_adapter.py',
          ROOT/'force_align_latent_sim_bundle_20261004/assets/encoder.pt',
          ROOT/'assets/Factory/franka_mimic.usd', ROOT/'assets/Factory/factory_hole_8mm.usd',
          ROOT/'assets/Factory/factory_peg_8mm.usd', ROOT/'franka_env_background_edit/franka_env.usd']


def _hash(paths):
    return {str(Path(p).resolve().relative_to(ROOT)): file_sha256(p) for p in sorted(set(paths), key=str)}


def skill_sources():
    """Identity of everything that defines the trained skill and its environment."""
    paths = [PACKAGE/name for name in CORE+SKILL]+SHARED
    paths += sorted((ROOT/'force_align_latent_sim_bundle_20261004/insertion_alignment_encoder').glob('*.py'))
    return _hash(paths)


def e2e_sources():
    """Identity of the end-to-end evaluation: V5 core plus the historical fixed-backend path."""
    paths = [PACKAGE/name for name in CORE+E2E]+SHARED
    paths += sorted((ROOT/'tavla_rl').glob('*.py'))
    paths += [ROOT/'scripts/peg_fixed_backend_env.py', ROOT/'scripts/peg_fixed_backend.py',
              ROOT/'scripts/peg_random_eval_common.py', ROOT/'tavla_rl/configs/ppo.json',
              ROOT/'configs/force_probe_link7_known_load.json', ROOT/'configs/peg_position_only_eval.json',
              SOURCE/'sim_data_aligned_env.py', SOURCE/'policy/five_model_runtime.py']
    paths += sorted((ROOT/'force_align_latent_sim_bundle_20261004/insertion_alignment_encoder').glob('*.py'))
    return _hash(paths)
