"""CPU-safe argument parsing for the V5 skill worker; never imports Isaac, pxr or the network."""
import argparse
from pathlib import Path
from .settings import ROOT, VARIANTS, from_mapping, load_settings

DEFAULT_ROOT = ROOT/'outputs/tavla_rl/ppo_v5'


def parser():
    p = argparse.ArgumentParser(description='PPO V5 force-tactile insertion skill (no cameras, no VLA)')
    p.add_argument('mode', choices=['benchmark', 'train', 'validate', 'compare', 'probe'])
    p.add_argument('--output', type=Path, required=True, help='New, empty output directory')
    p.add_argument('--num-envs', type=int, default=256)
    p.add_argument('--device', default='cuda:0')
    p.add_argument('--seed', type=int, default=20261021)
    p.add_argument('--settings', type=Path, help='Default: tavla_rl/ppo_v5/config.json')
    p.add_argument('--variant', choices=VARIANTS, default='main', help='Ablations: no_latent / no_raw_force')
    p.add_argument('--distribution', type=Path, default=DEFAULT_ROOT/'phase0/handover_distribution.json')
    p.add_argument('--noise-model', type=Path, default=DEFAULT_ROOT/'phase0/force_noise.json')
    p.add_argument('--recorded-states', type=Path, default=DEFAULT_ROOT/'e2e/validation40/vla',
                   help='Directory searched recursively for handover_state.npz (validation cases only)')
    p.add_argument('--benchmark-report', type=Path)
    p.add_argument('--benchmark-steps', type=int, default=200)
    p.add_argument('--resume', type=Path, help='Continue from last.pth into a NEW --output; budget is cumulative')
    p.add_argument('--checkpoint', type=Path, help='Skill checkpoint for validate / compare')
    p.add_argument('--policy', choices=['ppo', 'scripted', 'zero'], default='ppo')
    p.add_argument('--total-steps', type=int, default=0, help='Optional skill-step cap; 0 keeps only the wall budget')
    p.add_argument('--stop-on-gate', action='store_true', help='Stop training at the first validation passing gate 2')
    p.add_argument('--no-noisy', action='store_true', help='Skip the real-noise robustness set')
    p.add_argument('--probe-count', type=int, default=32)
    p.add_argument('--headless', action=argparse.BooleanOptionalAction, default=True)
    return p


def parse(argv=None):
    p = parser()
    args = p.parse_args(argv)
    settings = load_settings(args.settings, args.variant)
    if args.num_envs <= 0 or args.benchmark_steps <= 0 or args.total_steps < 0 or args.probe_count <= 0:
        p.error('Counts must be positive (total-steps may be 0)')
    if args.mode in ('train', 'validate', 'compare', 'probe', 'benchmark') and not args.distribution.is_file():
        p.error(f'Missing hand-over distribution {args.distribution}; run tools.fit_handover (phase 0) first')
    if args.mode == 'train' and not args.noise_model.is_file():
        p.error(f'Missing force-noise model {args.noise_model}; run tools.fit_force_noise (phase 0) first')
    if args.mode in ('validate', 'compare') and not args.no_noisy and not args.noise_model.is_file():
        p.error('The robustness set needs --noise-model, or pass --no-noisy')
    if args.mode in ('validate', 'compare') and args.policy == 'ppo' and not args.checkpoint:
        p.error('PPO evaluation needs --checkpoint')
    if args.mode == 'compare' and (args.policy != 'ppo' or not args.checkpoint):
        p.error('compare evaluates a PPO --checkpoint against the scripted baseline')
    if args.resume and args.mode != 'train':
        p.error('--resume is only for training')
    if args.checkpoint and args.mode in ('validate', 'compare'):
        import torch
        saved = torch.load(args.checkpoint, map_location='cpu', weights_only=False)
        if saved.get('format') != 'tavla_v5_skill_v1':
            p.error('Not a V5 skill checkpoint')
        # The checkpoint defines the observation contract (variant); CLI settings may not override it.
        settings = from_mapping(saved['settings'])
    if args.policy == 'scripted' and not settings.use_raw_force:
        p.error('The scripted baseline needs the raw force history (main or no_latent settings)')
    args.output = args.output.resolve()
    if args.benchmark_report is None:
        args.benchmark_report = DEFAULT_ROOT/f'benchmark_{args.num_envs}/benchmark.json'
    return args, settings
