"""Deployable trigger / handback state machine, batched over environments.

Its only geometric input is the FK peg-tip height relative to the calibrated hole-top
plane, so the same object runs in the skill environment and end to end.
"""
import torch


class HandoverMachine:
    def __init__(self, count, settings, device='cpu'):
        self.cfg = settings
        self.active = torch.zeros(count, dtype=torch.bool, device=device)
        self.below = torch.zeros(count, dtype=torch.long, device=device)
        self.above = torch.zeros_like(self.below)
        self.steps = torch.zeros_like(self.below)
        self.takeovers = torch.zeros_like(self.below)

    def reset(self, ids):
        self.active[ids] = False
        for value in (self.below, self.above, self.steps, self.takeovers):
            value[ids] = 0

    def observe_approach(self, height, eligible):
        """Call once per 0.1 s tick while the VLA (or scripted approach) moves. Returns rows to hand over."""
        if height.shape != self.below.shape or eligible.shape != self.below.shape:
            raise ValueError('Trigger inputs must have one value per environment')
        waiting = eligible & ~self.active
        inside = height <= -self.cfg.trigger_depth_m
        self.below = torch.where(waiting & inside, self.below+1, torch.zeros_like(self.below))
        return waiting & (self.below >= self.cfg.trigger_confirm_steps) & (self.takeovers < self.cfg.max_takeovers)

    def start(self, mask):
        self.active |= mask
        self.steps[mask] = 0
        self.above[mask] = 0
        self.below[mask] = 0
        self.takeovers[mask] += 1

    def observe_skill(self, height):
        """Call once after every skill step. Returns (timeout, liftout) for active rows."""
        self.steps = torch.where(self.active, self.steps+1, self.steps)
        out = height > self.cfg.liftout_height_m
        self.above = torch.where(self.active & out, self.above+1, torch.zeros_like(self.above))
        timeout = self.active & (self.steps >= self.cfg.skill_steps)
        liftout = self.active & (self.above >= self.cfg.liftout_confirm_steps)
        return timeout, liftout

    def stop(self, mask):
        self.active &= ~mask
        self.above[mask] = 0
        self.below[mask] = 0

    def state_dict(self):
        return {k: getattr(self, k).clone() for k in ('active', 'below', 'above', 'steps', 'takeovers')}
