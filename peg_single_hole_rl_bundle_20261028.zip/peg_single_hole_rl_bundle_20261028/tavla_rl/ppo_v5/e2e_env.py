"""End-to-end V5 environment: the v6 fixed-backend TavlaRLEnv, unchanged, plus

* the deployable chamfer trigger (FK peg-tip height vs the calibrated hole-top plane),
* takeover by the RL (or scripted) skill through the SAME slew/servo path as TAVLA,
* handback to TAVLA on skill timeout or lift-out (fresh 8001 request), at most max_takeovers,
* optional capture of the full hand-over state for skill validation.

TAVLA is not queried while the skill owns the arm. Import only after AppLauncher.
"""
import json
import numpy as np
import torch
from tavla_rl.env import TavlaRLEnv
from . import observation as contract
from .cases import load_case_manifest, scripts_on_path
from .controller import PoseIntegrator, load_fk
from .geometry import matrix_quat, quat_matrix, tip_from_tcp, to_base
from .starts import STATE_FILE, STATE_FORMAT
from .trigger import HandoverMachine

scripts_on_path()
from peg_fixed_backend_env import FixedBackendRandomEnv  # noqa: E402


class V5HandoverEnv(FixedBackendRandomEnv):
    def __init__(self, cfg, **kwargs):
        # FixedBackendRandomEnv.__init__ only accepts the v6 manifest; keep its behaviour for V5 sets.
        self._reference = load_case_manifest(cfg.rl_eval_case_manifest)
        self._case = self._reference['cases'][cfg.rl_eval_case_id]
        self._initialization_only = False
        self._fixture_path = ''
        self.v5 = dict(cfg.v5_options)
        self._v5_ready = False
        TavlaRLEnv.__init__(self, cfg, **kwargs)
        s, d = self.v5['settings'], self.device
        self._v5_settings = s
        self._v5_fk = load_fk(d)
        self._v5_integrator = PoseIntegrator(1, s, d)
        self._v5_machine = HandoverMachine(1, s, d)
        self._v5_fields = contract.actor_fields(s)
        self._v5_mount = float(s.peg_mount_offset_m+float(self.cfg.pi0_peg_mount_depth_adjust_m))
        self._v5_ready = True
        self._v5_reset()

    # ------------------------------------------------------------------ state
    def _v5_reset(self):
        d = self.device
        self._v5_active = False
        self._v5_action = torch.zeros(1, 5, device=d)
        self._v5_previous_action = torch.zeros(1, 5, device=d)
        self._v5_handover_q = torch.zeros(1, 7, device=d)
        self._v5_handover_tcp = torch.zeros(1, 3, device=d)
        self._v5_handover_tip = torch.zeros(1, 3, device=d)
        self._v5_target_q = torch.zeros(1, 7, device=d)
        self._v5_skill_steps = 0
        self._v5_takeovers = []
        self._v5_handbacks = []
        self._v5_first_trigger = None
        self._v5_captured = None
        self._v5_trace = []
        self._v5_last = None
        self._v5_armed = True
        self._v5_integrator.reset([0])
        self._v5_machine.reset([0])

    def _reset_idx(self, env_ids):
        result = super()._reset_idx(env_ids)
        if getattr(self, '_v5_ready', False):
            self._v5_reset()
        return result

    @property
    def v5_active(self):
        return bool(getattr(self, '_v5_active', False))

    def v5_set_action(self, action):
        action = torch.as_tensor(action, device=self.device, dtype=torch.float32).reshape(1, 5)
        if not bool(torch.isfinite(action).all()):
            raise ValueError('Non-finite skill action')
        self._v5_action = action.clamp(-1., 1.)

    # ------------------------------------------------------------------ deployable geometry
    def _v5_base(self):
        base_pos = self._as_torch(self._robot.data.root_pos_w)-self.scene.env_origins
        return base_pos, quat_matrix(self._as_torch(self._robot.data.root_quat_w))

    def _v5_geometry(self):
        s = self._v5_settings
        p, r = self._v5_fk(self.joint_pos[:, :7].float())
        tip = tip_from_tcp(p, r, self._v5_mount)
        base_pos, base_rot = self._v5_base()
        # The fixture height is a calibrated constant (only hole XY is randomized); exact in simulation.
        hole = to_base(self.fixed_pos.float(), base_pos.float(), base_rot.float())
        height = tip[:, 2]-(hole[:, 2]+s.rim_height_m)+s.tip_height_correction_m
        return p, r, tip, height

    def _v5_force_history(self):
        s = self._v5_settings
        rows = self.runtime.force_rows
        forces = np.asarray([f for _, f in rows], np.float32).reshape(-1, 3)
        baseline = np.median(forces[:20], axis=0) if len(forces) >= 20 else np.zeros(3, np.float32)
        tared = forces[-s.force_history_steps:]-baseline
        if len(tared) < s.force_history_steps:
            tared = np.concatenate((np.zeros((s.force_history_steps-len(tared), 3), np.float32), tared))
        return torch.as_tensor(tared, device=self.device).reshape(1, -1), torch.as_tensor(baseline, device=self.device)

    def v5_observation(self):
        """The skill's actor observation, built exactly as in the skill environment."""
        s = self._v5_settings
        p, r, tip, height = self._v5_geometry()
        history, _ = self._v5_force_history()
        commanded = self._v5_integrator.commanded_tcp(self._v5_handover_tcp)
        values = dict(q=self.joint_pos[:, :7].float(), qd=self.joint_vel[:, :7].float(),
                      gripper=(self.joint_pos[:, 7:9].sum(-1, keepdim=True)/.08).clamp(0., 1.).float(),
                      command=self._teacher_command_target.float(), command_velocity=self._teacher_command_velocity.float(),
                      offset=self._v5_integrator.offset, tip_displacement=tip-self._v5_handover_tip,
                      height=height[:, None], gap=commanded-p, tilt=r[:, :, 2][:, :2], force_history=history,
                      latent=torch.as_tensor(self.runtime.latest_latent, device=self.device).reshape(1, -1).float(),
                      previous_action=self._v5_previous_action,
                      elapsed=torch.full((1, 1), self._v5_skill_steps*s.dt, device=self.device))
        return contract.build(values, self._v5_fields, s)

    # ------------------------------------------------------------------ decision hook
    def _prepare_decision(self):
        if not getattr(self, '_v5_ready', False) or self._contact is None:
            return super()._prepare_decision()
        if self.runtime.prepared_time is not None:
            return
        self._sample_force()
        p, r, tip, height = self._v5_geometry()
        self._v5_last = dict(height=float(height[0]), tip=tip[0].cpu().tolist())
        tick = round(self._sample_tick*.1, 9)
        if self._v5_active:
            timeout, liftout = self._v5_machine.observe_skill(height)
            if bool(timeout[0]) or bool(liftout[0]):
                self._v5_stop('timeout' if bool(timeout[0]) else 'liftout', height)
            else:
                self.runtime.prepared_time = tick  # skill decision: TAVLA is not queried
                return
        else:
            # After a handback the peg must first leave the hole (re-approach) before a new takeover.
            if not self._v5_armed and float(height[0]) > self._v5_settings.liftout_height_m:
                self._v5_armed = True
            eligible = torch.full((1,), self._v5_armed, dtype=torch.bool, device=self.device)
            fire = self._v5_machine.observe_approach(height, eligible)
            if bool(fire[0]):
                self._v5_on_trigger(p, tip, height)
                if self.v5['arm'] in ('rl', 'scripted'):
                    self._v5_start(tip)
                    self.runtime.prepared_time = tick
                    return
        super()._prepare_decision()

    def _v5_on_trigger(self, p, tip, height):
        xy, z = self._geometry()
        event = dict(time_s=self._episode_steps*.1, height_mm=float(height[0])*1e3, xy_true_mm=xy*1e3, z_true_mm=z*1e3)
        if self._v5_first_trigger is None:
            self._v5_first_trigger = event
            if self.v5.get('capture'):
                self._v5_capture(height)
        self._v5_machine.stop(torch.ones(1, dtype=torch.bool, device=self.device))

    def _v5_start(self, tip):
        self._v5_active = True
        self._v5_machine.start(torch.ones(1, dtype=torch.bool, device=self.device))
        self._v5_handover_q = self._teacher_command_target[:, :7].clone().float()
        self._v5_handover_tcp = self._v5_fk(self._v5_handover_q)[0]
        self._v5_handover_tip = tip.clone()
        self._v5_target_q = self._v5_handover_q.clone()
        self._v5_integrator.reset([0])
        self._v5_previous_action.zero_()
        self._v5_action.zero_()
        self._v5_skill_steps = 0
        self._v5_takeovers.append(dict(time_s=self._episode_steps*.1, z_true_mm=self._geometry()[1]*1e3))

    def _v5_stop(self, reason, height):
        self._v5_active = False
        self._v5_armed = False
        self._v5_machine.stop(torch.ones(1, dtype=torch.bool, device=self.device))
        self._v5_handbacks.append(dict(time_s=self._episode_steps*.1, reason=reason, height_mm=float(height[0])*1e3,
                                       z_true_mm=self._geometry()[1]*1e3, skill_steps=self._v5_skill_steps))
        # Hand back with a fresh TAVLA request from the current images, state and force history.
        self.runtime.chunk = None
        self.runtime.index = 1
        self.runtime.chunk_steps = 0

    # ------------------------------------------------------------------ action hook
    def _pre_physics_step(self, action):
        if not self.v5_active:
            return super()._pre_physics_step(action)
        if self.runtime.prepared_time is None:
            raise RuntimeError('Skill decision must be prepared before env.step')
        lower, upper = self._joint_limits()
        lower, upper = self._as_torch(lower)[:, :7].float(), self._as_torch(upper)[:, :7].float()
        measured, _ = self._v5_fk(self.joint_pos[:, :7].float())
        valid = torch.ones(1, dtype=torch.bool, device=self.device)
        proposed = self._v5_integrator.propose(self._v5_action, valid, self._v5_handover_tcp, measured)
        q, accepted = self._v5_fk.ik(self._v5_handover_q, proposed, lower, upper)
        if self._pending_guard:
            accepted = torch.zeros_like(accepted)
            q = self._teacher_command_target[:, :7].float()
        self._v5_integrator.commit(accepted)
        self._v5_target_q = torch.where(accepted[:, None], q, self._v5_target_q)
        target = self.teacher_target.clone()
        target[:, :7] = self._v5_target_q.to(target.dtype)
        self.teacher_target = target
        self.residual_action.zero_()
        self.actions.zero_()
        self._last_slew_previous = self._np(self._teacher_command_target)[0]
        self._last_slew_velocity = self._np(self._teacher_command_velocity)[0]
        self._last_ik_target = self._np(self._v5_target_q)[0].astype(np.float64)
        self.combined_joint_target = self._smooth_teacher_target(target)
        self.next_action = self.combined_joint_target.clone()
        self._last_residual = np.zeros(3, np.float32)
        self._ik = None
        xy, z = self._geometry()
        self._v5_trace.append(dict(time_s=self._episode_steps*.1, action=self._np(self._v5_action)[0],
                                   offset=self._np(self._v5_integrator.offset)[0], accepted=bool(accepted[0]),
                                   height_m=self._v5_last['height'] if self._v5_last else np.nan,
                                   xy_true_m=xy, z_true_m=z))
        self._v5_previous_action = self._v5_action.clone()
        self._v5_skill_steps += 1

    # ------------------------------------------------------------------ capture and summary
    def _v5_capture(self, height):
        base_pos, base_rot = self._v5_base()
        base_pos, base_rot = base_pos.float(), base_rot.float()
        rt = base_rot.transpose(-1, -2)
        held_r = rt@quat_matrix(self.held_quat.float())
        fixed_r = rt@quat_matrix(self.fixed_quat.float())
        lin = getattr(self._held_asset.data, 'root_lin_vel_w', None)
        ang = getattr(self._held_asset.data, 'root_ang_vel_w', None)
        lin = self._as_torch(lin).float() if lin is not None else torch.zeros(1, 3, device=self.device)
        ang = self._as_torch(ang).float() if ang is not None else torch.zeros(1, 3, device=self.device)
        xy, z = self._geometry()
        forces = np.asarray([f for _, f in self.runtime.force_rows], np.float32).reshape(-1, 3)
        times = np.asarray([t for t, _ in self.runtime.force_rows], np.float64)
        meta = dict(format=STATE_FORMAT, case_id=int(self._case['case_id']), split=self._case['split'],
                    set=self.v5.get('set_name'), manifest_id=self._reference['manifest_id'], arm=self.v5['arm'],
                    time_s=self._episode_steps*.1, height_estimate_m=float(height[0]), z_true_m=z, xy_true_m=xy,
                    mount_m=self._v5_mount, base_pos=base_pos[0].cpu().tolist())
        arrays = dict(q=self._np(self.joint_pos)[0], qd=self._np(self.joint_vel)[0],
                      held_pos_b=self._np(to_base(self.held_pos.float(), base_pos, base_rot))[0],
                      held_quat_b=self._np(matrix_quat(held_r))[0],
                      held_lin_vel_b=self._np((rt@lin[..., None]).squeeze(-1))[0],
                      held_ang_vel_b=self._np((rt@ang[..., None]).squeeze(-1))[0],
                      fixed_pos_b=self._np(to_base(self.fixed_pos.float(), base_pos, base_rot))[0],
                      fixed_quat_b=self._np(matrix_quat(fixed_r))[0],
                      command=self._np(self._teacher_command_target)[0, :7],
                      command_velocity=self._np(self._teacher_command_velocity)[0, :7],
                      forces=forces, force_times=times)
        path = self.output/STATE_FILE
        np.savez_compressed(path, meta=np.asarray(json.dumps(meta)), **arrays)
        self._v5_captured = str(path)

    def _finish_episode(self, success, timed_out, xy, z):
        super()._finish_episode(success, timed_out, xy, z)
        summary = self._last_summary
        summary['v5'] = dict(arm=self.v5['arm'], set=self.v5.get('set_name'), takeovers=len(self._v5_takeovers),
                             takeover_events=self._v5_takeovers, handbacks=self._v5_handbacks,
                             first_trigger_s=None if self._v5_first_trigger is None else self._v5_first_trigger['time_s'],
                             first_trigger=self._v5_first_trigger, skill_active_at_end=self.v5_active,
                             captured_state=self._v5_captured)
        if self._v5_trace:
            keys = self._v5_trace[0].keys()
            np.savez_compressed(self.output/'v5_trace.npz', **{k: np.asarray([r[k] for r in self._v5_trace]) for k in keys})
