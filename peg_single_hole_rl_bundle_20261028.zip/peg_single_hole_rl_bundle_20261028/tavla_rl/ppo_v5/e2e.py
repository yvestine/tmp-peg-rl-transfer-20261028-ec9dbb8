"""V5 end-to-end evaluation: TAVLA (8001) approach + chamfer-triggered skill takeover.

  python -m tavla_rl.ppo_v5.e2e run --sets validation40 --arms vla --capture-states --output-root ...
  python -m tavla_rl.ppo_v5.e2e run --sets original50 new50 --arms vla rl --checkpoint best.pth --output-root ...
  python -m tavla_rl.ppo_v5.e2e summarize <output-root> --skill-comparison comparison.json

`run` starts one fresh Isaac process per case (`worker`), keeps Kit output in the terminal (tmux),
skips completed cases and refuses to mix code, settings or checkpoints inside one output root.
The worker reuses the v6 episode protocol (fixed backend, 60 s, seed 42, zero raw torque).
"""
import argparse
from functools import partial
import json
import os
from pathlib import Path
import subprocess
import sys
import time
from .cases import default_paths, load_case_manifest, scripts_on_path
from .settings import ROOT, atomic_json, e2e_sources, file_sha256, from_mapping, load_settings, read_json, to_jsonable

DEFAULT_PYTHON = Path('/home/gujiawei/env_isaaclab/bin/python')
ARMS = ('vla', 'rl', 'scripted')


# ---------------------------------------------------------------------- worker (one case)
def worker_parser(launcher=None):
    from tavla_rl.cli import build_parser
    p = build_parser('eval', launcher)
    p.set_defaults(policy='zero', repeats=1, physics_mode='fixed', progress_seconds=15., raw_torque_mode='zero',
                   hole_static_friction=None)
    p.add_argument('--manifest', type=Path, required=True)
    p.add_argument('--case-id', type=int, required=True)
    p.add_argument('--arm', choices=ARMS, required=True)
    p.add_argument('--set-name', required=True)
    p.add_argument('--skill-checkpoint', type=Path)
    p.add_argument('--v5-settings', type=Path)
    p.add_argument('--capture-states', action='store_true')
    return p


def skill_settings(args):
    if args.arm == 'rl':
        import torch
        saved = torch.load(args.skill_checkpoint, map_location='cpu', weights_only=False)
        if saved.get('format') != 'tavla_v5_skill_v1':
            raise ValueError('--skill-checkpoint is not a V5 skill checkpoint')
        return from_mapping(saved['settings'])
    return load_settings(args.v5_settings)


def expected_hole_override(manifest):
    # The historical Factory final pass yields dynamic 0.75 without an override (v6 protocol).
    return .75 if manifest['config'].get('hole_dynamic_friction', .25) == .25 else None


def worker_main(argv):
    preliminary = worker_parser().parse_args(argv)
    manifest = load_case_manifest(preliminary.manifest)
    if not 0 <= preliminary.case_id < len(manifest['cases']):
        raise ValueError('Case id out of range')
    if (preliminary.task != 'peg_insert' or preliminary.policy != 'zero' or preliminary.repeats != 1
            or preliminary.physics_mode != 'fixed' or preliminary.seconds != 60. or preliminary.raw_torque_mode != 'zero'
            or preliminary.hole_static_friction != expected_hole_override(manifest) or preliminary.checkpoint
            or preliminary.image_input or preliminary.teacher_trace or preliminary.port != 8001):
        raise ValueError('The V5 worker keeps the frozen v6 fixed-backend episode protocol')
    if (preliminary.arm == 'rl') != bool(preliminary.skill_checkpoint):
        raise ValueError('--skill-checkpoint is required for, and only for, the rl arm')
    if preliminary.output is None:
        raise ValueError('--output is required')
    settings = skill_settings(preliminary)
    case = manifest['cases'][preliminary.case_id]
    import torch
    torch.manual_seed(preliminary.seed)
    from isaaclab.app import AppLauncher
    args = worker_parser(AppLauncher).parse_args(argv)
    args.command, args.enable_cameras = 'eval', True
    args.profiles = [case['source_profile']]
    args.eval_case_manifest, args.eval_case_id = str(args.manifest.resolve()), args.case_id
    from tavla_rl.experiment import prepare_output
    prepare_output(args.output)
    app = None
    try:
        app = AppLauncher(args).app
        import tavla_rl.env as backend
        import tavla_rl.env_cfg as configurations
        scripts_on_path()
        from peg_fixed_backend import ReferenceTeacherRuntime
        from .e2e_env import V5HandoverEnv
        backend.TavlaRLEnv = V5HandoverEnv  # process-local binding, exactly as the v6 episode worker
        backend.TeacherRuntime = partial(ReferenceTeacherRuntime, variant='full')
        original_config = configurations.make_config

        def configure(options):
            cfg = original_config(options)
            cfg.fixed_backend_initialization_only = False
            cfg.fixed_backend_fixture = ''
            cfg.v5_options = dict(arm=args.arm, settings=settings, capture=args.capture_states, set_name=args.set_name)
            return cfg
        configurations.make_config = configure
        from tavla_rl.experiment import load_ppo_config, simulation_environment, write_manifest
        write_manifest(args, load_ppo_config(args))
        with simulation_environment(args) as env:
            actor = make_actor(args, settings, env)
            env.reset(seed=args.seed)
            for step in range(600):
                if env.v5_active:
                    env.v5_set_action(actor(env.v5_observation()))
                _, _, done, timeout, _ = env.step(torch.zeros((1, 3), device=env.device))
                atomic_json(env.output/'progress.json', dict(steps=step+1, formal_seconds=(step+1)*.1,
                                                             skill_active=env.v5_active))
                if bool((done | timeout)[0]):
                    break
            else:
                raise RuntimeError('Episode did not terminate at 60 formal seconds')
            row = env._last_summary
            env.runtime.save_policy_trace(env.output/'policy_force_trace.npz')
            atomic_json(env.output/'result.json', dict(
                status='COMPLETE', result=row, case_id=args.case_id, set=args.set_name, arm=args.arm,
                manifest_id=manifest['manifest_id'], settings=to_jsonable(settings),
                skill_checkpoint=str(args.skill_checkpoint) if args.skill_checkpoint else None,
                skill_checkpoint_sha256=file_sha256(args.skill_checkpoint) if args.skill_checkpoint else None,
                server_metadata=getattr(env.client, 'server_metadata', None)))
    except BaseException as error:
        atomic_json(Path(args.output)/'failure.json', dict(error=f'{type(error).__name__}: {error}'))
        raise
    finally:
        if app is not None:
            app.close()


def make_actor(args, settings, env):
    import torch
    if args.arm == 'rl':
        from .policy import load_policy
        policy, trained, _ = load_policy(args.skill_checkpoint, env.device)
        return lambda obs: policy.deterministic(obs)
    if args.arm == 'scripted':
        from .policy import ScriptedInsertion
        scripted = ScriptedInsertion(1, settings, env.device)
        return lambda obs: scripted(obs)
    return lambda obs: torch.zeros(1, 5, device=env.device)


# ---------------------------------------------------------------------- runner
def suite_identity(args, manifests, settings):
    return json.loads(json.dumps(dict(
        sets={name: manifest['manifest_id'] for name, manifest in manifests.items()}, arms=list(args.arms),
        settings=to_jsonable(settings), sources=e2e_sources(), host=args.host,
        checkpoint=str(args.checkpoint) if args.checkpoint else None,
        checkpoint_sha256=file_sha256(args.checkpoint) if args.checkpoint else None,
        capture_states=args.capture_states, python=str(args.python)), default=str))


def worker_command(args, set_name, manifest_path, manifest, arm, case_id, directory):
    command = [str(args.python), '-u', '-B', '-m', 'tavla_rl.ppo_v5.e2e', 'worker',
               '--manifest', str(manifest_path), '--case-id', str(case_id), '--arm', arm, '--set-name', set_name,
               '--output', str(directory), '--host', args.host, '--port', '8001', '--seed', '42', '--seconds', '60',
               '--physics-mode', 'fixed', '--raw-torque-mode', 'zero', '--device', args.device, '--headless',
               '--enable_cameras']
    override = expected_hole_override(manifest)
    if override is not None:
        command += ['--hole-static-friction', str(override)]
    if arm == 'rl':
        command += ['--skill-checkpoint', str(args.checkpoint.resolve())]
    if args.v5_settings:
        command += ['--v5-settings', str(args.v5_settings.resolve())]
    if args.capture_states:
        command.append('--capture-states')
    return command


def run_main(argv):
    p = argparse.ArgumentParser(description='Run V5 end-to-end cases (one Isaac process per case)')
    p.add_argument('--sets', nargs='+', choices=sorted(default_paths()), required=True)
    p.add_argument('--arms', nargs='+', choices=ARMS, required=True)
    p.add_argument('--output-root', type=Path, required=True)
    p.add_argument('--checkpoint', type=Path, help='Skill checkpoint for the rl arm')
    p.add_argument('--v5-settings', type=Path, help='Settings for vla/scripted arms (default config.json)')
    p.add_argument('--cases', type=int, nargs='+', help='Subset of case ids (default: all)')
    p.add_argument('--capture-states', action='store_true', help='Save handover_state.npz at the first trigger')
    p.add_argument('--host', default=os.environ.get('TAVLA_HOST', '114.214.164.36'))
    p.add_argument('--device', default='cuda:0')
    p.add_argument('--python', type=Path, default=DEFAULT_PYTHON)
    p.add_argument('--dry-run', action='store_true', help='Print commands only; no Isaac, network or writes')
    args = p.parse_args(argv)
    if 'rl' in args.arms and not (args.checkpoint and args.checkpoint.is_file()):
        p.error('The rl arm needs an existing --checkpoint')
    if args.capture_states and any(load_case_manifest(default_paths()[s])['cases'][0]['split'] == 'test'
                                   for s in args.sets):
        print('[V5 e2e] note: states captured on test sets are for analysis only; skill validation rejects them',
              flush=True)
    paths = {s: default_paths()[s] for s in args.sets}
    manifests = {s: load_case_manifest(path) for s, path in paths.items()}
    if args.checkpoint:
        import torch
        settings = from_mapping(torch.load(args.checkpoint, map_location='cpu', weights_only=False)['settings'])
    else:
        settings = load_settings(args.v5_settings)
    root = args.output_root.resolve()
    identity = suite_identity(args, manifests, settings)
    if args.dry_run:
        for s in args.sets:
            for arm in args.arms:
                for case in manifests[s]['cases'][:2]:
                    print(' '.join(worker_command(args, s, paths[s], manifests[s], arm, case['case_id'],
                                                  root/s/arm/f"case_{case['case_id']:04d}/attempt_000")))
        return
    saved = root/'suite.json'
    if saved.exists() and read_json(saved) != identity:
        raise ValueError(f'{root} holds a different V5 suite (code, settings, checkpoint or arms); use a new root')
    root.mkdir(parents=True, exist_ok=True)
    atomic_json(saved, identity)
    for set_name in args.sets:
        cases = [c['case_id'] for c in manifests[set_name]['cases']]
        selected = [c for c in cases if args.cases is None or c in args.cases]
        for arm in args.arms:
            done = 0
            for number, case_id in enumerate(selected, 1):
                directory = root/set_name/arm/f'case_{case_id:04d}'
                result = directory/'result.json'
                if result.exists() and read_json(result).get('status') == 'COMPLETE':
                    done += 1
                    continue
                directory.mkdir(parents=True, exist_ok=True)
                index = 0
                while (directory/f'attempt_{index:03d}').exists():
                    index += 1
                attempt = directory/f'attempt_{index:03d}'
                print(f'[V5 e2e] {set_name}/{arm}: case {number}/{len(selected)} (id={case_id}); completed {done}',
                      flush=True)
                started = time.monotonic()
                process = subprocess.run(worker_command(args, set_name, paths[set_name], manifests[set_name], arm,
                                                        case_id, attempt), cwd=ROOT,
                                         env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1'))
                if process.returncode != 0 or not (attempt/'result.json').exists() or (attempt/'failure.json').exists():
                    raise RuntimeError(f'{set_name}/{arm}/case {case_id} failed; inspect the traceback and {attempt}')
                value = read_json(attempt/'result.json')
                value['attempt'] = str(attempt)
                value['wall_seconds'] = time.monotonic()-started
                atomic_json(result, value)
                done += 1
                row = value['result']
                print(f"[V5 e2e] {set_name}/{arm} case {case_id}: success={row['success']} "
                      f"takeovers={row['v5']['takeovers']} wall={value['wall_seconds']:.0f}s", flush=True)


def main():
    if len(sys.argv) < 2 or sys.argv[1] not in ('worker', 'run', 'summarize'):
        raise SystemExit('usage: python -m tavla_rl.ppo_v5.e2e {worker,run,summarize} ...')
    command, argv = sys.argv[1], sys.argv[2:]
    if command == 'worker':
        worker_main(argv)
    elif command == 'run':
        run_main(argv)
    else:
        from .analysis import main as summarize
        sys.argv = [sys.argv[0]]+argv
        summarize()


if __name__ == '__main__':
    main()
