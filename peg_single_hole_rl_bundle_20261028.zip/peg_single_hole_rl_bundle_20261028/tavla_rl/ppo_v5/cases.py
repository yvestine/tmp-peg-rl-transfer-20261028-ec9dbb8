"""Frozen case manifests for the V5 end-to-end evaluation (CPU only).

original50    the v6 manifest outputs/peg_three_models_v6/test_cases.json, unchanged (historical regression)
new50         same generator, physics and visuals; new test seeds 17201-17205 (the unseen test set)
validation40  same generator; seeds 17301-17305. Only these cases may feed recorded hand-over
              states into skill validation or tuning.
"""
import copy
import sys
from pathlib import Path
from .settings import ROOT, atomic_json, digest, file_sha256, read_json

V6_MANIFEST = ROOT/'outputs/peg_three_models_v6/test_cases.json'
CASE_ROOT = ROOT/'outputs/tavla_rl/ppo_v5/cases'
SETS = dict(new50=dict(split='test', count=50, seeds=(17201, 17202, 17203, 17204, 17205)),
            validation40=dict(split='validation', count=40, seeds=(17301, 17302, 17303, 17304, 17305)))
USED_SEEDS = {17001, 17002, 17003, 17004, 17005, 17101, 17102, 17103, 17104, 17105}
REQUIRED = dict(backend='tavla_rl.env.TavlaRLEnv', physics_mode='fixed', formal_seconds=60., startup_seconds=2.,
                visual_reference_profile=0, raw_torque_mode='zero', hole_static_friction=.75)
CASE_KEYS = ('case_id', 'split', 'source_profile', 'source_hole_position_m', 'hole_position_m', 'hole_quat_xyzw',
             'arm_joint_pos_rad', 'initial_joint_pos_rad', 'physics_seed')


def default_paths():
    return dict(original50=V6_MANIFEST, new50=CASE_ROOT/'new50.json', validation40=CASE_ROOT/'validation40.json')


def scripts_on_path():
    path = str(ROOT/'scripts')
    if path not in sys.path:
        sys.path.insert(0, path)


def load_case_manifest(path):
    value = read_json(path)
    content = {k: v for k, v in value.items() if k != 'manifest_id'}
    if digest(content) != value.get('manifest_id'):
        raise ValueError(f'Case manifest checksum mismatch: {path}')
    config = value['config']
    if any(config.get(k) != v for k, v in REQUIRED.items()):
        raise ValueError(f'{path} does not use the historical fixed-backend protocol')
    if file_sha256(ROOT/'sim-data-aligned/traj_0/replay_metadata.json') != value['visual_reference_sha256']:
        raise ValueError('Frozen visual calibration changed')
    for index, expected in value['source_metadata_sha256'].items():
        if file_sha256(ROOT/f'sim-data-aligned/traj_{int(index)}/replay_metadata.json') != expected:
            raise ValueError(f'Recorded hole metadata changed for profile {index}')
    cases = value['cases']
    if [c['case_id'] for c in cases] != list(range(len(cases))):
        raise ValueError('Case IDs must be ordered 0..n-1')
    for case in cases:
        if any(k not in case for k in CASE_KEYS):
            raise ValueError(f'Case {case.get("case_id")} misses required fields')
    return value


def make_manifest(name):
    """Regenerate a V5 case set with the unchanged v6 generator and new seeds."""
    if name not in SETS:
        raise ValueError(f'Unknown V5 case set {name}')
    spec = SETS[name]
    if set(spec['seeds']) & USED_SEEDS:
        raise ValueError('New case seeds must not reuse v6 test or development seeds')
    scripts_on_path()
    from peg_random_eval_common import generate_manifest
    base = load_case_manifest(V6_MANIFEST)
    geometry_path = ROOT/'configs/peg_position_only_eval.json'
    geometry = read_json(geometry_path)
    geometry['physics_seed'] = 42  # as the v6 manifest
    key = 'test' if spec['split'] == 'test' else 'dev'
    other = 'dev' if key == 'test' else 'test'
    geometry[f'{key}_seeds'] = list(spec['seeds'])
    geometry[f'{other}_seeds'] = [seed+1000 for seed in spec['seeds']]  # unused; must only be disjoint
    sampled = generate_manifest(geometry, key, spec['count'])
    cases = sampled['cases']
    for case in cases:
        case['visual_seed'] = 0
        case['initial_joint_pos_rad'] = case['arm_joint_pos_rad']
        case['split'] = spec['split']
    v6_holes = {tuple(round(v, 9) for v in c['hole_position_m']) for c in base['cases']}
    if any(tuple(round(v, 9) for v in c['hole_position_m']) in v6_holes for c in cases):
        raise ValueError('A new case repeats a v6 hole position')
    config = copy.deepcopy(base['config'])
    config['note'] = (config.get('note', '')+' V5: same generator/physics/visuals as the v6 50 cases; '
                      f'set {name}, seeds {list(spec["seeds"])}.')
    value = dict(version=1, config=config, cases=cases, visual_reference=base['visual_reference'],
                 visual_reference_sha256=base['visual_reference_sha256'],
                 source_metadata_sha256=base['source_metadata_sha256'],
                 v5=dict(name=name, split=spec['split'], seeds=list(spec['seeds']), base_manifest_id=base['manifest_id'],
                         generator='scripts/peg_random_eval_common.generate_manifest (recorded_arm_random_hole_xy)',
                         geometry_config_sha256=file_sha256(geometry_path)))
    value['manifest_id'] = digest(value)
    return value


def write_manifests(root=CASE_ROOT):
    root = Path(root)
    written = {}
    for name in SETS:
        value = make_manifest(name)
        path = root/f'{name}.json'
        if path.exists():
            existing = read_json(path)
            if existing != value:
                raise FileExistsError(f'{path} exists with different content; frozen manifests are never rewritten')
        else:
            atomic_json(path, value)
        load_case_manifest(path)
        written[name] = dict(path=str(path), manifest_id=value['manifest_id'], cases=len(value['cases']))
    return written
