"""One camera-free Isaac process. Long runs are launched by the resource watchdog."""
import argparse
from contextlib import contextmanager
import json
import os
from pathlib import Path
import random
import signal
import tempfile
import time
import numpy as np
import torch
from tavla_rl.ppo_v5.settings import ROOT, atomic_json, to_jsonable, from_mapping
from .config import FORMAT, KINDS, settings, sources


def parser():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('mode', choices=['benchmark', 'train', 'validate'])
    p.add_argument('--kind', choices=KINDS, required=True)
    p.add_argument('--bank', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--num-envs', type=int, default=128)
    p.add_argument('--device', default='cuda:0')
    p.add_argument('--seed', type=int, default=61022)
    p.add_argument('--seconds', type=float, default=7200)
    p.add_argument('--benchmark-steps', type=int, default=100)
    p.add_argument('--benchmark-report', type=Path)
    p.add_argument('--validation-every', type=float, default=1200)
    p.add_argument('--validation-count', type=int, default=64)
    p.add_argument('--v5-init', type=Path)
    p.add_argument('--resume', type=Path)
    p.add_argument('--checkpoint', type=Path)
    return p


@contextmanager
def environment(args, s, sampler, noise, bank):
    from pxr import Usd, UsdGeom
    from .environment import VectorFusionEnv
    old = os.environ.get('TACEX_BACKGROUND_USD')
    fd, name = tempfile.mkstemp(prefix='tavla_fusion_', suffix='.usd')
    os.close(fd)
    env = None
    try:
        stage = Usd.Stage.CreateNew(name)
        root = UsdGeom.Xform.Define(stage, '/World')
        root.GetPrim().GetReferences().AddReference(str(ROOT/'franka_env_background_edit/franka_env.usd'), '/World')
        stage.SetDefaultPrim(root.GetPrim())
        stage.OverridePrim('/World/PhysicsScene').SetActive(False)
        stage.GetRootLayer().Save()
        os.environ['TACEX_BACKGROUND_USD'] = name
        env = VectorFusionEnv(args, s, sampler, noise, bank)
        yield env
    finally:
        if env is not None:
            env.close()
        if old is None:
            os.environ.pop('TACEX_BACKGROUND_USD', None)
        else:
            os.environ['TACEX_BACKGROUND_USD'] = old
        Path(name).unlink(missing_ok=True)


def validation_starts(bank, distribution, s, count):
    from tavla_rl.ppo_v5.starts import sample_start
    rng = np.random.default_rng(9161022)
    available = bank.sources('validation')
    starts = []
    for i in range(count):
        # Fixed mix of easy and hard conditions; all methods get the same set.
        source = [available[i%len(available)]]
        row = sample_start(rng, distribution, s, source, level=(i%4)/3, mode='train')
        row.update(mode='validation', start_id=i, noise_scale=0., latency=False)
        starts.append(row)
    return starts


def evaluate(env, actor, starts, deadline):
    from tavla_rl.ppo_v5.validation import run_fixed, summarize
    state = env.noise.generator.get_state()
    try:
        env.noise.generator.manual_seed(9161022)
        rows, missing = run_fixed(env, actor, starts, label='fusion_validation', deadline=deadline)
    finally:
        env.noise.generator.set_state(state)
    summary = summarize('held-out recorded-reference insertion', rows, missing)
    summary['planned'] = len(starts)
    summary['success_rate_all_starts'] = summary['successes']/len(starts)
    summary['not_end_to_end'] = True
    return summary, rows, missing


def comparison(baseline, result):
    b = {r['item_id']:r['success'] for r in baseline[1]}
    r = {row['item_id']:row['success'] for row in result[1]}
    # Never-triggered / failed placements count as failures in both arms.
    ids = range(baseline[0]['planned'])
    rescued = [i for i in ids if r.get(i, False) and not b.get(i, False)]
    regressed = [i for i in ids if b.get(i, False) and not r.get(i, False)]
    return dict(rescued=rescued, regressed=regressed, net_gain=len(rescued)-len(regressed),
                baseline=baseline[0], learned=result[0],
                interpretation='Paired local insertion with recorded references; live VLA improvement remains untested')


def run(args, deadline):
    from .reference import ReferenceBank
    from .learning import Policy, Selector, warm_actor
    from tavla_rl.ppo_v5.learner import PPO
    from tavla_rl.ppo_v5.noise import NoiseModel
    from tavla_rl.ppo_v5.starts import HandoverDistribution, StartSampler, Curriculum
    s = settings()
    bank = ReferenceBank(args.bank, args.device)
    distribution = HandoverDistribution.load(args.bank/'distribution.json')
    noise = NoiseModel.load(args.bank/'noise.json')
    sampler = StartSampler(args.seed, distribution, s, bank.sources('train'), Curriculum(s, .25))
    torch.set_num_threads(1)
    torch.manual_seed(args.seed)
    np.random.seed(args.seed)
    random.seed(args.seed)
    identity = dict(format=FORMAT, kind=args.kind, sources=sources(), settings=to_jsonable(s),
                    bank_sha256=bank.meta['bank_sha256'], bank_inputs=bank.meta['inputs_sha256'], num_envs=args.num_envs)
    atomic_json(args.output/'identity.json', identity)
    with environment(args, s, sampler, noise, bank) as env:
        if args.mode == 'benchmark':
            action = (torch.zeros(env.num_envs, device=env.device, dtype=torch.long) if args.kind == 'selector'
                      else torch.zeros(env.num_envs, 5, device=env.device))
            warm = 0
            while int(env.observe()['valid'].sum()) < max(1, args.num_envs//2) and warm < 400:
                env.step(action)
                warm += 1
                if time.monotonic() > deadline:
                    raise TimeoutError('Benchmark startup budget exceeded')
            if not bool(env.observe()['valid'].any()):
                raise RuntimeError('No training environments reached contact')
            before = [x[1:].clone() for x in (env.joint_pos, env.command, env.steps, env.phase, env.history,
                       env.reference_ids, env.integrator.residual)]
            env.reset_ids([0])
            after = [x[1:] for x in (env.joint_pos, env.command, env.steps, env.phase, env.history,
                      env.reference_ids, env.integrator.residual)]
            isolated = all(torch.equal(a,b) for a,b in zip(before, after))
            if not isolated:
                raise RuntimeError('Reset of env 0 changed a neighbouring environment')
            started, initial = time.monotonic(), env.skill_samples
            for _ in range(args.benchmark_steps):
                env.step(action)
                if time.monotonic() > deadline:
                    raise TimeoutError('Benchmark budget exceeded')
            rate = (env.skill_samples-initial)/max(1e-6, time.monotonic()-started)
            report = dict(identity, status='PASS' if rate >= s.minimum_steps_per_second else 'FAIL',
                          reset_isolation=isolated, skill_steps_per_second=rate, progress=env.progress(),
                          cameras=False, renderer_requested=False)
            atomic_json(args.output/'benchmark.json', report)
            if report['status'] != 'PASS':
                raise RuntimeError(f'Throughput too low: {rate:.1f} skill steps/s')
            return
        validation_reserve = 180.
        if args.mode == 'train':
            proof = json.loads(args.benchmark_report.read_text())
            if proof.get('status') != 'PASS' or not proof.get('reset_isolation') or any(proof.get(k) != v for k,v in identity.items()):
                raise ValueError('No matching successful camera-free benchmark')
            validation_reserve = max(180., 3*args.validation_count*s.skill_steps/proof['skill_steps_per_second']+120)
        selector = args.kind == 'selector'
        learner = Selector(env.actor_dim, args.device) if selector else None
        policy = None if selector else Policy(env.actor_dim, env.critic_dim, s).to(args.device)
        ppo = None if selector else PPO(policy, s)
        transferred = []
        steps, episodes, successes, best, validations = 0, 0, 0, None, []
        checkpoint = args.resume or args.checkpoint
        if checkpoint:
            saved = torch.load(checkpoint, map_location=args.device, weights_only=False)
            for k in ('format','kind','sources','settings','bank_sha256','bank_inputs'):
                if saved.get(k) != identity[k]:
                    raise ValueError(f'Checkpoint identity differs: {k}')
            if selector:
                learner.load_state_dict(saved['learner'])
            else:
                ppo.load_state_dict(saved['learner'])
            steps, episodes, successes = saved['steps'], saved['episodes'], saved['successes']
            best, validations = saved.get('best'), saved.get('validations', [])
            if args.resume:
                sampler.load_state_dict(saved['sampler'])
                torch.set_rng_state(saved['torch_rng'].cpu())
                torch.cuda.set_rng_state_all([x.cpu() for x in saved['cuda_rng']])
                np.random.set_state(saved['numpy_rng'])
                random.setstate(saved['python_rng'])
                env.set_sampler(sampler)
        elif args.v5_init and args.kind == 'residual':
            transferred = warm_actor(policy, args.v5_init)
        actor = ((lambda obs:learner.act(obs['actor'])) if selector else
                 (lambda obs:policy.deterministic(obs['actor'])))
        starts = validation_starts(bank, distribution, s, args.validation_count)

        def save(name):
            value = dict(identity, learner=learner.state_dict() if selector else ppo.state_dict(),
                         steps=steps, episodes=episodes, successes=successes, sampler=sampler.state_dict(),
                         best=best, validations=validations, transferred_hidden_layers=transferred,
                         actor_dim=env.actor_dim, critic_dim=env.critic_dim,
                         torch_rng=torch.get_rng_state(), cuda_rng=torch.cuda.get_rng_state_all(),
                         numpy_rng=np.random.get_state(), python_rng=random.getstate())
            path = args.output/'checkpoints'/name
            path.parent.mkdir(exist_ok=True)
            temporary = path.with_suffix('.tmp.pth')
            torch.save(value, temporary)
            temporary.replace(path)

        stop_requested = [False]
        old_handlers = {}
        if args.mode == 'train':
            for sig in (signal.SIGTERM, signal.SIGINT):
                old_handlers[sig] = signal.signal(sig, lambda *_:stop_requested.__setitem__(0, True))
        try:
            if args.mode == 'train':
                save('last.pth')
            env.integrator.nominal_only = True
            baseline = evaluate(env, actor, starts, deadline)
            env.integrator.nominal_only = False
            atomic_json(args.output/'nominal_validation.json', dict(summary=baseline[0], episodes=baseline[1], not_triggered=baseline[2]))
            if args.mode == 'validate':
                result = evaluate(env, actor, starts, deadline)
                atomic_json(args.output/'comparison.json', comparison(baseline, result))
                return
            # Keep the unmodified reference as an eligible checkpoint for fresh
            # residual/selector runs; training must earn its improvement.
            initial = (evaluate(env, actor, starts, deadline)
                       if args.kind == 'admittance' or checkpoint else baseline)
            initial_item = dict(steps=steps, initialization=True, **comparison(baseline, initial))
            validations.append(initial_item)
            initial_score = (initial[0]['success_rate_all_starts'], -len(initial_item['regressed']),
                             -(initial[0]['mean_peak_force_n'] or 0))
            if best is None or tuple(best['score']) < initial_score:
                best = dict(steps=steps, score=initial_score, comparison=initial_item)
                save('best.pth')
            atomic_json(args.output/'comparison.json', initial_item)
            atomic_json(args.output/'validation_history.json', validations)
            obs = env.observe()
            started = time.monotonic()
            next_validation = started+args.validation_every
            last_report, last_save, last_progress = started, started, started
            steps_at_start = steps

            def validate():
                nonlocal best, obs
                result = evaluate(env, actor, starts, deadline)
                item = dict(steps=steps, **comparison(baseline, result))
                validations.append(item)
                score = (item['learned']['success_rate_all_starts'], -len(item['regressed']),
                         -(item['learned']['mean_peak_force_n'] or 0))
                if best is None or tuple(best['score']) < score:
                    best = dict(steps=steps, score=score, comparison=item)
                    save('best.pth')
                atomic_json(args.output/'validation_history.json', validations)
                atomic_json(args.output/'comparison.json', item)
                obs = env.observe()

            while time.monotonic() < deadline-validation_reserve and not stop_requested[0]:
                fraction = (time.monotonic()-started)/max(1, deadline-started-validation_reserve)
                sampler.curriculum.level = max(sampler.curriculum.level, min(1., .25+fraction))
                rollout, sampled = [], 0
                for tick in range(s.horizon):
                    if selector:
                        epsilon = max(.05, 1.-steps/1_000_000)
                        action = learner.act(obs['actor'], epsilon)
                        nxt, rew, done, info = env.step(action)
                        learner.add(obs['actor'], action, rew, nxt['actor'], done, info['valid'])
                        if tick%4 == 0:
                            learner.update(gamma=s.gamma)
                    else:
                        action, log, value = policy.act(obs)
                        nxt, rew, done, info = env.step(action)
                        with torch.no_grad():
                            nv = policy.value(nxt['critic'])
                        rollout.append(dict(actor=obs['actor'], critic=obs['critic'], action=action,
                                            log_prob=log, value=value, next_value=nv, reward=rew, done=done,
                                            valid=info['valid'], actor_valid=info['actor_valid']))
                    count = int(info['valid'].sum())
                    steps += count
                    sampled += count
                    episodes += len(info['episodes'])
                    successes += sum(r['success'] for r in info['episodes'])
                    if info['episodes']:
                        with (args.output/'episodes.jsonl').open('a') as handle:
                            for row in info['episodes']:
                                handle.write(json.dumps(dict(row, training_steps=steps))+'\n')
                    obs = nxt
                    if stop_requested[0] or time.monotonic() >= deadline-validation_reserve:
                        break
                if sampled:
                    last_progress = time.monotonic()
                if not selector and rollout:
                    ppo.update(rollout)
                now = time.monotonic()
                if now-last_progress > 300:
                    raise RuntimeError('No valid training transitions for 5 minutes')
                if now-last_save > 120:
                    save('last.pth')
                    last_save = now
                if now >= next_validation and now < deadline-validation_reserve-60 and not stop_requested[0]:
                    save('last.pth')
                    validate()
                    next_validation = time.monotonic()+args.validation_every
                if now-last_report > 15:
                    atomic_json(args.output/'progress.json', dict(status='RUNNING', kind=args.kind, steps=steps,
                        episodes=episodes, successes=successes, success_rate=successes/max(1,episodes),
                        training_steps_per_second=(steps-steps_at_start)/max(1,now-started),
                        level=sampler.curriculum.level, best=best, not_end_to_end=True))
                    last_report = now
            save('last.pth')
            if not stop_requested[0] and time.monotonic() < deadline-30:
                validate()
            status = ('RESOURCE_OR_SIGNAL_STOP' if stop_requested[0] else
                      'COMPLETE' if steps > steps_at_start else 'NO_TRAINING_STEPS')
            atomic_json(args.output/'training_summary.json', dict(status=status,
                kind=args.kind, steps=steps, episodes=episodes, successes=successes, best=best,
                validation_count=len(validations), not_end_to_end=True, cameras=False))
        finally:
            for sig, handler in old_handlers.items():
                signal.signal(sig, handler)


def main(argv=None):
    p = parser()
    args = p.parse_args(argv)
    if args.num_envs < 1 or args.num_envs > 128 or args.seconds < 60 or args.validation_count < 4 or args.validation_every <= 0 or args.benchmark_steps < 1:
        p.error('Invalid count/budget; environment count must be 1..128')
    if args.mode == 'train' and (not args.benchmark_report or not args.benchmark_report.is_file()):
        p.error('Training requires a successful --benchmark-report')
    if args.mode == 'validate' and not args.checkpoint:
        p.error('Validation requires --checkpoint')
    # Reject bad inputs before allocating a renderer/physics context.
    from .reference import ReferenceBank
    bank = ReferenceBank(args.bank, 'cpu')
    expected = dict(format=FORMAT, kind=args.kind, sources=sources(), settings=to_jsonable(settings()),
                    bank_sha256=bank.meta['bank_sha256'], bank_inputs=bank.meta['inputs_sha256'], num_envs=args.num_envs)
    if args.mode == 'train':
        proof = json.loads(args.benchmark_report.read_text())
        if proof.get('status') != 'PASS' or not proof.get('reset_isolation') or any(proof.get(k) != v for k,v in expected.items()):
            p.error('Benchmark identity does not match this experiment')
    if args.resume or args.checkpoint:
        saved = torch.load(args.resume or args.checkpoint, map_location='cpu', weights_only=False)
        if any(saved.get(k) != expected[k] for k in ('format','kind','sources','settings','bank_sha256','bank_inputs')):
            p.error('Checkpoint kind/source/settings/input identity does not match')
    args.output = args.output.resolve()
    if args.output.exists() and any(args.output.iterdir()):
        p.error('Output must be a new empty directory')
    args.output.mkdir(parents=True, exist_ok=True)
    atomic_json(args.output/'arguments.json', vars(args))
    deadline = time.monotonic()+args.seconds
    from isaaclab.app import AppLauncher
    app, exit_code = None, 0
    try:
        app = AppLauncher(headless=True, enable_cameras=False, device=args.device).app
        run(args, deadline)
    except BaseException as error:
        import traceback
        exit_code = 1
        atomic_json(args.output/'failure.json', dict(error=f'{type(error).__name__}: {error}'))
        traceback.print_exc()
    finally:
        if app is not None:
            try:
                app.close()
            except SystemExit as error:
                if error.code:
                    exit_code = int(error.code)
    raise SystemExit(exit_code)


if __name__ == '__main__':
    main()
