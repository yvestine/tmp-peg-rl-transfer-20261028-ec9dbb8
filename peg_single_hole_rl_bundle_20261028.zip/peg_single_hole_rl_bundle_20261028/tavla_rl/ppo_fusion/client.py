"""Deployable client-side policy loading; no simulator or network imports.

The caller supplies the original 141-D deployable V5 observation, plus current
and future VLA target poses expressed relative to the handover command pose.
The returned correction is resolved by the same FusionControl used in training.
"""
import torch
from tavla_rl.ppo_v5.policy import Policy
from tavla_rl.ppo_v5.settings import from_mapping
from .config import FORMAT
from .control import FusionControl, extend_observation
from .learning import Selector


class FusionClient:
    def __init__(self, checkpoint, count=1, device='cpu'):
        saved = torch.load(checkpoint, map_location=device, weights_only=False)
        if saved.get('format') != FORMAT:
            raise ValueError('Expected a new fusion checkpoint, not a V5 takeover checkpoint')
        self.kind = saved['kind']
        self.settings = from_mapping(saved['settings'])
        self.control = FusionControl(count, self.settings, self.kind, device)
        if self.kind == 'selector':
            self.policy = Selector(saved['actor_dim'], device, capacity=1)
            self.policy.q.load_state_dict(saved['learner']['q'])
        else:
            self.policy = Policy(saved['actor_dim'], saved['critic_dim'], self.settings).to(device)
            self.policy.load_state_dict(saved['learner']['policy'])
            self.policy.eval()

    def reset(self, ids):
        self.control.reset(ids)

    @torch.no_grad()
    def action(self, base_observation, nominal, nominal_future):
        # Only the actor prefix is supplied; no privileged simulator critic input.
        observation = extend_observation(dict(actor=base_observation, critic=base_observation),
                                         nominal, nominal_future, self.control.residual)['actor']
        if self.kind == 'selector':
            return self.control.encode_candidates(self.policy.act(observation))
        return self.policy.deterministic(observation)
