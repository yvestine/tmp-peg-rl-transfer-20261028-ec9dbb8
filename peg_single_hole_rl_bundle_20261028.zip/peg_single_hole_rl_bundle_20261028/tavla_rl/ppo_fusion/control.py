"""Three different learned interfaces, sharing the original IK and joint slew."""
import math
import torch

# Candidate zero is the original nominal trajectory. Other candidates are small
# trajectory translations/tilts; their offsets are ramped by the same rate limit.
CANDIDATES = ((0,0,0,0,0), (.002,0,0,0,0), (-.002,0,0,0,0),
              (0,.002,0,0,0), (0,-.002,0,0,0), (0,0,.003,0,0),
              (0,0,-.003,0,0), (0,0,0,math.radians(2),0), (0,0,0,-math.radians(2),0),
              (0,0,0,0,math.radians(2)), (0,0,0,0,-math.radians(2)))


class FusionControl:
    def __init__(self, count, settings, kind, device='cpu'):
        if kind not in ('residual', 'admittance', 'selector'):
            raise ValueError(kind)
        self.kind, self.cfg = kind, settings
        self.offset = torch.zeros(count, 5, device=device)
        self.residual = torch.zeros_like(self.offset)
        self.reference = torch.zeros_like(self.offset)
        self.force = torch.zeros(count, 3, device=device)
        self.proposed = self.offset.clone()
        self.pending_residual = self.offset.clone()
        self.nominal_only = False
        self.scale = self.offset.new_tensor([.002, .002, .003, math.radians(2), math.radians(2)])
        self.rate = self.offset.new_tensor([.0005, .0005, .001, math.radians(.3), math.radians(.3)])
        self.candidates = self.offset.new_tensor(CANDIDATES)

    def reset(self, ids):
        for tensor in (self.offset, self.residual, self.reference, self.proposed, self.pending_residual, self.force):
            tensor[ids] = 0.

    def commanded_tcp(self, anchor):
        return anchor+self.offset[:, :3]

    def propose(self, action, valid, anchor, measured):
        if action.shape != self.offset.shape or not bool(torch.isfinite(action).all()):
            raise ValueError('Expected finite N x 5 controls')
        a = action.clamp(-1, 1)
        if self.nominal_only:
            desired = torch.zeros_like(self.residual)
        elif self.kind == 'admittance':
            # Stable exact-discrete first-order admittance: D*x_dot + K*x = F-F_ref.
            unit = (a+1)/2
            kxy, kz = 150+850*unit[:, 0], 500+2000*unit[:, 1]
            dxy, dz = 20+80*unit[:, 2], 30+120*unit[:, 3]
            k = torch.stack((kxy, kxy, kz), -1)
            damping = torch.stack((dxy, dxy, dz), -1)
            force = self.force.clone()
            force[:, 2] -= 1+5*unit[:, 4]
            equilibrium = force/k
            alpha = 1-torch.exp(-self.cfg.dt*k/damping)
            translation = self.residual[:, :3]+alpha*(equilibrium-self.residual[:, :3])
            bound = self.scale[:3]
            desired = torch.cat((translation.clamp(-bound, bound), torch.zeros_like(a[:, :2])), -1)
        else:
            desired = a*self.scale
        residual = self.residual+(desired-self.residual).clamp(-self.rate, self.rate)
        proposed = self.reference+residual
        moved = measured-anchor
        low = moved-proposed.new_tensor([self.cfg.gap_xy_m, self.cfg.gap_xy_m, self.cfg.gap_z_down_m])
        high = moved+proposed.new_tensor([self.cfg.gap_xy_m, self.cfg.gap_xy_m, self.cfg.gap_z_up_m])
        xyz = torch.maximum(torch.minimum(proposed[:, :3], high), low)
        proposed = torch.cat((xyz, proposed[:, 3:]), -1)
        # Keep the realizable correction relative to the MOVING nominal target;
        # rejected IK never enters either residual or total-command memory.
        self.proposed = torch.where(valid[:, None], proposed, self.offset)
        self.pending_residual = torch.where(valid[:, None], residual, self.residual)
        return self.proposed.clone()

    def commit(self, accepted):
        self.offset = torch.where(accepted[:, None], self.proposed, self.offset)
        self.residual = torch.where(accepted[:, None], self.pending_residual, self.residual)
        return self.offset.clone()

    def encode_candidates(self, indices):
        return (self.candidates[indices.long()]/self.scale).clamp(-1, 1)


def extend_observation(base, reference, future, residual):
    scale = reference.new_tensor([.003, .003, .030, math.radians(5), math.radians(5)])
    extra = torch.cat((reference/scale, (future-reference)/scale, residual/scale), -1).clamp(-10, 10)
    return dict(base, actor=torch.cat((base['actor'], extra), -1),
                critic=torch.cat((base['critic'], extra), -1))
