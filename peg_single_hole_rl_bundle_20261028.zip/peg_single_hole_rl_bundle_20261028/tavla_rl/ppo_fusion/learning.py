"""Continuous PPO policies and a separate Double-DQN candidate selector."""
import copy
import torch
from torch import nn
from tavla_rl.ppo_v5.policy import Policy
from .control import CANDIDATES


def warm_actor(policy, checkpoint):
    """Transfer compatible hidden features only; zero the changed action head."""
    saved = torch.load(checkpoint, map_location='cpu', weights_only=False)
    if saved.get('format') != 'tavla_v5_skill_v1':
        raise ValueError('Initialization must be a V5 skill checkpoint')
    if saved.get('observation', {}).get('actor_dim') != 141:
        raise ValueError('Hidden-layer initialization requires the main 141-D V5 observation layout')
    source = saved['policy']
    transferred = []
    with torch.no_grad():
        last = len(policy.actor)-1
        for name, tensor in policy.actor.state_dict().items():
            if int(name.split('.')[0]) == last:
                continue
            old = source.get('actor.'+name)
            if old is None:
                continue
            if tensor.shape == old.shape:
                tensor.copy_(old)
            elif name == '0.weight' and tensor.shape[0] == old.shape[0] and tensor.shape[1] >= old.shape[1]:
                tensor.zero_()
                tensor[:, :old.shape[1]].copy_(old)
            else:
                continue
            transferred.append(name)
        policy.actor[-1].weight.zero_()
        policy.actor[-1].bias.zero_()
    if not transferred:
        raise ValueError('No compatible V5 hidden layers')
    return transferred


class Selector:
    def __init__(self, actor_dim, device='cpu', capacity=32768):
        self.device = device
        self.q = nn.Sequential(nn.Linear(actor_dim, 256), nn.ELU(), nn.Linear(256, 256),
                               nn.ELU(), nn.Linear(256, len(CANDIDATES))).to(device)
        nn.init.zeros_(self.q[-1].weight)
        nn.init.zeros_(self.q[-1].bias)
        self.target = copy.deepcopy(self.q).requires_grad_(False)
        self.optimizer = torch.optim.Adam(self.q.parameters(), lr=3e-4)
        self.capacity, self.position, self.size, self.updates = capacity, 0, 0, 0
        self.buffer = dict(obs=torch.empty(capacity, actor_dim), next=torch.empty(capacity, actor_dim),
                           action=torch.empty(capacity, dtype=torch.long), reward=torch.empty(capacity),
                           done=torch.empty(capacity, dtype=torch.bool))

    @torch.no_grad()
    def act(self, observation, epsilon=0.):
        action = self.q(observation).argmax(-1)
        explore = torch.rand(len(action), device=action.device) < epsilon
        return torch.where(explore, torch.randint(len(CANDIDATES), action.shape, device=action.device), action)

    def add(self, obs, action, reward, next_obs, done, valid):
        count = int(valid.sum())
        if count == 0:
            return
        ids = (torch.arange(count)+self.position)%self.capacity
        for key, value in dict(obs=obs, action=action, reward=reward, next=next_obs, done=done).items():
            self.buffer[key][ids] = value[valid].detach().cpu()
        self.position = (self.position+count)%self.capacity
        self.size = min(self.capacity, self.size+count)

    def update(self, batch=1024, gamma=.99):
        if self.size < 2048:
            return None
        ids = torch.randint(self.size, (batch,))
        b = {k:v[ids].to(self.device) for k,v in self.buffer.items()}
        with torch.no_grad():
            chosen = self.q(b['next']).argmax(-1, keepdim=True)
            future = self.target(b['next']).gather(1, chosen).squeeze(1)
            target = b['reward']+gamma*(~b['done'])*future
        value = self.q(b['obs']).gather(1, b['action'][:, None]).squeeze(1)
        loss = nn.functional.smooth_l1_loss(value, target)
        if not bool(torch.isfinite(loss)):
            raise FloatingPointError('Non-finite selector loss')
        self.optimizer.zero_grad()
        loss.backward()
        nn.utils.clip_grad_norm_(self.q.parameters(), 1.)
        self.optimizer.step()
        with torch.no_grad():
            for target_p, source_p in zip(self.target.parameters(), self.q.parameters()):
                target_p.lerp_(source_p, .01)
        self.updates += 1
        return float(loss.detach())

    def state_dict(self):
        return dict(q=self.q.state_dict(), target=self.target.state_dict(),
                    optimizer=self.optimizer.state_dict(), updates=self.updates,
                    replay_note='Replay is intentionally rebuilt from fresh physical transitions on resume')

    def load_state_dict(self, value):
        self.q.load_state_dict(value['q'])
        self.target.load_state_dict(value['target'])
        self.optimizer.load_state_dict(value['optimizer'])
        self.updates = value['updates']
