"""Physics/reset implementation reused from V5, with a moving recorded VLA target."""
import torch
from tavla_rl.ppo_v5.skill_env import VectorSkillEnv
from tavla_rl.ppo_v5.settings import atomic_json, to_jsonable
from .control import FusionControl, extend_observation, CANDIDATES


class VectorFusionEnv(VectorSkillEnv):
    def __init__(self, args, settings, sampler, noise_model, bank):
        self._fusion_ready = False
        self.bank = bank
        super().__init__(args, settings, sampler, noise_model)
        self.integrator = FusionControl(self.num_envs, settings, args.kind, self.device)
        self.reference_ids = torch.zeros(self.num_envs, dtype=torch.long, device=self.device)
        self.actor_dim += 15
        self.critic_dim += 15
        self._fusion_ready = True
        prefix_contract = self.contract['observation']
        self.contract = dict(self.contract, format='tavla_fusion_v1', version=1, base_physics_version=5,
            settings=to_jsonable(settings), kind=args.kind,
            actor_dim=self.actor_dim, critic_dim=self.critic_dim, extra_fields=['nominal_pose_offset:5', 'nominal_next_0.5s_delta:5', 'applied_correction:5'],
            observation=dict(base_prefix=prefix_contract, actor_dim=self.actor_dim, critic_dim=self.critic_dim,
                             extra_fields=['nominal_pose_offset:5', 'nominal_next_0.5s_delta:5', 'applied_correction:5']),
            action=('continuous bounded pose correction' if args.kind == 'residual' else
                    'Kxy,Kz,Dxy,Dz,desired_Fz' if args.kind == 'admittance' else 'discrete candidate index'),
            candidates=CANDIDATES if args.kind == 'selector' else None,
            reference_bank_sha256=bank.meta['bank_sha256'],
            starts='Training profiles only; separate held-out profiles for local validation',
            limitation='Recorded reference is open loop. Reported success is local insertion, not live VLA end to end.')
        atomic_json(self.output/'environment_contract.json', self.contract)

    def _begin_skill(self, rows):
        super()._begin_skill(rows)
        if self._fusion_ready and len(rows):
            self.reference_ids[rows] = torch.tensor([self.bank.lookup[self.starts[i]['profile']] for i in rows.cpu().tolist()], device=self.device)

    def observe(self):
        base = super().observe()
        if not self._fusion_ready:
            return base
        reference = self.bank.at(self.reference_ids, self.steps)
        future = self.bank.at(self.reference_ids, self.steps+5)
        out = extend_observation(base, reference, future, self.integrator.residual)
        active = base['valid'][:, None]
        out['actor'] = out['actor']*active
        out['critic'] = out['critic']*active
        return out

    def step(self, action):
        self.integrator.reference = self.bank.at(self.reference_ids, self.steps).clone()
        self.integrator.force = self.history[:, -1].clone()
        if self.args.kind == 'selector':
            action = self.integrator.encode_candidates(action)
        return super().step(action)
