"""Sequential, wall-budgeted training with a watchdog outside the Isaac process."""
import argparse
from datetime import datetime
import fcntl
import json
import os
from pathlib import Path
import resource
import signal
import subprocess
import sys
import time
from zoneinfo import ZoneInfo
from tavla_rl.ppo_v5.settings import ROOT, atomic_json
from .config import KINDS, DEFAULT_RECORDINGS, DEFAULT_INIT, sources


class ResourcePause(RuntimeError):
    pass


def interrupt(signum, frame):
    raise KeyboardInterrupt(f'Launcher received signal {signum}')


def resources():
    text = subprocess.check_output(['nvidia-smi', '-i', '0',
        '--query-gpu=memory.free,temperature.gpu', '--format=csv,noheader,nounits'],
        text=True, stderr=subprocess.PIPE, timeout=8).strip()
    free, temperature = [int(x.strip()) for x in text.split(',')]
    available = next(int(x.split()[1]) for x in Path('/proc/meminfo').read_text().splitlines()
                     if x.startswith('MemAvailable:'))/1048576
    return dict(gpu_free_mib=free, temperature_c=temperature, available_ram_gib=available)


def safe(sample, starting=False):
    return (sample['gpu_free_mib'] >= (25600 if starting else 15360)
            and sample['temperature_c'] < 65 and sample['available_ram_gib'] >= 64)


def evaluation_running():
    for path in Path('/proc').glob('[0-9]*/cmdline'):
        try:
            command = path.read_bytes().replace(b'\0', b' ').decode(errors='replace')
            if 'run_original50_rl_quiet.py' in command and 'python' in command:
                return True
        except (OSError, PermissionError):
            pass
    return False


def wait_resources(deadline, output):
    ready = None
    while time.monotonic() < deadline:
        sample = resources()
        if safe(sample, starting=True) and not evaluation_running():
            ready = ready or time.monotonic()
            if time.monotonic()-ready >= 10:
                return
        else:
            ready = None
        atomic_json(output/'resource_wait.json', dict(status='WAITING', **sample,
                    waiting_for_current_evaluation=evaluation_running()))
        print('\r\033[K等待当前评测结束及显存空闲 ≥25 GiB', end='', flush=True)
        time.sleep(2)
    raise TimeoutError('Wall budget exhausted while waiting for resources')


def stop_child(process):
    if process.poll() is not None:
        return
    try:
        os.killpg(process.pid, signal.SIGTERM)
    except ProcessLookupError:
        return
    try:
        process.wait(timeout=30)
    except subprocess.TimeoutExpired:
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        process.wait(timeout=10)


def monitor(command, directory, deadline):
    directory.mkdir(parents=True, exist_ok=True)
    # Worker output must remain empty until its own output validation has run.
    log = directory.parent/(directory.name+'.console.txt')
    process = None
    try:
        with log.open('xb') as handle:
            process = subprocess.Popen(command, cwd=ROOT, stdin=subprocess.DEVNULL, stdout=handle,
                                       stderr=subprocess.STDOUT, start_new_session=True)
            atomic_json(directory.parent/'active_process.json', dict(pid=process.pid, command=command,
                        log=str(log), output=str(directory)))
            while process.poll() is None:
                sample = resources()
                if not safe(sample):
                    stop_child(process)
                    atomic_json(directory.parent/'resource_pause.json', sample)
                    raise ResourcePause(json.dumps(sample))
                if time.monotonic() >= deadline:
                    stop_child(process)
                    raise TimeoutError('Stage wall budget reached')
                progress = directory/'progress.json'
                if progress.is_file():
                    try:
                        p = json.loads(progress.read_text())
                        print(f"\r\033[K{p['kind']} | 训练成功 {p['successes']}/{p['episodes']} "
                              f"| 成功率 {p['success_rate']:.2%} | 步数 {p['steps']}", end='', flush=True)
                    except (ValueError, KeyError):
                        pass
                time.sleep(2)
        if process.returncode:
            raise RuntimeError(f'Worker failed with exit {process.returncode}; see {log}')
    finally:
        if process is not None:
            stop_child(process)


def parser():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--hours', type=float, default=9.)
    p.add_argument('--max-envs', type=int, default=128)
    p.add_argument('--kinds', nargs='+', choices=KINDS, default=list(KINDS))
    p.add_argument('--output', type=Path)
    p.add_argument('--recordings', type=Path, default=DEFAULT_RECORDINGS)
    p.add_argument('--v5-init', type=Path, default=DEFAULT_INIT)
    p.add_argument('--prepare-only', action='store_true', help='CPU-only preparation, no Isaac process')
    p.add_argument('--device', default='cuda:0', choices=['cuda:0'])
    return p


def main(argv=None):
    args = parser().parse_args(argv)
    if args.hours <= 0 or args.max_envs < 8 or args.max_envs > 128 or len(set(args.kinds)) != len(args.kinds):
        raise ValueError('Positive hours, 8..128 environments, and unique methods are required')
    resource.setrlimit(resource.RLIMIT_CORE, (0,0))
    signal.signal(signal.SIGTERM, interrupt)
    # A single host-wide fusion launcher, even if two different output paths are chosen.
    lock = Path('/tmp/tavla_fusion_training.lock').open('a')
    try:
        fcntl.flock(lock, fcntl.LOCK_EX|fcntl.LOCK_NB)
    except BlockingIOError:
        raise RuntimeError('Another fusion training pipeline is already running')
    started = time.monotonic()
    deadline = started+args.hours*3600
    output = (args.output or ROOT/'outputs/tavla_rl/ppo_fusion'/datetime.now(ZoneInfo('Asia/Shanghai')).strftime('run_%Y%m%d_%H%M%S')).resolve()
    if output.exists() and any(output.iterdir()):
        raise FileExistsError(f'Choose a new output directory: {output}')
    output.mkdir(parents=True, exist_ok=True)
    frozen_sources = sources()
    atomic_json(output/'plan.json', dict(hours=args.hours, kinds=args.kinds, maximum_envs=args.max_envs,
        sources=frozen_sources, cameras=False, parallelism='One Isaac process, multiple independent environments; methods run sequentially',
        minimum_gpu_free_mib=15360, minimum_start_free_mib=25600, maximum_temperature_c=65,
        minimum_available_ram_gib=64, interpretation='Camera-free local insertion screening. No live VLA success claim.'))
    print(f'输出：{output}', flush=True)
    from .reference import prepare
    metadata = prepare(args.recordings, output/'bank')
    print(f"参考轨迹：训练 {len(metadata['train_profiles'])} / 验证 {len(metadata['validation_profiles'])}；无相机", flush=True)
    if args.prepare_only:
        return
    records = []
    try:
        for index, kind in enumerate(args.kinds):
            root = output/kind
            root.mkdir()
            selected, proof, best_rate = None, None, 0.
            counts = sorted(set([n for n in (8,32,64,128) if n <= args.max_envs]+[args.max_envs]))
            print(f'\n{kind}：分级测试并行环境数', flush=True)
            for count in counts:
                wait_resources(deadline, output)
                folder = root/f'benchmark_{count}'
                command = [sys.executable, '-u', '-B', '-m', 'tavla_rl.ppo_fusion.worker', 'benchmark',
                           '--kind',kind,'--bank',str(output/'bank'),'--output',str(folder),
                           '--num-envs',str(count),'--device',args.device,'--seconds','900']
                try:
                    monitor(command, folder, min(deadline, time.monotonic()+930))
                except ResourcePause:
                    # Keep the smaller count that already passed; do not push allocation further.
                    print(f'\n{count} 环境触及资源保护，采用已通过的较小规模。', flush=True)
                    break
                report = folder/'benchmark.json'
                value = json.loads(report.read_text())
                if value['skill_steps_per_second'] > best_rate*1.05:
                    selected, proof, best_rate = count, report, value['skill_steps_per_second']
                print(f"\n{count} 环境通过，{value['skill_steps_per_second']:.1f} 有效步/秒", flush=True)
            if selected is None:
                raise RuntimeError('Even the smallest parallel benchmark did not pass resource protection')
            remaining_methods = len(args.kinds)-index
            remaining = deadline-time.monotonic()-300
            seconds = remaining/remaining_methods
            if seconds < 600:
                raise TimeoutError('Not enough remaining budget for another method')
            stage_deadline = min(deadline-120, time.monotonic()+seconds)
            resume = None
            attempts = []
            while time.monotonic() < stage_deadline-300:
                wait_resources(stage_deadline-240, output)
                if sources() != frozen_sources:
                    raise RuntimeError('Training source files changed during the experiment')
                folder = root/f'train_{len(attempts):03d}'
                command = [sys.executable,'-u','-B','-m','tavla_rl.ppo_fusion.worker','train',
                           '--kind',kind,'--bank',str(output/'bank'),'--output',str(folder),
                           '--num-envs',str(selected),'--benchmark-report',str(proof),'--device',args.device,
                           '--seconds',str(max(60, stage_deadline-time.monotonic()-30))]
                if resume:
                    command += ['--resume', str(resume)]
                elif kind == 'residual' and args.v5_init and args.v5_init.is_file():
                    command += ['--v5-init', str(args.v5_init)]
                attempts.append(str(folder))
                print(f'\n{kind}：{selected} 环境，剩余阶段预算 {(stage_deadline-time.monotonic())/3600:.2f} 小时', flush=True)
                try:
                    monitor(command, folder, stage_deadline)
                except ResourcePause:
                    resume = folder/'checkpoints/last.pth'
                    if not resume.is_file():
                        raise RuntimeError('Resources interrupted initialization before a resumable checkpoint was saved')
                    print('\n资源不足，已结束本次训练进程；等待空闲后从检查点继续。', flush=True)
                    continue
                summary = json.loads((folder/'training_summary.json').read_text())
                if summary['status'] != 'COMPLETE':
                    raise RuntimeError(f'Training ended unexpectedly: {summary}')
                break
            if not attempts or not (Path(attempts[-1])/'training_summary.json').is_file():
                raise TimeoutError(f'{kind}: no completed training stage within its budget')
            # A best checkpoint may belong to an earlier resource-interrupted attempt.
            best = None
            for path in attempts:
                manifest = Path(path)/'training_summary.json'
                if manifest.is_file():
                    candidate = json.loads(manifest.read_text()).get('best')
                    if candidate and (best is None or tuple(candidate['score']) > tuple(best['score'])):
                        best = candidate
            candidates = []
            for path in attempts:
                comp = Path(path)/'comparison.json'
                checkpoint = Path(path)/'checkpoints/best.pth'
                if comp.is_file() and checkpoint.is_file():
                    # Checkpoint itself is authoritative; the final comparison can be of last weights.
                    import torch
                    saved = torch.load(checkpoint, map_location='cpu', weights_only=False)
                    if saved.get('best'):
                        candidates.append((tuple(saved['best']['score']), str(checkpoint), saved['best']['comparison']))
            if not candidates:
                raise RuntimeError(f'{kind}: no validated checkpoint was produced')
            _, best_path, cmp = max(candidates, key=lambda x:x[0])
            records.append(dict(kind=kind, num_envs=selected, attempts=attempts, best_checkpoint=best_path, comparison=cmp))
            atomic_json(output/'summary.json', dict(status='RUNNING', methods=records, not_end_to_end=True))
        atomic_json(output/'summary.json', dict(status='COMPLETE', methods=records,
                    elapsed_hours=(time.monotonic()-started)/3600, not_end_to_end=True,
                    next_step='Evaluate selected checkpoint with live 8001 before claiming improved task success'))
        print(f'\n训练和离线验证完成：{output}/summary.json', flush=True)
    except BaseException as error:
        atomic_json(output/'failure.json', dict(error=f'{type(error).__name__}: {error}', completed_methods=records))
        print(f'\n停止：{error}', flush=True)
        raise


if __name__ == '__main__':
    main()
