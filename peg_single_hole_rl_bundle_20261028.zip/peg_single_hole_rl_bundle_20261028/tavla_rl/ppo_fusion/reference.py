"""Recorded 8001 motion references, split by source profile before fitting anything.

Only the original 40 profile recordings are used. Neither original50 nor new50
is read. These references are an open-loop training approximation of live VLA.
"""
import json
from pathlib import Path
import numpy as np
from tavla_rl.ppo_v5.settings import atomic_json, file_sha256


def prepare(recordings, output):
    import torch
    from tavla_rl.ppo_v5.controller import load_fk
    from tavla_rl.ppo_v5.geometry import leveling_rotation, rotation_log, tool_axis
    from tavla_rl.ppo_v5.noise import load_real_trajectories, fit_noise_model
    from tavla_rl.ppo_v5.settings import ROOT
    from .config import settings
    torch.set_num_threads(1)
    s, fk = settings(), load_fk('cpu')
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    rows, excluded = [], []
    for folder in sorted(Path(recordings).glob('profile_*')):
        profile = int(folder.name.split('_')[-1])
        summary = json.loads((folder/'summary.json').read_text())
        if summary.get('server', {}).get('port') != 8001 or summary.get('policy_source') != 'remote':
            raise ValueError(f'Not an authenticated remote 8001 recording: {folder}')
        if summary.get('diagnostic_auxiliary') or summary.get('action_start_index') != 1 or summary.get('replan_actions') != 10:
            raise ValueError(f'Recording execution protocol differs: {folder}')
        path = folder/'diagnostic_trace.npz'
        with np.load(path, allow_pickle=False) as trace:
            z, xy = trace['z_m'], trace['xy_m']
            hit = np.flatnonzero((z < .023) & (xy < .003))
            if not len(hit):
                excluded.append(dict(profile=profile, reason='no_aligned_contact_segment'))
                continue
            start = int(hit[0])
            q = torch.tensor(trace['raw_target_q'][start:], dtype=torch.float32)
            anchor = torch.tensor(trace['command_q'][start:start+1], dtype=torch.float32)
            if len(q) < 3 or not bool(torch.isfinite(q).all()):
                excluded.append(dict(profile=profile, reason='short_or_invalid_contact_segment'))
                continue
            p, r = fk(q)
            p0, r0 = fk(anchor)
            delta = torch.cat((p-p0, rotation_log(r@r0.transpose(-1, -2))[:, :2]), -1).numpy()
            # Bound unusually distant raw VLA targets before they become a reference.
            limits = np.array([.010, .010, .040, np.deg2rad(10), np.deg2rad(10)])
            clipped = np.clip(delta, -limits, limits)
            clipped[:, 2] = np.minimum(clipped[:, 2], .005)
            times = np.asarray(trace['formal_time_s'][start:], float)
            if np.any(np.diff(times) <= 0):
                raise ValueError(f'Non-monotonic reference clock: {path}')
            times -= times[0]
            target_times = np.arange(s.skill_steps+1)*s.dt
            reference = np.stack([np.interp(target_times, times, clipped[:, k]) for k in range(5)], -1)
            measured = torch.tensor(trace['q'][start:start+1], dtype=torch.float32)
            _, rm = fk(measured)
            level = leveling_rotation(tool_axis(rm))@rm
            tilt = rotation_log(rm@level.transpose(-1, -2))[0, :2].numpy()
            hole = trace['hole_target_pos_m'][start].tolist()
            speed = np.clip(-np.median(np.diff(z[start:start+8]))/.1, .003, .007)
            rows.append(dict(profile=profile, reference=reference.astype(np.float32),
                             q=measured[0].numpy(), hole=hole, tilt=tilt.tolist(),
                             xy=float(min(xy[start], .003)), speed=float(speed),
                             clipped_values=int(np.count_nonzero(delta != clipped)),
                             source=str(path.resolve()), sha256=file_sha256(path),
                             duration_s=float(times[-1]), checkpoint=summary.get('policy_checkpoint')))
    if len(rows) < 12:
        raise ValueError('Need at least 12 usable profile references; no test-set fallback is permitted')
    if len({row['checkpoint'] for row in rows}) != 1:
        raise ValueError('Mixed VLA checkpoints in the reference bank')
    order = np.random.default_rng(61022).permutation(len(rows))
    val_indices = set(order[:max(4, len(rows)//5)].tolist())
    split = np.array([int(i in val_indices) for i in range(len(rows))], np.int64)
    train = [row for i, row in enumerate(rows) if split[i] == 0]
    np.savez_compressed(output/'references.npz', reference=np.stack([x['reference'] for x in rows]),
                        profiles=np.array([x['profile'] for x in rows]), split=split,
                        q=np.stack([x['q'] for x in rows]), hole=np.array([x['hole'] for x in rows]))
    distribution = dict(format='tavla_v5_handover_distribution_v1',
                        xy_offset_m=[x['xy'] for x in train], hand_tilt_rotvec=[x['tilt'] for x in train],
                        approach_speed_m_s=[x['speed'] for x in train], in_hand_slip_deg=[0.],
                        in_hand_offset_m=[[0., 0., 0.]],
                        postures=[dict(q=x['q'].tolist(), hole_m=x['hole']) for x in train],
                        sources={'training_profiles': [x['profile'] for x in train],
                                 'in_hand_pose': 'not measured; randomized independently, never fitted from test cases'})
    atomic_json(output/'distribution.json', distribution)
    allowed = {f"traj_{x['profile']}" for x in train}
    noise = fit_noise_model([x for x in load_real_trajectories(ROOT/'real-data-aligned') if x['name'] in allowed])
    noise.save(output/'noise.json')
    meta = dict(format='tavla_fusion_references_v1', dt=.1, steps=s.skill_steps+1,
                train_profiles=[x['profile'] for i, x in enumerate(rows) if split[i] == 0],
                validation_profiles=[x['profile'] for i, x in enumerate(rows) if split[i] == 1],
                checkpoint=rows[0]['checkpoint'], sources=[{k:v for k,v in x.items() if k not in ('q','reference')} for x in rows],
                excluded_profiles=excluded,
                interpretation='Recorded VLA references, not live VLA feedback. Validation is local insertion, not end-to-end success.',
                bank_sha256=file_sha256(output/'references.npz'),
                inputs_sha256={name:file_sha256(output/name) for name in ('references.npz','distribution.json','noise.json')})
    atomic_json(output/'metadata.json', meta)
    return meta


class ReferenceBank:
    def __init__(self, directory, device='cpu'):
        import torch
        self.directory = Path(directory)
        self.meta = json.loads((self.directory/'metadata.json').read_text())
        if self.meta.get('format') != 'tavla_fusion_references_v1':
            raise ValueError('Unknown reference bank format')
        if file_sha256(self.directory/'references.npz') != self.meta['bank_sha256']:
            raise ValueError('Reference bank content changed')
        for name, expected in self.meta['inputs_sha256'].items():
            if file_sha256(self.directory/name) != expected:
                raise ValueError(f'Reference input content changed: {name}')
        with np.load(self.directory/'references.npz', allow_pickle=False) as a:
            self.reference = torch.tensor(a['reference'], device=device)
            self.profiles = a['profiles'].tolist()
            self.split = a['split'].tolist()
            self.q, self.hole = a['q'].copy(), a['hole'].copy()
        self.lookup = {p:i for i,p in enumerate(self.profiles)}

    def sources(self, split):
        return [dict(profile=p, joint_pos_rad=self.q[i].tolist(), hole_position_m=self.hole[i].tolist())
                for i,p in enumerate(self.profiles) if self.split[i] == int(split == 'validation')]

    def at(self, indices, steps):
        return self.reference[indices, steps.clamp(0, self.reference.shape[1]-1)]
