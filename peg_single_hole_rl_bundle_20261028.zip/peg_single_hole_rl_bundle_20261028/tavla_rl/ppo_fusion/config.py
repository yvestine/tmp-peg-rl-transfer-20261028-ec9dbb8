"""Versioned camera-free experiments, separate from the running V5 evaluation."""
from dataclasses import replace
from pathlib import Path
from tavla_rl.ppo_v5.settings import ROOT, load_settings, file_sha256, skill_sources

FORMAT = 'tavla_fusion_v1'
KINDS = ('residual', 'admittance', 'selector')
DEFAULT_RECORDINGS = ROOT/'outputs/five_model_proportional_200/eval/port_8001_force_align_latent_cotrain_50_50'
DEFAULT_INIT = ROOT/'outputs/tavla_rl/ppo_v5/continue128_300k_rng_cpu_20261021_190208/train_300k/checkpoints/best.pth'


def settings():
    return replace(load_settings(), horizon=64, synthetic_validation_count=64,
                   minimum_steps_per_second=10., train_in_hand_offset_m=.004,
                   validation_every_steps=500_000)


def sources():
    result = skill_sources()
    for path in sorted(Path(__file__).parent.glob('*.py')):
        result[str(path.relative_to(ROOT))] = file_sha256(path)
    return result
