"""Deployment observation contract and reproducible train/evaluation split."""
from __future__ import annotations

import numpy as np

DEFAULT_HOLE_STATIC_FRICTION = .75
HOLE_DYNAMIC_FRICTION = .25


def validate_hole_static_friction(value, physics_mode):
    if value is None:
        return
    if physics_mode != "fixed":
        raise ValueError("--hole-static-friction requires --physics-mode fixed")
    if not np.isfinite(value) or value < HOLE_DYNAMIC_FRICTION:
        raise ValueError("Hole static friction must be finite and >= 0.25; dynamic friction stays 0.25")

ENCODER_SHA256 = "db793ebd4f3158b8a8add895cf04368b2289df7fad450f1d2a39b09bb46acd80"
TRAIN_PROFILES = (0, 3, 4, 5, 6, 7, 9, 10, 11, 15, 16, 18, 19, 20, 21, 22, 23, 24,
                  25, 26, 27, 28, 29, 30, 31, 32, 35, 36, 37, 39)
EVAL_PROFILES = (1, 2, 8, 12, 13, 14, 17, 33, 34, 38)
ACTOR_FIELDS = (
    ("joint_pos", 7), ("joint_vel", 7), ("gripper", 1), ("nominal_action", 8),
    ("force_latent", 32), ("previous_residual", 3), ("command_joint_pos", 7),
    ("command_joint_velocity", 7), ("chunk_phase", 1),
)
PRIVILEGED_FIELDS = (
    ("held_pos_rel_fixed", 3), ("held_quat", 4), ("fixed_pos", 3),
    ("fixed_quat", 4), ("wrench_base", 6), ("task_prop_gains", 6),
    ("contact_threshold", 1),
)
EXECUTION_HISTORY_STEPS = 4
EXECUTION_SAMPLE_DIM = 29  # response/progress; stiffness slot is reserved and fixed at 1
EXECUTION_FIELDS = (("execution_history", EXECUTION_HISTORY_STEPS*EXECUTION_SAMPLE_DIM),
                    ("execution_state", 2), ("nominal_lookahead", 7))
CONTACT_HISTORY_FIELDS = (("contact_history", EXECUTION_HISTORY_STEPS*(EXECUTION_SAMPLE_DIM-2)),
                          ("nominal_lookahead", 7))
IMAGE_FIELDS = (("front_image_features", 512), ("wrist_image_features", 512))
IMAGE_FEATURE_DIM = sum(size for _, size in IMAGE_FIELDS)
POSE_FIELDS = (("tool_axis_base", 3), ("nominal_tool_axis_base", 3),
               ("tool_angular_velocity_base", 3), ("previous_rotation_residual", 2),
               ("residual_gate", 1), ("contact_force_xyz", 3))
POSE_V2_FIELDS = (("contact_phase", 1), ("tcp_height_above_reference_m", 1),
                  ("remaining_time_fraction", 1))


def actor_fields(use_latent=True, execution=False, contact_history=False, image_input=False, pose_residual=False, pose_v2=False):
    if execution and contact_history:
        raise ValueError("Contact history belongs to the XYZ actor, not the progress actor")
    if execution and pose_residual:
        raise ValueError("Pose residual and progress controls have different action contracts")
    fields = tuple((name, size) for name, size in ACTOR_FIELDS if use_latent or name != "force_latent")
    return (fields + (EXECUTION_FIELDS if execution else CONTACT_HISTORY_FIELDS if contact_history else ())
            + (POSE_FIELDS if pose_residual else ()) + (POSE_V2_FIELDS if pose_v2 else ())
            + (IMAGE_FIELDS if image_input else ()))


def actor_dim(use_latent=True, execution=False, contact_history=False, image_input=False, pose_residual=False, pose_v2=False):
    return sum(size for _, size in actor_fields(use_latent, execution, contact_history, image_input, pose_residual, pose_v2))


def critic_fields(execution=False, contact_history=False, pose_residual=False, pose_v2=False):
    # Keep the asymmetric critic's state contract independent of actor-only RGB.
    return actor_fields(execution=execution, contact_history=contact_history, pose_residual=pose_residual, pose_v2=pose_v2)+PRIVILEGED_FIELDS


def critic_dim(execution=False, contact_history=False, pose_residual=False, pose_v2=False):
    return sum(size for _, size in critic_fields(execution, contact_history, pose_residual, pose_v2))


CRITIC_DIM = actor_dim() + sum(size for _, size in PRIVILEGED_FIELDS)


def flatten_fields(values, fields):
    rows = []
    for name, size in fields:
        row = np.asarray(values[name], np.float32).reshape(-1)
        if row.shape != (size,) or not np.isfinite(row).all():
            raise ValueError(f"Invalid observation field {name}: expected finite ({size},)")
        rows.append(row)
    return np.concatenate(rows).astype(np.float32)


class ProfileSampler:
    """Visit every training profile once per shuffled round; evaluation is ordered."""
    def __init__(self, profiles, seed=0, shuffle=True):
        self.profiles = tuple(int(p) for p in profiles)
        if not self.profiles or len(set(self.profiles)) != len(self.profiles):
            raise ValueError("Profiles must be nonempty and unique")
        if any(p not in range(40) for p in self.profiles):
            raise ValueError("Profile IDs must be in 0..39")
        self.rng = np.random.default_rng(seed)
        self.shuffle = shuffle
        self.pending = []

    def next(self):
        if not self.pending:
            self.pending = list(self.profiles)
            if self.shuffle:
                self.rng.shuffle(self.pending)
        return self.pending.pop(0)
