"""Causal frozen teacher runtime. No simulation, renderer, or PPO imports."""
from __future__ import annotations

import hashlib
import importlib.util
from pathlib import Path
import sys
import time
import numpy as np

from .contracts import ENCODER_SHA256

ROOT = Path(__file__).resolve().parents[1]


def load_streaming_encoder(bundle=None):
    import torch
    torch.set_num_threads(1)  # Match the released single-env encoder's CPU execution.
    bundle = Path(bundle or ROOT/"force_align_latent_sim_bundle_20261004").resolve()
    checkpoint = bundle/"assets/encoder.pt"
    if hashlib.sha256(checkpoint.read_bytes()).hexdigest() != ENCODER_SHA256:
        raise ValueError("Encoder checkpoint differs from the pinned 8001 contract")
    if str(bundle) not in sys.path:
        sys.path.append(str(bundle))
    import insertion_alignment_encoder
    if not Path(insertion_alignment_encoder.__file__).resolve().is_relative_to(bundle):
        raise ValueError("Encoder source was imported from another bundle")
    spec = importlib.util.spec_from_file_location("_tavla_rl_sim_adapter", bundle/"sim_adapter.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    encoder = module.StreamingForceAlignmentEncoder(checkpoint, device="cpu")
    encoder.encoder.model.requires_grad_(False)
    return encoder


def make_client(host, port=8001):
    # Load the existing bounded client without importing Isaac-dependent task packages.
    path = ROOT/"source/tacex_tasks/tacex_tasks/real2sim/policy/five_model_runtime.py"
    spec = importlib.util.spec_from_file_location("_tavla_rl_five_model_client", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    if port not in (8001, 8005):
        raise ValueError("Use 8001 for residual PPO or 8005 for raw-wrench baseline evaluation")
    return module.FiveModelClient(host, port)


class RecordedTeacher:
    """Replay complete nominal chunks, for deterministic zero-residual regression only."""
    def __init__(self, trace):
        with np.load(trace, allow_pickle=False) as data:
            self.chunks = data["action_chunks"].copy()
        self.metadata = {"source": "recorded", "trace": str(Path(trace).resolve())}
        self.reset()

    def reset(self):
        self.index = 0

    def infer(self, observation):
        if self.index >= len(self.chunks):
            raise RuntimeError("Recorded teacher chunks exhausted; reduce episode duration")
        result = self.chunks[self.index].copy()
        self.index += 1
        return {"actions": result}

    def close(self):
        pass


class TeacherRuntime:
    """Prepare a nominal action BEFORE Actor inference; commit AFTER one physics tick."""
    def __init__(self, encoder, client, port=8001, raw_torque_mode="measured"):
        if port not in (8001, 8005) or raw_torque_mode not in ("measured", "zero"):
            raise ValueError("Invalid teacher input contract")
        self.encoder, self.client = encoder, client
        self.port, self.raw_torque_mode = port, raw_torque_mode
        self.reset()

    def reset(self, *, reset_client=True):
        self.encoder.reset()
        if reset_client:
            self.client.reset()
        self.chunk = None
        self.index = 1
        self.chunk_steps = 0
        self.last_force_time = None
        self.prepared_time = None
        self.requests = 0
        self.request_rows = []
        self.force_rows = []
        self.inference_seconds = []
        self.current_wrench = None

    def update_force(self, force, timestamp, wrench=None):
        timestamp = round(float(timestamp), 9)
        if self.last_force_time is not None and timestamp <= self.last_force_time:
            raise ValueError("Force must be sampled exactly once per increasing simulation timestamp")
        if self.port == 8005:
            wrench = np.asarray(wrench, np.float32)
            if wrench.shape != (6,) or not np.isfinite(wrench).all():
                raise ValueError("8005 requires the current finite six-axis base/K wrench")
            if not np.array_equal(wrench[:3], np.asarray(force, np.float32)):
                raise ValueError("Encoder and raw teacher forces must be synchronized")
            self.current_wrench = wrench.copy()
        self.encoder.update(np.asarray(force, np.float32), float(timestamp))
        self.last_force_time = float(timestamp)
        self.force_rows.append((float(timestamp), np.asarray(force, np.float32).copy()))

    @property
    def latest_latent(self):
        return self.encoder.effort_history[-1].copy()

    @property
    def needs_request(self):
        return self.prepared_time is None and (self.chunk is None or self.index >= 11-1e-8 or self.chunk_steps >= 10)

    def target_at(self, phase):
        """Interpolate only the current chunk; exact integer phases preserve old targets."""
        phase = float(phase)
        if not np.isfinite(phase) or not 0 <= phase <= 49 or self.chunk is None:
            raise ValueError("Invalid prepared chunk phase")
        lower = int(np.floor(phase))
        upper = min(lower+1, 49)
        fraction = phase-lower
        if fraction == 0:
            return self.chunk[lower].copy()
        return ((1-fraction)*self.chunk[lower]+fraction*self.chunk[upper]).astype(np.float32)

    def prepare(self, observation, timestamp):
        timestamp = round(float(timestamp), 9)
        if timestamp != self.last_force_time:
            raise ValueError("Teacher and Actor must use the current force sample")
        if self.prepared_time is not None:
            if timestamp != self.prepared_time:
                raise RuntimeError("Commit the prepared decision before advancing time")
            return self.target_at(self.index)
        if self.needs_request:
            if self.port == 8001:
                effort = self.encoder.effort_history
            else:
                effort = self.current_wrench.copy().reshape(1, 6)
                if self.raw_torque_mode == "zero":
                    effort[:, 3:] = 0.
            payload = dict(observation, effort=effort.copy())
            started = time.perf_counter()
            chunk = np.asarray(self.client.infer(payload)["actions"], np.float32)
            self.inference_seconds.append(time.perf_counter()-started)
            if chunk.shape != (50, 8) or not np.isfinite(chunk).all():
                raise ValueError("Teacher must return finite absolute targets (50, 8)")
            if np.any((chunk[:, 7] < -1e-5) | (chunk[:, 7] > 1+1e-5)):
                raise ValueError("Teacher gripper targets must be normalized in 0..1")
            self.chunk = chunk.copy()
            self.chunk[:, 7] = np.clip(self.chunk[:, 7], 0, 1)
            self.index = 1
            self.chunk_steps = 0
            self.requests += 1
            self.request_rows.append({"timestamp_s": float(timestamp), "state": payload["state"].copy(),
                                      "effort": effort.copy(), "actions": self.chunk.copy()})
            self.request_rows[-1]["image_sha256"] = {
                name: hashlib.sha256(np.ascontiguousarray(value).tobytes()).hexdigest()
                for name, value in payload.get("images", {}).items()}
        self.prepared_time = float(timestamp)
        return self.target_at(self.index)

    def commit(self, progress=1.):
        if self.prepared_time is None:
            raise RuntimeError("Cannot commit without a prepared Actor decision")
        if not np.isfinite(progress) or not 0 < progress <= 1:
            raise ValueError("Chunk progress must be in (0, 1]")
        self.index = min(11., self.index+progress)
        self.chunk_steps += 1
        self.prepared_time = None
