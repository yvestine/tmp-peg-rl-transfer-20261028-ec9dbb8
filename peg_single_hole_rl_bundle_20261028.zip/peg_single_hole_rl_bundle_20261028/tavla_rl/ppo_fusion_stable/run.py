"""Evaluate gated residual v2 on original50, with the existing serial watchdog."""
from datetime import datetime
from functools import partial
from pathlib import Path
import sys
from zoneinfo import ZoneInfo
from tavla_rl.ppo_fusion_eval import run as runner
from tavla_rl.ppo_v5.settings import ROOT, atomic_json, file_sha256, read_json, to_jsonable
from .control import StableSettings

PREVIOUS = ROOT/'outputs/tavla_rl/ppo_fusion/live_original50_20261022_101644/comparison.json'
_identity = runner.identity
_command = runner.command
_report = runner.report


def identity(args, manifest):
    value = _identity(args, manifest)
    paths = list(Path(__file__).parent.glob('*.py'))+[ROOT/'scripts/eval_vla_fusion_stable50.sh']
    value['sources'].update({str(p.relative_to(ROOT)): file_sha256(p) for p in paths})
    value.update(format='tavla_live_fusion_stable_v2', controller=StableSettings().contract,
                 previous_fusion_sha256=file_sha256(PREVIOUS),
                 protocol='original50; contact/stall gated residual; exact raw VLA fallback; weights unchanged')
    return value


def command(args, case, directory):
    value = _command(args, case, directory)
    value[value.index('tavla_rl.ppo_fusion_eval.run')] = 'tavla_rl.ppo_fusion_stable.run'
    return value


def report(args, suite, status, current_case=None, error=None):
    value = _report(args, suite, status, current_case, error)
    previous = read_json(PREVIOUS)
    old = {r['case_id']:r for r in previous['rows']}
    improved, regressed = [], []
    for row in value['rows']:
        if row['fusion'].get('controller') != StableSettings().version:
            raise ValueError('Completed result does not use the gated v2 controller')
        before = old[row['case_id']]['success']
        if row['success'] and not before:
            improved.append(row['case_id'])
        if before and not row['success']:
            regressed.append(row['case_id'])
    value.update(controller=StableSettings().contract, checkpoint_weights_changed=False,
        previous_fusion=dict(comparison=str(PREVIOUS), successes=sum(old[i]['success'] for i in args.cases),
            planned=len(args.cases), improved_cases=improved, regressed_cases=regressed,
            net_gain=len(improved)-len(regressed)),
        interpretation='Original50 development regression; historical VLA and previous residual runs are not new paired baselines')
    atomic_json(args.output/'comparison.json', value)
    atomic_json(args.output/'controller_contract.json', dict(checkpoint=str(args.checkpoint),
        checkpoint_sha256=suite['checkpoint_sha256'], weights_changed=False, controller=StableSettings().contract,
        evaluation='Original 50 cases; 8001 server and original success criterion unchanged'))
    return value


def worker_main(argv):
    # Keep the v1 worker protocol, but bind a different environment only in this
    # new process. The old evaluation and trained source files remain untouched.
    preliminary = runner.worker_parser().parse_args(argv)
    manifest = runner.load_case_manifest(preliminary.manifest)
    if not 0 <= preliminary.case_id < len(manifest['cases']):
        raise ValueError('Case id out of range')
    if (preliminary.task != 'peg_insert' or preliminary.policy != 'zero' or preliminary.repeats != 1
            or preliminary.physics_mode != 'fixed' or preliminary.seconds != 60. or preliminary.raw_torque_mode != 'zero'
            or preliminary.hole_static_friction != runner.expected_hole_override(manifest) or preliminary.checkpoint
            or preliminary.image_input or preliminary.teacher_trace or preliminary.port != 8001 or not preliminary.output):
        raise ValueError('Keep the original 60 s fixed-backend evaluation protocol')
    settings = runner.load_checkpoint(preliminary.fusion_checkpoint)
    import torch
    torch.set_num_threads(1)
    torch.manual_seed(preliminary.seed)
    from isaaclab.app import AppLauncher
    args = runner.worker_parser(AppLauncher).parse_args(argv)
    args.command, args.enable_cameras = 'eval', True
    args.profiles = [manifest['cases'][args.case_id]['source_profile']]
    args.eval_case_manifest, args.eval_case_id = str(args.manifest.resolve()), args.case_id
    from tavla_rl.experiment import prepare_output
    prepare_output(args.output)
    app = None
    try:
        app = AppLauncher(args).app
        import tavla_rl.env as backend
        import tavla_rl.env_cfg as configurations
        runner.scripts_on_path()
        from peg_fixed_backend import ReferenceTeacherRuntime
        from .environment import StableFusionEnv
        backend.TavlaRLEnv = StableFusionEnv
        backend.TeacherRuntime = partial(ReferenceTeacherRuntime, variant='full')
        original_config = configurations.make_config

        def configure(options):
            cfg = original_config(options)
            cfg.fixed_backend_initialization_only, cfg.fixed_backend_fixture = False, ''
            cfg.v5_options = dict(arm='gated_fusion', settings=settings, capture=False, set_name='original50')
            cfg.fusion_checkpoint = str(args.fusion_checkpoint.resolve())
            return cfg
        configurations.make_config = configure
        from tavla_rl.experiment import load_ppo_config, simulation_environment, write_manifest
        write_manifest(args, load_ppo_config(args))
        with simulation_environment(args) as env:
            if env.client.server_metadata != read_json(runner.SERVER_REFERENCE)['server_metadata']:
                raise ValueError('8001 model metadata differs from the historical baseline')
            env.reset(seed=args.seed)
            for step in range(600):
                _, _, done, timeout, _ = env.step(torch.zeros((1, 3), device=env.device))
                atomic_json(env.output/'progress.json', dict(steps=step+1, formal_seconds=(step+1)*.1,
                    fusion_active=env.v5_active, vla_requests=env.runtime.requests))
                if bool((done | timeout)[0]):
                    break
            else:
                raise RuntimeError('Episode did not terminate at 60 formal seconds')
            env.runtime.save_policy_trace(env.output/'policy_force_trace.npz')
            atomic_json(env.output/'result.json', dict(status='COMPLETE', result=env._last_summary,
                case_id=args.case_id, set='original50', arm='fusion', manifest_id=manifest['manifest_id'],
                settings=to_jsonable(settings), checkpoint=str(args.fusion_checkpoint.resolve()),
                checkpoint_sha256=file_sha256(args.fusion_checkpoint), server_metadata=env.client.server_metadata))
    except BaseException as error:
        atomic_json(Path(args.output)/'failure.json', dict(error=f'{type(error).__name__}: {error}'))
        raise
    finally:
        if app is not None:
            app.close()


def run_main(argv):
    # Reuse the serial runner, result validation, source pinning, resume, lock,
    # per-case timeout and resource watchdog through process-local bindings.
    runner.identity, runner.command, runner.report = identity, command, report
    if not any(x == '--output' or x.startswith('--output=') for x in argv):
        output = ROOT/'outputs/tavla_rl/ppo_fusion'/('stable_original50_'+
            datetime.now(ZoneInfo('Asia/Shanghai')).strftime('%Y%m%d_%H%M%S'))
        argv = ['--output', str(output)]+list(argv)
    runner.run_main(argv)


if __name__ == '__main__':
    worker_main(sys.argv[2:]) if len(sys.argv) > 1 and sys.argv[1] == 'worker' else run_main(sys.argv[1:])
