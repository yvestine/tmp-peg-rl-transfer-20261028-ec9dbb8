"""Gated residual inference using the existing best actor; no weight retraining."""
