"""Gated residual simulation adapter. Import only after AppLauncher."""
import numpy as np
import torch
from tavla_rl.env import TavlaRLEnv
from tavla_rl.ppo_v5.e2e_env import V5HandoverEnv
from tavla_rl.ppo_v5.geometry import rotation_log
from tavla_rl.ppo_fusion.client import FusionClient
from tavla_rl.ppo_fusion_eval.environment import nominal_pose
from .control import StableSettings, ContactGate, bounded_correction, choose_joint_target


class StableFusionEnv(V5HandoverEnv):
    def __init__(self, cfg, **kwargs):
        super().__init__(cfg, **kwargs)
        self._fusion_client = FusionClient(cfg.fusion_checkpoint, device=self.device)
        self._v5_integrator = self._fusion_client.control
        self._stable = StableSettings()
        self._gate = ContactGate(self._stable)
        self._v5_reset()

    def _v5_reset(self):
        super()._v5_reset()
        self._fusion_trace = []
        self._fusion_teacher_requests = 0
        self._fusion_clipped_values = 0
        self._stable_assisted_steps = 0
        self._stable_nominal_steps = 0
        self._stable_ik_fallbacks = 0
        self._stable_liftout_ticks = 0
        if hasattr(self, '_gate'):
            self._gate.reset()

    def _prepare_decision(self):
        if not getattr(self, '_v5_ready', False) or self._contact is None or not hasattr(self, '_gate'):
            return TavlaRLEnv._prepare_decision(self)
        if self.runtime.prepared_time is not None:
            return
        self._sample_force()
        p, _, tip, height = self._v5_geometry()
        history, _ = self._v5_force_history()
        self._v5_last = dict(height=float(height[0]), tip=tip[0].cpu().tolist())
        eligible = self._gate.observe(float(height[0]), float(tip[0, 2]), history[0, -3:], self.v5_active)
        if self._v5_active:
            timeout, _ = self._v5_machine.observe_skill(height)
            # The new entry window admits contact above the old depth threshold.
            # Do not instantly cancel these valid phases using that old height.
            outside = float(height[0]) > self._stable.near_high_m and not self._gate.loaded
            self._stable_liftout_ticks = self._stable_liftout_ticks+1 if outside else 0
            liftout = self._stable_liftout_ticks >= self._v5_settings.liftout_confirm_steps
            if bool(timeout[0]) or liftout:
                self._v5_active = False
                self._v5_armed = False
                self._v5_machine.stop(torch.ones(1, dtype=torch.bool, device=self.device))
                self._gate.clear_assistance()
                self._v5_handbacks.append(dict(time_s=self._episode_steps*.1,
                    reason='timeout' if bool(timeout[0]) else 'unloaded_liftout',
                    height_mm=float(height[0])*1e3, skill_steps=self._v5_skill_steps))
        else:
            if not self._v5_armed and float(height[0]) > self._stable.near_high_m:
                self._v5_armed = True
            allowed = int(self._v5_machine.takeovers[0]) < self._v5_settings.max_takeovers
            if eligible and self._gate.stalled and self._v5_armed and allowed:
                # Geometry truth is logged by the inherited event reporter only;
                # it never enters the eligibility decision.
                self._v5_on_trigger(p, tip, height)
                self._v5_start(tip)
                self._stable_liftout_ticks = 0
        if not self._v5_active:
            self._gate.clear_assistance()
        before = self.runtime.requests
        TavlaRLEnv._prepare_decision(self)
        if self._v5_active:
            self._fusion_teacher_requests += self.runtime.requests-before

    def _remember_target(self, target_q, nominal_q, applied, requested):
        """Actor memory describes the accepted target, including exact fallback."""
        control = self._v5_integrator
        p, r = self._v5_fk(target_q)
        p0, r0 = self._v5_fk(self._v5_handover_q)
        control.offset = torch.cat((p-p0, rotation_log(r@r0.transpose(-1, -2))[:, :2]), -1)
        control.residual = applied.clone()
        control.reference = nominal_pose(self._v5_fk, nominal_q, self._v5_handover_q)[0]
        self._v5_target_q = target_q.clone()
        self._v5_previous_action = requested.clone()

    def _pre_physics_step(self, action):
        if not self.v5_active:
            return TavlaRLEnv._pre_physics_step(self, action)
        if self.runtime.prepared_time is None:
            raise RuntimeError('Prepare the live VLA target before gated fusion')
        nominal_q = self.teacher_target[:, :7].float().clone()
        nominal, clipped = nominal_pose(self._v5_fk, nominal_q, self._v5_handover_q)
        ahead = torch.as_tensor(self.runtime.target_at(min(self.runtime.index+5, 49))[:7],
                                device=self.device).reshape(1, 7)
        future = nominal_pose(self._v5_fk, ahead, self._v5_handover_q)[0]
        self._fusion_clipped_values += clipped
        nominal_tcp, _ = self._v5_fk(nominal_q)
        measured, _ = self._v5_fk(self.joint_pos[:, :7].float())
        client, control = self._fusion_client, self._v5_integrator
        requested = client.action(self.v5_observation(), nominal, future)
        correction = bounded_correction(requested, control.residual, self._gate.alpha,
                                        self._gate.force_n, nominal_tcp, measured, self._stable)
        zero = bool(correction.abs().amax() <= 1e-9)
        accepted = torch.zeros(1, dtype=torch.bool, device=self.device)
        target_q = nominal_q.clone()
        if not zero and not self._pending_guard:
            lower, upper = self._joint_limits()
            lower, upper = self._as_torch(lower)[:, :7].float(), self._as_torch(upper)[:, :7].float()
            # Correct the current RAW VLA pose, retaining its full orientation
            # and redundancy seed. No anchor-yaw reconstruction or nominal clip.
            solved, accepted = self._v5_fk.ik(nominal_q, correction, lower, upper)
            target_q, used = choose_joint_target(nominal_q, solved, accepted, correction)
        else:
            used = torch.zeros_like(accepted)
        if not bool(used[0]):
            if not zero and not self._pending_guard:
                self._stable_ik_fallbacks += 1
                self._ik_rejections += 1
            applied = torch.zeros_like(correction)
            # Exact original teacher / zero-policy branch, including all original
            # guards, gripper, slew and bookkeeping. Avoid a second slew call.
            TavlaRLEnv._pre_physics_step(self, action)
            self._stable_nominal_steps += 1
        else:
            applied = correction
            target = self.teacher_target.clone()
            target[:, :7] = target_q.to(target.dtype)
            self.residual_action.zero_()
            self.actions.zero_()
            self._last_slew_previous = self._np(self._teacher_command_target)[0]
            self._last_slew_velocity = self._np(self._teacher_command_velocity)[0]
            self._last_ik_target = self._np(target_q)[0].copy()
            self.combined_joint_target = self._smooth_teacher_target(target)
            self.next_action = self.combined_joint_target.clone()
            self._last_residual.fill(0.)
            self._ik = None
            self._stable_assisted_steps += 1
        self._remember_target(target_q, nominal_q, applied, requested)
        xy, z = self._geometry()
        self._fusion_trace.append(dict(time_s=self._episode_steps*.1, action=self._np(requested)[0],
            nominal=self._np(nominal)[0], future=self._np(future)[0],
            residual=self._np(applied)[0], offset=self._np(control.offset)[0],
            accepted=bool(used[0]), alpha=self._gate.alpha, force_n=self._gate.force_n,
            stalled=self._gate.stalled, down_progress_m=self._gate.progress_m,
            original_vla_path=not bool(used[0]), nominal_q=self._np(nominal_q)[0],
            target_q=self._np(target_q)[0], gripper=float(self.teacher_target[0, 7]),
            vla_requests=self.runtime.requests, xy_true_m=xy, z_true_m=z))
        self._v5_skill_steps += 1

    def _finish_episode(self, success, timed_out, xy, z):
        super()._finish_episode(success, timed_out, xy, z)
        self._last_summary['fusion'] = dict(kind='residual', controller=self._stable.version,
            live_vla=True, blended_steps=len(self._fusion_trace), assisted_steps=self._stable_assisted_steps,
            original_vla_steps_in_phase=self._stable_nominal_steps, ik_fallbacks=self._stable_ik_fallbacks,
            vla_requests_while_blending=self._fusion_teacher_requests,
            clipped_nominal_values=self._fusion_clipped_values,
            nominal_clipping='Observation only; actual VLA target is not clipped',
            checkpoint_weights_changed=False, policy_contract=self._stable.contract,
            success_rule='XY < 3 mm and Z < 3 mm; original benchmark criterion')
        if self._fusion_trace:
            np.savez_compressed(self.output/'fusion_trace.npz', **{
                k: np.asarray([row[k] for row in self._fusion_trace]) for k in self._fusion_trace[0]})
