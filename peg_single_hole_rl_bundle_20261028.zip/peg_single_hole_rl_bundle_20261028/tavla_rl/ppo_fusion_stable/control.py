"""Robot-state/force gating and residual limits. No simulator or network imports."""
from collections import deque
from dataclasses import asdict, dataclass
import math
import torch


@dataclass(frozen=True)
class StableSettings:
    version: str = 'gated_residual_v2'
    dt: float = .1
    near_low_m: float = -.010
    active_low_m: float = -.035
    near_high_m: float = .008
    contact_n: float = 1.
    contact_ticks: int = 3
    stall_window_ticks: int = 10
    minimum_down_progress_m: float = .0005
    alpha_step: float = .2
    maximum_alpha: float = 1.
    unload_force_n: float = 4.
    maximum_up_residual_m: float = .001

    @property
    def contract(self):
        return dict(asdict(self), inputs='FK height and relative downward progress; tared XYZ force',
            target='raw live VLA FK pose plus gated residual; zero residual keeps raw joint target exactly',
            geometry='No true hole XY, peg pose, success flag or case ID enters the controller',
            checkpoint='Existing best actor reused; inference controller changed, weights unchanged',
            limitation='Contact evidence cannot certify XY alignment; no learned recovery controller is added')


class ContactGate:
    """Observe each control tick once; assist only after loaded insertion stalls.

    Contact near the calibrated rim can start a phase before the old depth-only
    trigger. Normal downward progress keeps the residual disabled. This gate
    cannot replace an actual hole-alignment estimator.
    """
    def __init__(self, cfg=None):
        self.cfg = cfg or StableSettings()
        self.reset()

    def reset(self):
        self.history = deque(maxlen=self.cfg.stall_window_ticks+1)
        self.loaded_ticks = 0
        self.alpha = 0.
        self.loaded = self.near = self.stalled = False
        self.force_n = 0.
        self.progress_m = 0.

    def observe(self, height_m, tip_z_m, force_xyz, active=False):
        if not math.isfinite(height_m) or not math.isfinite(tip_z_m):
            raise FloatingPointError('Non-finite gate geometry')
        force = torch.as_tensor(force_xyz).float()
        if force.numel() != 3 or not bool(torch.isfinite(force).all()):
            raise FloatingPointError('Expected finite XYZ force')
        self.force_n = float(torch.linalg.vector_norm(force))
        low = self.cfg.active_low_m if active else self.cfg.near_low_m
        self.near = low <= height_m <= self.cfg.near_high_m
        self.loaded = self.force_n >= self.cfg.contact_n
        self.loaded_ticks = self.loaded_ticks+1 if self.near and self.loaded else 0
        # Unloaded/free-space history must not create an immediate stall trigger
        # at a new contact. Require a full window of near-contact observations.
        if not self.near:
            self.history.clear()
        else:
            self.history.append(tip_z_m)
        ready = len(self.history) == self.history.maxlen
        self.progress_m = self.history[0]-self.history[-1] if ready else 0.
        self.stalled = ready and self.progress_m < self.cfg.minimum_down_progress_m
        eligible = self.loaded_ticks >= self.cfg.contact_ticks
        desired = self.cfg.maximum_alpha if eligible and self.stalled else 0.
        self.alpha += max(-self.cfg.alpha_step, min(self.cfg.alpha_step, desired-self.alpha))
        self.alpha = min(self.cfg.maximum_alpha, max(0., round(self.alpha, 10)))
        return eligible

    def clear_assistance(self):
        self.alpha = 0.

    def snapshot(self):
        return dict(alpha=self.alpha, near=self.near, loaded=self.loaded, stalled=self.stalled,
                    contact_ticks=self.loaded_ticks, force_n=self.force_n,
                    down_progress_mm=self.progress_m*1000)


def bounded_correction(action, previous, alpha, force_n, nominal_tcp, measured_tcp, cfg=None):
    """Absolute base-frame correction with rate and gap limits containing zero.

    Limits constrain only the added correction. The original VLA reference is
    never projected or clipped. Thus zero always maps to the original reference,
    even if the VLA itself lies outside the residual controller's gap limits.
    """
    cfg = cfg or StableSettings()
    if action.shape != (1, 5) or previous.shape != (1, 5):
        raise ValueError('Expected one five-dimensional residual')
    if not all(bool(torch.isfinite(t).all()) for t in (action, previous, nominal_tcp, measured_tcp)):
        raise FloatingPointError('Non-finite residual inputs')
    if not math.isfinite(alpha) or not 0 <= alpha <= 1 or not math.isfinite(force_n):
        raise ValueError('Invalid gate weight or load')
    scale = action.new_tensor([.002, .002, .003, math.radians(2), math.radians(2)])
    rate = action.new_tensor([.0005, .0005, .001, math.radians(.3), math.radians(.3)])
    desired = action.clamp(-1, 1)*scale*alpha
    # Upward correction is reserved for unloading under load, rather than
    # routinely lifting an already aligned, lightly loaded insertion.
    up = cfg.maximum_up_residual_m if force_n >= cfg.unload_force_n else 0.
    desired[:, 2] = desired[:, 2].clamp_max(up*alpha)
    correction = previous+(desired-previous).clamp(-rate, rate)
    if alpha == 0.:
        correction.zero_()  # zero gate takes the exact original execution path
    # Existing over-large VLA gaps are allowed unchanged, but residuals cannot
    # enlarge them. Zero belongs to the feasible set for every nominal target.
    gap = nominal_tcp-measured_tcp
    lower = torch.minimum(gap, gap.new_tensor([-.002, -.002, -.015]))
    upper = torch.maximum(gap, gap.new_tensor([.002, .002, .005]))
    corrected_gap = torch.maximum(torch.minimum(gap+correction[:, :3], upper), lower)
    correction[:, :3] = corrected_gap-gap
    correction = correction.clamp(-scale, scale)
    return correction


def choose_joint_target(nominal, solved, accepted, correction):
    """Exact nominal fallback on zero residual or rejected IK."""
    use = accepted & correction.abs().amax(-1).gt(1e-9)
    return torch.where(use[:, None], solved, nominal), use
