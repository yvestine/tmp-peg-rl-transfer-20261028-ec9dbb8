"""CPU-safe argument parsing; help/validation never imports Isaac or pxr."""
import argparse
from pathlib import Path
from .settings import ROOT,load_settings


def parser():
    p=argparse.ArgumentParser(description='V4 calibrated cumulative-residual PPO')
    p.add_argument('mode',choices=['train','benchmark','eval'])
    p.add_argument('--output',type=Path,default=ROOT/'outputs/tavla_rl/ppo_pose_v4')
    p.add_argument('--num-envs',type=int,default=8)
    p.add_argument('--host',default='114.214.164.36')
    p.add_argument('--device',default='cuda:0')
    p.add_argument('--seed',type=int,default=20261023)
    p.add_argument('--settings',type=Path)
    p.add_argument('--server-audit',type=Path,default=ROOT/'outputs/tavla_rl/ppo_v4_probe/server_audit.json')
    p.add_argument('--rpc-concurrency',type=int,default=1)
    p.add_argument('--hole-pose-source',choices=['simulated','measured'],default='simulated')
    p.add_argument('--hole-calibration',type=Path)
    p.add_argument('--total-steps',type=int,default=200000)
    p.add_argument('--wall-hours',type=float,default=8.)
    p.add_argument('--checkpoint-every',type=int,default=50000)
    p.add_argument('--resume',type=Path)
    p.add_argument('--checkpoint',type=Path)
    p.add_argument('--split',choices=['validation','test'],default='validation')
    p.add_argument('--policy',choices=['zero','geometric','ppo'],default='ppo')
    p.add_argument('--manifest',type=Path,default=ROOT/'outputs/peg_three_models_v6/test_cases.json')
    p.add_argument('--initial-bank',type=Path)
    p.add_argument('--benchmark-steps',type=int,default=128)
    p.add_argument('--benchmark-report',type=Path)
    p.add_argument('--save-trace',action='store_true')
    p.add_argument('--drift-limit',type=float)
    p.add_argument('--headless',action=argparse.BooleanOptionalAction,default=True)
    return p


def parse(argv=None):
    p=parser();args=p.parse_args(argv)
    cfg=load_settings(args.settings)
    if args.drift_limit is None:args.drift_limit=max(.5,.03*(cfg.seconds+2.1)+.03)
    if args.num_envs not in (1,4,8):p.error('--num-envs must be 1, 4 or 8 until a new benchmark is validated')
    if not 1<=args.rpc_concurrency<=args.num_envs:p.error('Invalid RPC concurrency')
    if args.hole_pose_source=='measured' and not args.hole_calibration:p.error('Measured mode requires --hole-calibration; no truth fallback')
    if args.hole_calibration and args.hole_pose_source!='measured':p.error('--hole-calibration requires measured mode')
    if args.mode=='eval' and args.policy=='ppo' and not args.checkpoint:p.error('PPO evaluation needs --checkpoint')
    if min(args.total_steps,args.wall_hours,args.checkpoint_every,args.benchmark_steps,args.drift_limit)<=0:p.error('Budgets must be positive')
    args.output=args.output.resolve()
    if args.benchmark_report is None:
        args.benchmark_report=ROOT/f'outputs/tavla_rl/ppo_pose_v4_pipeline/benchmark_{args.num_envs}/benchmark.json'
    args.save_trace=args.save_trace or args.mode=='eval'
    return args,cfg
