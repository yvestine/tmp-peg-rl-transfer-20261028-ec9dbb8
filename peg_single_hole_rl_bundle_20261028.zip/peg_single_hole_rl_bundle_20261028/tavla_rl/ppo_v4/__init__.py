"""Versioned, calibrated, vector contact PPO. Importing this package starts nothing."""
