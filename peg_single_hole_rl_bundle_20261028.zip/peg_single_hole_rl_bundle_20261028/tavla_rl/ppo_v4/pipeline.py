"""Benchmark -> 200k -> independent validation -> optional 1M -> 150 regressions.

All child output stays in tmux. A low-throughput or non-improving candidate
stops the long run, with concrete structured diagnostics and resumable weights.
"""
import argparse
import hashlib
import json
from pathlib import Path
import sys
import time
from .settings import ROOT,atomic_json,source_hashes
from .evaluation import choose


def select_benchmark(reports,minimum=10.):
    eligible=[r for r in reports if r.get('status')=='PASS' and r.get('reset_isolation') is True and
              r['gpu_memory_fraction']<.8]
    if not eligible:raise ValueError('No physically isolated parallel configuration passed the memory limit')
    best=max(eligible,key=lambda r:r['effective_steps_per_second'])
    return best,best['effective_steps_per_second']>=minimum


def result_file(path,name):
    p=Path(path)/name
    return json.loads(p.read_text()) if p.exists() else None


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output',type=Path,default=ROOT/'outputs/tavla_rl/ppo_pose_v4_pipeline')
    p.add_argument('--server-audit',type=Path,default=ROOT/'outputs/tavla_rl/ppo_v4_probe/server_audit.json')
    p.add_argument('--host',default='114.214.164.36')
    p.add_argument('--device',default='cuda:0')
    p.add_argument('--wall-hours',type=float,default=8.)
    p.add_argument('--stage1-steps',type=int,default=200000)
    p.add_argument('--stage2-steps',type=int,default=1000000)
    args=p.parse_args()
    if not args.server_audit.is_file():p.error(f'Missing audit/probe result: {args.server_audit}; see tavla_rl/ppo_v4/README.md')
    if not 0<args.stage1_steps<args.stage2_steps or args.wall_hours<=0:p.error('Invalid staged/wall budgets')
    args.output=args.output.resolve();args.output.mkdir(parents=True,exist_ok=True)
    deadline=time.monotonic()+args.wall_hours*3600
    training_retries={}
    def call(mode,folder,extra=(),num_envs=8):
        directory=args.output/folder
        completion={'benchmark':'benchmark.json','train':'training_summary.json','eval':'summary.json'}[mode]
        if mode=='train':
            # Find the latest continuation of this phase, including one that
            # already completed on a previous invocation of the whole pipeline.
            continuations=sorted(args.output.glob(f'{folder}_resume_*'))
            if continuations:directory=continuations[-1]
        value=result_file(directory,completion)
        if value and value.get('status') in ('COMPLETE','PASS'):
            manifest=result_file(directory,'run_manifest.json')
            if not manifest or manifest.get('sources')!=source_hashes():
                raise ValueError(f'Saved phase code differs from current V4; choose a fresh pipeline output: {directory}')
            return directory
        remaining=(deadline-time.monotonic())/3600
        if remaining<=0:raise TimeoutError('Overall overnight wall budget reached; rerun this pipeline to resume')
        command=[sys.executable,'-u','-B','-m','tavla_rl.ppo_v4.worker',mode,'--output',str(directory),
                 '--num-envs',str(num_envs),'--server-audit',str(args.server_audit.resolve()),'--host',args.host,
                 '--device',args.device,'--wall-hours',str(remaining),*map(str,extra)]
        if mode=='train':command+=['--benchmark-report',str(args.output/f'benchmark_{num_envs}/benchmark.json')]
        if mode=='train' and directory.exists():
            # Keep source runs untouched and restart into a fresh attempt.
            checkpoint=directory/'checkpoints/last.pth'
            if any(directory.iterdir()):
                attempts=1
                while (args.output/f'{folder}_resume_{attempts:02d}').exists():attempts+=1
                directory=args.output/f'{folder}_resume_{attempts:02d}'
                command[command.index('--output')+1]=str(directory)
                # An earlier --resume is superseded by this phase's latest weights.
                if checkpoint.exists() and '--resume' in command:
                    i=command.index('--resume');del command[i:i+2]
                if checkpoint.exists():command+=['--resume',str(checkpoint)]
        print(f'[PPO v4 pipeline] {mode}: {directory}',flush=True)
        from tavla_rl.ppo_v3.watchdog import run_command
        result=run_command(command,directory/'runtime_timing.json',directory,label=f'V4 {mode}')
        def committed_evaluation():
            state=result_file(directory,'summary.json')
            if not state or state.get('status')!='COMPLETE':return False
            cases=sorted(directory.glob('case_*/summary.json'))
            return len(cases)==state['planned']==state['completed'] and len({json.loads(c.read_text())['case']['case_id'] for c in cases})==state['planned']
        if mode=='eval' and committed_evaluation():
            # Finished, independently committed cases remain valid even if
            # simulator teardown reports an error after the final episode.
            return directory
        # Finished task cases are retained; only an unfinished infrastructure
        # attempt is retried. Evaluation worker supports identical-output resume.
        if mode=='eval':
            for retry in range(2):
                state=result_file(directory,completion)
                if state and state.get('status')=='WALL_LIMIT':break
                if result.returncode==0 and state and state.get('status')=='COMPLETE' and not (directory/'failure.json').exists():break
                print(f'[PPO v4 pipeline] reconnect evaluation {retry+1}/2; committed cases stay saved',flush=True)
                result=run_command(command,directory/'runtime_timing.json',directory,label=f'V4 {mode} retry')
                if committed_evaluation():return directory
        value=result_file(directory,completion)
        if result.returncode or (directory/'failure.json').exists() or not value:
            retries=training_retries.get(folder,0)
            if mode=='train' and retries<2 and time.monotonic()<deadline:
                training_retries[folder]=retries+1
                print(f'[PPO v4 pipeline] training recovery {retries+1}/2; resume latest committed checkpoint in a fresh worker',flush=True)
                return call(mode,folder,extra,num_envs)
            raise RuntimeError(f'{mode} interrupted; completed cases/checkpoints retained in {directory}')
        if value.get('status')=='WALL_LIMIT':raise TimeoutError(f'Weights saved at {directory}; resume this pipeline later')
        return directory
    try:
        reports=[]
        for n in (1,4,8):
            folder=call('benchmark',f'benchmark_{n}',num_envs=n)
            reports.append(result_file(folder,'benchmark.json'))
        best,fast=select_benchmark(reports)
        atomic_json(args.output/'benchmark_selection.json',dict(selected=best,reports=reports,minimum_steps_per_second=10.,passed=fast,
            sampling_hours_estimate=dict(stage1=args.stage1_steps/best['effective_steps_per_second']/3600,
                full_model_budget=args.stage2_steps/best['effective_steps_per_second']/3600),
            estimate_note='Measured zero-residual throughput; excludes validation, final comparison and extra nonzero IK cost.'))
        if not fast:
            rpc=best.get('stages',{}).get('teacher',0.)
            total=sum(best.get('stages',{}).values())
            atomic_json(args.output/'pipeline_status.json',dict(status='THROUGHPUT_GATE_FAILED',
                measured_steps_per_second=best['effective_steps_per_second'],
                rpc_major_bottleneck=rpc/max(total,1e-9)>.5,
                next_action='Optimize the measured bottleneck before long training; a separate batch server is needed only if RPC dominates.'))
            return
        n=best['num_envs']
        print(f'[PPO v4 pipeline] selected {n} envs, {best["effective_steps_per_second"]:.2f} steps/s; '
              f'stage1 sampling estimate {args.stage1_steps/best["effective_steps_per_second"]/3600:.2f}h, validation extra',flush=True)
        stage1=call('train','stage1',extra=['--total-steps',args.stage1_steps],num_envs=n)
        bank=args.output/'validation_initial_requests'
        baseline=call('eval','validation/zero',extra=['--policy','zero','--split','validation','--initial-bank',bank],num_envs=n)
        baseline_summary=result_file(baseline,'summary.json')
        def validate(run,phase):
            candidates=[]
            paths=sorted((run/'checkpoints').glob('step_*.pth'))
            if (run/'checkpoints/final.pth').exists():paths.append(run/'checkpoints/final.pth')
            seen=set()
            for path in paths:
                digest=hashlib.sha256(path.read_bytes()).hexdigest()
                if digest in seen:continue
                seen.add(digest)
                folder=call('eval',f'validation/{phase}_{path.stem}_{digest[:10]}',extra=['--policy','ppo','--checkpoint',path,
                            '--split','validation','--initial-bank',bank],num_envs=n)
                candidates.append((path,result_file(folder,'summary.json')))
            return choose(candidates,baseline_summary)
        selected=validate(stage1,'stage1')
        atomic_json(args.output/'stage1_selection.json',selected)
        if not selected['improved_over_baseline']:
            atomic_json(args.output/'pipeline_status.json',dict(status='VALIDATION_NOT_IMPROVED',
                baseline_successes=baseline_summary['successes'],ppo_successes=selected['validation']['successes'],
                next_action='Inspect failure mechanisms; stage 2 was not started.'))
            return
        stage2=call('train','stage2',extra=['--total-steps',args.stage2_steps,'--resume',selected['checkpoint']],num_envs=n)
        second=validate(stage2,'stage2')
        if second['validation']['successes']>selected['validation']['successes'] or (
                second['validation']['successes']==selected['validation']['successes'] and
                (second['validation']['mean_success_seconds'],second['validation']['mean_peak_force_n'])<
                (selected['validation']['mean_success_seconds'],selected['validation']['mean_peak_force_n'])):selected=second
        atomic_json(args.output/'selection.json',selected)
        test_bank=args.output/'test_initial_requests'
        tests={}
        for name in ('zero','geometric','ppo'):
            extra=['--policy',name,'--split','test','--initial-bank',test_bank]
            if name=='ppo':extra+=['--checkpoint',selected['checkpoint']]
            directory=call('eval',f'test/{name}',extra=extra,num_envs=n)
            tests[name]=result_file(directory,'summary.json')
        atomic_json(args.output/'results.json',dict(status='COMPLETE',experiments=tests,
            acceptance_met=tests['ppo']['successes']>=45 and tests['ppo']['successes']>tests['zero']['successes'],
            learned_advantage_over_geometric=tests['ppo']['successes']-tests['geometric']['successes']))
        print(f'[PPO v4] final: VLA={tests["zero"]["successes"]}/50; geometric={tests["geometric"]["successes"]}/50; PPO={tests["ppo"]["successes"]}/50',flush=True)
    except BaseException as exc:
        atomic_json(args.output/'pipeline_status.json',dict(status='INTERRUPTED',error=f'{type(exc).__name__}: {exc}'))
        raise


if __name__=='__main__':main()
