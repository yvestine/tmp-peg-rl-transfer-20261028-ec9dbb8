"""The V4 contract is independent of previous experiments and checkpoints."""
from dataclasses import asdict, dataclass
from pathlib import Path
import hashlib
import json
import math

ROOT = Path(__file__).resolve().parents[2]


@dataclass(frozen=True)
class Settings:
    version: int = 4
    revision: int = 1
    dt: float = .1
    seconds: float = 60.
    translation_speed: float = .005
    rotation_speed_deg: float = 1.
    xy_limit: float = .005
    z_lower: float = -.040
    z_upper: float = .010
    rotation_limit_deg: float = 5.
    gate_height: float = .035
    gate_force: float = .75
    gate_confirm: int = 2
    gate_ramp: float = .5
    calibration_xy: float = .002
    calibration_z: float = .001
    history_steps: int = 20
    horizon: int = 128
    minibatch: int = 256
    update_epochs: int = 4
    learning_rate: float = 1e-4
    gamma: float = 1.
    gae_lambda: float = .99
    clip: float = .2
    target_kl: float = .01
    force_limit: float = 7.5
    success_reward: float = 300.
    failure_penalty: float = 300.
    time_cost: float = 1.
    force_cost: float = 1.
    tilt_cost: float = .5
    smooth_cost: float = .2
    validation_seed: int = 914021
    validation_cases: int = 40
    minimum_steps_per_second: float = 10.

    def __post_init__(self):
        values = asdict(self)
        if not all(isinstance(x, (int, float)) and math.isfinite(x) for x in values.values()):
            raise ValueError('V4 settings must be finite numeric values')
        if self.version != 4 or self.revision != 1 or self.dt != .1 or self.gamma != 1.:
            raise ValueError('Unsupported V4 version/timing/discount')
        for k in ('history_steps', 'horizon', 'minibatch', 'update_epochs', 'gate_confirm', 'validation_cases'):
            if type(values[k]) is not int or values[k] <= 0:
                raise ValueError(f'{k} must be a positive integer')
        if self.z_lower >= 0 or self.z_upper <= 0 or not 0 < self.gae_lambda <= 1:
            raise ValueError('Invalid residual bounds/GAE')
        if any(v < 0 for k,v in values.items() if k != 'z_lower'):
            raise ValueError('Negative V4 scale')
        if min(self.translation_speed, self.rotation_speed_deg, self.xy_limit,
               self.rotation_limit_deg, self.gate_ramp, self.force_limit, self.learning_rate) <= 0:
            raise ValueError('Control scales must be positive')
        # Geometry potential spans 75; all running costs have explicit caps.
        if self.seconds*(self.time_cost+self.force_cost+self.tilt_cost+self.smooth_cost)+150 >= self.success_reward+self.failure_penalty:
            raise ValueError('Terminal outcomes must dominate the running costs and shaping span')

    @property
    def contract(self):
        return dict(settings=asdict(self), actions=['base_vx','base_vy','base_vz','base_wx','base_wy'],
                    action_semantics='integrated bounded offsets from live VLA; accepted slew fraction only',
                    calibration='explicit base-frame measurement, fixed episode error; no actor truth fallback',
                    control='original proportional joint slew and implicit position servo; 120 Hz physics, 10 Hz policy',
                    force='original frozen encoder and base/K XYZ convention, per-env median of first 20 samples')


def load_settings(path=None):
    return Settings(**json.loads(Path(path).read_text())) if path else Settings()


def atomic_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix('.tmp.json')
    temporary.write_text(json.dumps(value, indent=2, default=str, allow_nan=False)+'\n')
    temporary.replace(path)


def source_hashes():
    paths = list(Path(__file__).parent.glob('*.py'))
    paths += [ROOT/'tavla_rl'/f for f in ('control.py','runtime.py')]
    paths += [ROOT/'source/tacex_tasks/tacex_tasks/real2sim'/f for f in
              ('realsim_env.py','forge_env.py','sim_data_visual.py','tavla_residual_env.py',
               'realsim_env_cfg.py','tavla_residual_env_cfg.py','realsim_tasks_cfg.py','pi0_env.py','pi0_env_cfg.py',
               'policy/joint_slew.py','pi0_static_right_arm.py')]
    bundle=ROOT/'force_align_latent_sim_bundle_20261004'
    paths += [bundle/'sim_adapter.py',bundle/'assets/encoder.pt']
    paths += list((bundle/'insertion_alignment_encoder').glob('*.py'))
    paths += [ROOT/'assets/Factory/franka_mimic.usd']
    paths += [ROOT/'franka_env_background_edit/franka_env.usd']
    paths += [ROOT/f'sim-data-aligned/traj_{i}/replay_metadata.json' for i in range(40)]
    return {str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths)}
