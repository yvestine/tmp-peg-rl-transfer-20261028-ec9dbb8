"""Explicit user-run preparation: read server sources, then probe existing RPC.

Does not change the running service, checkpoint, dependencies or configuration.
Copies one inspection script to /tmp and reads policy methods in the existing
TAVLA environment. SSH authentication remains interactive in the user's tmux.
"""
import argparse
from pathlib import Path
import shlex
import subprocess
import sys
from .settings import ROOT


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--remote',default='gujiawei@114.214.164.36')
    p.add_argument('--host',default='114.214.164.36')
    p.add_argument('--remote-root',default='/data/workspace/gujiawei/TAVLA')
    p.add_argument('--remote-python',help='Defaults to <remote-root>/.venv/bin/python')
    p.add_argument('--output',type=Path,default=ROOT/'outputs/tavla_rl/ppo_v4_probe')
    args=p.parse_args()
    args.output.mkdir(parents=True,exist_ok=True)
    remote_script='/tmp/tavla_ppo_v4_server_audit.py'
    remote_result='/tmp/tavla_ppo_v4_server_audit.json'
    subprocess.run(['scp',str(Path(__file__).with_name('server_audit.py')),f'{args.remote}:{remote_script}'],check=True)
    command=['env','CUDA_VISIBLE_DEVICES=','JAX_PLATFORMS=cpu','XLA_PYTHON_CLIENT_PREALLOCATE=false','OMP_NUM_THREADS=1',
             f'PYTHONPATH={args.remote_root}/src:{args.remote_root}/packages/openpi-client/src',
             args.remote_python or f'{args.remote_root}/.venv/bin/python',remote_script,
             '--launcher',f'{args.remote_root}/scripts/serve_force_align_latent_cotrain.py','--output',remote_result]
    subprocess.run(['ssh',args.remote,shlex.join(command)],check=True)
    source=args.output/'server_source_audit.json'
    subprocess.run(['scp',f'{args.remote}:{remote_result}',str(source)],check=True)
    subprocess.run([sys.executable,'-u','-B','-m','tavla_rl.ppo_v4.probe','--host',args.host,
                    '--server-audit',str(source),'--output',str(args.output)],check=True,cwd=ROOT)
    print(f'[PPO v4] server audit and RPC probe saved: {args.output}/server_audit.json',flush=True)


if __name__=='__main__':main()
