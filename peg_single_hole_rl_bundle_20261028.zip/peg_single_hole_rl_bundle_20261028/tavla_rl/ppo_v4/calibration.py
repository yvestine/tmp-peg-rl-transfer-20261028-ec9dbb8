"""Only this provider can turn a measurement into Actor hole information."""
import json
from pathlib import Path
import numpy as np
import torch


class HoleCalibration:
    def __init__(self, count, settings, device='cpu', *, source='simulated', measurements=None):
        if source not in ('simulated','measured'):
            raise ValueError('Explicit simulated or measured calibration required')
        self.source, self.settings = source, settings
        self.measurements = json.loads(Path(measurements).read_text()) if measurements else None
        if source == 'measured' and self.measurements is None:
            raise ValueError('Measured calibration requires a file; simulator truth is never a fallback')
        if self.measurements is not None and self.measurements.get('coordinate_frame') != 'robot_base':
            raise ValueError('Calibration file must declare coordinate_frame=robot_base')
        if self.measurements is not None and self.measurements.get('reference') != 'insertion_target':
            raise ValueError('Calibration reference must be insertion_target (fixed asset root), not the hole mouth')
        self.position = torch.zeros(count,3,device=device)
        self.uncertainty = torch.zeros_like(self.position)
        self.valid = torch.zeros(count,dtype=torch.bool,device=device)

    def reset(self, ids, episode_keys, seeds, *, simulator_hole_base=None):
        ids = torch.as_tensor(ids,device=self.position.device,dtype=torch.long)
        if not (len(ids) == len(episode_keys) == len(seeds)):
            raise ValueError('Calibration episode list mismatch')
        rows, bounds = [], []
        if self.source == 'measured' and simulator_hole_base is not None:
            raise ValueError('Measured provider must not receive simulator truth')
        for j,key in enumerate(episode_keys):
            if self.source == 'simulated':
                if simulator_hole_base is None:
                    raise ValueError('Simulated measurement requires an explicitly supplied simulator pose')
                limit = np.array([self.settings.calibration_xy]*2+[self.settings.calibration_z])
                error = np.random.default_rng(int(seeds[j])).uniform(-limit,limit)
                rows.append(torch.as_tensor(simulator_hole_base[j]).detach().cpu().numpy()+error)
                bounds.append(limit)
            else:
                entry = self.measurements.get('episodes',{}).get(str(key))
                if not entry or entry.get('valid') is not True:
                    raise ValueError(f'Missing/invalid measured hole calibration: {key}')
                rows.append(entry['position_m']); bounds.append(entry['error_bound_m'])
        positions = torch.as_tensor(np.asarray(rows),device=self.position.device,dtype=torch.float32)
        errors = torch.as_tensor(np.asarray(bounds),device=self.position.device,dtype=torch.float32)
        if positions.shape != (len(ids),3) or errors.shape != positions.shape or not bool(torch.isfinite(positions).all() & torch.isfinite(errors).all()) or bool((errors<0).any()):
            raise ValueError('Calibration must contain finite XYZ positions and nonnegative XYZ bounds')
        self.position[ids],self.uncertainty[ids],self.valid[ids] = positions,errors,True

    def observe(self, estimated_tip_base):
        if not bool(self.valid.all()):
            raise RuntimeError('Actor observation requested without valid calibration')
        return dict(relative_hole=(estimated_tip_base-self.position),
                    calibration_error_bound=self.uncertainty.clone(),calibration_valid=self.valid.float()[:,None])
