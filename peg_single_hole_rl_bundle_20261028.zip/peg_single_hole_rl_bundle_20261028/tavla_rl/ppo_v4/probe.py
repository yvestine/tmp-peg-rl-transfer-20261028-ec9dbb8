"""Explicitly invoked CPU client probe. It sends saved observations, never simulates."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
import time
import numpy as np
from tavla_rl.runtime import make_client
from .settings import ROOT,atomic_json


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--host',default='114.214.164.36')
    p.add_argument('--server-audit',type=Path,required=True)
    p.add_argument('--requests',type=int,default=8)
    p.add_argument('--output',type=Path,required=True)
    args=p.parse_args()
    audit=json.loads(args.server_audit.read_text())
    if audit.get('status')!='PASS':raise ValueError('Server state/reset audit did not pass; do not mix environment episodes')
    with np.load(ROOT/'force_align_latent_sim_bundle_20261004/reference/single_request.npz') as d:
        payload=dict(state=d['state'],effort=d['effort'],prompt='peg-in-hole',images=dict(cam_high=d['front_rgb'],cam_left_wrist=d['wrist_rgb'],cam_right_wrist=d['wrist_rgb']))
    report=dict(status='RUNNING',server_audit=audit,measurements=[],not_batched_inference=True)
    for count in (1,4,8):
        clients=[]
        try:
            clients=[make_client(args.host) for _ in range(count)]
            meta=clients[0].server_metadata
            if any(c.server_metadata!=meta for c in clients):raise ValueError('Server identities differ')
            for c in clients:c.reset()
            started=time.monotonic()
            def run(i):
                latencies=[]
                for _ in range(args.requests):
                    t=time.monotonic();clients[i].infer(payload);latencies.append(time.monotonic()-t)
                return latencies
            with ThreadPoolExecutor(max_workers=count) as executor:
                times=list(executor.map(run,range(count)))
            duration=time.monotonic()-started
            report['measurements'].append(dict(connections=count,requests=count*args.requests,wall_seconds=duration,
                requests_per_second=count*args.requests/duration,latency_p95_seconds=float(np.quantile(times,.95))))
            # Reset one session and check every other connection still responds.
            # Semantic independence is established by the source audit, not by
            # comparing stochastic VLA actions for equality.
            clients[0].reset()
            for c in clients[1:]:c.infer(payload)
        finally:
            for c in clients:c.close()
        print(f"[V4 probe] {count} connections: {report['measurements'][-1]['requests_per_second']:.2f} requests/s",flush=True)
    audit['server_metadata']=meta
    atomic_json(args.output/'server_audit.json',audit)
    report['status']='PASS';atomic_json(args.output/'probe.json',report)


if __name__=='__main__':main()
