"""One in-flight request per socket; explicit episode tokens prevent stale replies."""
from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
import threading
import time
import numpy as np
from tavla_rl.runtime import make_client


class TeacherPool:
    def __init__(self,count,host,*,concurrency=1,audit=None,client_factory=make_client):
        if not 1<=concurrency<=count:raise ValueError('RPC concurrency must be in 1..num_envs')
        if count>1:
            if audit is None:raise ValueError('Parallel RPC requires --server-audit from the read-only server audit; run probe first')
            proof=json.loads(Path(audit).read_text())
            if proof.get('status')!='PASS' or proof.get('inference_state')!='stateless' or proof.get('reset_scope')!='no_op':
                raise ValueError('Parallel training requires verified stateless infer and no-op reset, or a session-aware server')
        self.clients=[]
        try:
            for _ in range(count):self.clients.append(client_factory(host,8001))
        except BaseException:
            self.close();raise
        metadata=self.clients[0].server_metadata
        if any(c.server_metadata!=metadata for c in self.clients):
            self.close();raise ValueError('Teacher connection identities differ')
        self.metadata=metadata
        if count>1 and proof.get('server_metadata')!=metadata:
            self.close();raise ValueError('Server audit metadata differs from the live deployment')
        self.executor=ThreadPoolExecutor(max_workers=concurrency,thread_name_prefix='v4-vla')
        self.tokens=np.zeros(count,np.int64)
        self.locks=[threading.Lock() for _ in range(count)]
        self.requests=0;self.seconds=0.;self.last_hashes={}

    def reset(self,env_id):
        with self.locks[env_id]:
            self.tokens[env_id]+=1
            self.clients[env_id].reset()

    def infer(self,payloads):
        started=time.monotonic()
        def one(env_id,observation,token):
            with self.locks[env_id]:
                if token!=self.tokens[env_id]:raise RuntimeError('Stale teacher request before send')
                result=self.clients[env_id].infer(observation)['actions']
                if token!=self.tokens[env_id]:raise RuntimeError('Stale teacher response after reset')
                a=np.asarray(result,np.float32)
                if a.shape!=(50,8) or not np.isfinite(a).all():raise ValueError('Invalid 8001 chunk')
                if np.any((a[:,7]<-1e-5)|(a[:,7]>1+1e-5)):raise ValueError('Invalid 8001 gripper range')
                return env_id,a.copy()
        futures=[self.executor.submit(one,i,p,int(self.tokens[i])) for i,p in payloads.items()]
        result={}
        try:
            for future in futures:
                i,a=future.result();result[i]=a
        except BaseException:
            for f in futures:f.cancel()
            raise  # Never retry a request in the middle of a physical episode.
        self.requests+=len(result);self.seconds+=time.monotonic()-started
        return result

    def close(self):
        if hasattr(self,'executor'):self.executor.shutdown(wait=True,cancel_futures=True)
        for c in getattr(self,'clients',[]):
            try:c.close()
            except Exception:pass
