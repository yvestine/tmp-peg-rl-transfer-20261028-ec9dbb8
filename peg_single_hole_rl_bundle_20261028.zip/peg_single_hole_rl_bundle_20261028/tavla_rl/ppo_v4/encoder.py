"""Independent baseline, features and latents for every environment; one frozen model."""
import torch
from tavla_rl.runtime import load_streaming_encoder


class BatchedEncoder:
    def __init__(self,count,device='cpu',reference=None):
        reference=reference or load_streaming_encoder()
        source=reference.encoder
        self.model=source.model.to(device).eval().requires_grad_(False)
        self.scales=torch.as_tensor(source.scales,device=device)
        self.count=count; self.history=source.history
        self.samples=torch.zeros(count,dtype=torch.long,device=device)
        self.startup=torch.zeros(count,20,3,device=device)
        self.baseline=torch.zeros(count,3,device=device)
        self.previous=torch.zeros_like(self.baseline)
        self.features=torch.zeros(count,self.history,6,device=device)
        self.latents=torch.zeros(count,10,32,device=device)

    def reset(self,ids):
        for v in (self.samples,self.startup,self.baseline,self.previous,self.features,self.latents): v[ids]=0

    @property
    def ready(self): return self.samples>=20

    @torch.inference_mode()
    def update(self,force,valid):
        if force.shape!=self.baseline.shape or not bool(torch.isfinite(force).all()):
            raise ValueError('Expected finite N x 3 encoder force')
        startup=valid & (self.samples<20)
        ids=startup.nonzero().flatten()
        self.startup[ids,self.samples[ids]]=force[ids]
        newly=startup & (self.samples==19)
        established=valid & self.ready
        ids=newly.nonzero().flatten()
        if len(ids):
            ordered=self.startup[ids].sort(dim=1).values
            self.baseline[ids]=(ordered[:,9]+ordered[:,10])*.5
            f=self.startup[ids]-self.baseline[ids,None]
            delta=torch.cat((torch.zeros_like(f[:,:1]),(f[:,1:]-f[:,:-1])/.1),1)
            feats=(torch.cat((f,delta),-1)/self.scales).clamp(-10,10)
            # Genuine startup history: same edge padding and backfilled 20 latents.
            positions=torch.arange(self.history,device=f.device)[None,:]-self.history+1+torch.arange(20,device=f.device)[:,None]
            windows=feats[:,positions.clamp_min(0)]
            out=self.model(windows.reshape(-1,self.history,6))[0].reshape(len(ids),20,32)
            self.latents[ids]=out[:,-10:]
            self.features[ids]=feats[:,(torch.arange(self.history,device=f.device)-self.history+20).clamp_min(0)]
            self.previous[ids]=f[:,-1]
        ids=established.nonzero().flatten()
        if len(ids):
            f=force[ids]-self.baseline[ids]
            feature=(torch.cat((f,(f-self.previous[ids])/.1),-1)/self.scales).clamp(-10,10)
            self.features[ids]=torch.cat((self.features[ids,1:],feature[:,None]),1)
            out=self.model(self.features[ids])[0]
            self.latents[ids]=torch.cat((self.latents[ids,1:],out[:,None]),1)
            self.previous[ids]=f
        self.samples += valid.long()
        return self.latents
