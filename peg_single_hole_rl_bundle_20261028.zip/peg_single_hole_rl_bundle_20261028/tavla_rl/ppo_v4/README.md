# PPO V4

独立版本；不修改 V1/V2/V3 或已有结果。8001 权重保持冻结，PPO 无图像分支，VLA 继续读取原两路图像。

## 使用

首次先准备服务检查：只读检查远端 Python 源码，向现有 8001 发送参考请求，测量 1/4/8 个连接，不启动 Isaac、不修改或重启 8001。SSH 需要在你的 tmux 中完成认证。

```bash
cd /home/gujiawei/isaac_env
/home/gujiawei/env_isaaclab/bin/python -u -B -m tavla_rl.ppo_v4.prepare
```

默认远端仓库 `/data/workspace/gujiawei/TAVLA`，Python 为该目录下 `.venv/bin/python`；可用 `--remote-root` 和 `--remote-python` 指定实际路径。审计脚本单独复制到远端 `/tmp`，不会编辑远端仓库。检查结果保存在 `outputs/tavla_rl/ppo_v4_probe/`。

完整串行流程：

```bash
cd /home/gujiawei/isaac_env && bash scripts/run_peg_pose_ppo_v4.sh
```

顺序为：1/4/8 环境基准 → 20 万步 → 40 条独立验证 → 有改善才扩至累计 100 万步 → 验证选模 → 三组各 50 条。默认整个流程墙钟预算 8 小时；到时保存，可重新运行同一条流水线命令续跑。每阶段 stdout/stderr 留在 tmux，不重定向 `.log`。JSON、NPZ 为实验结果，不是终端日志。

基准要求 reset 隔离、相同起点的克隆相机平均像素差不超过 3/255、总 GPU 已用显存低于 80%、有效吞吐至少 10 控制步/秒。失败时不会启动长训，结果给出实际瓶颈。多个连接不代表服务端已经支持批量计算；默认 RPC 并发为 1。此版本不自动修改远端服务来绕过失败。

单独训练：

```bash
cd /home/gujiawei/isaac_env && bash scripts/train_peg_pose_ppo_v4.sh \
  --num-envs 8 --total-steps 200000 \
  --output outputs/tavla_rl/ppo_pose_v4_stage1
```

续训必须使用新输出目录；`total-steps` 是包含之前训练量的累计目标：

```bash
cd /home/gujiawei/isaac_env && bash scripts/train_peg_pose_ppo_v4.sh \
  --num-envs 8 --total-steps 1000000 \
  --resume outputs/tavla_rl/ppo_pose_v4_stage1/checkpoints/last.pth \
  --output outputs/tavla_rl/ppo_pose_v4_stage2
```

单独训练同样会验证前面生成的对应环境数基准；自定义流水线目录时用 `--benchmark-report` 指向其 `benchmark_N/benchmark.json`。一个物理 tick 必须同时推进整批环境，因此总交互量可能比目标最多多 N−1 步，统计记录实际值。

## 控制、观测与奖励

- 5 维动作表示残差变化率：XYZ 最大 5 mm/s、两个倾斜轴最大 1°/s。累计 XY 各 ±5 mm、Z −40～+10 mm、角度各 ±5°；跨 chunk 保留，reset 清零。只有被 IK 接受且经过限速实际可实现的增量进入积分状态。
- 接触或距估计孔位 35 mm 时渐入，0.5 秒达到完整权限；之后持续至 episode 结束。高度来自机器人 fingertip 测量与固定 peg 安装变换，不再混用 FK 高度和 PhysX 根坐标高度。真实 peg 位姿不进入 Actor。
- 保留 120 Hz 物理、10 Hz 控制、原绝对关节目标、比例限速和 200/40 位置伺服。零积分状态加全零动作保持名义关节目标；夹爪仍使用原归一化及 2/s 变化率限制。
- 奖励为原 V3 几何势能增量、成功 +300/失败 −300、每秒 −1、有界超载/倾斜/平滑代价。7.5 N 以下接触不罚，不奖励单纯负 Z 输出，不保留硬阈值上抬、重复停滞及零均值先验。
- 每个环境独立关闭夹爪、稳定和采集 20 帧力基线；reset 不调用物理步进，也不修改其他环境状态。预热不进入 Actor 或 Critic 损失。
- 只有接触权限开启的真实交互步进入 Actor；Critic/GAE 保留所有正式交互，包含接近阶段。GAE 按每环境时间顺序计算，终止不 bootstrap，rollout 截断正常 bootstrap。
- 使用共享冻结 encoder 的批量前向；每环境独立前 20 帧中位数、32 帧特征窗口和 10 帧 latent。CPU 回归比较原适配器，包括偶数帧中位数和启动历史回填。

## 标定输入

默认 `--hole-pose-source simulated`：仿真真孔位由独立 provider 转成一次测量，叠加本回合固定误差，XY 各均匀 ±2 mm、Z 均匀 ±1 mm。训练和验证/测试一致；这是**模拟标定**，不等于视觉识别或已完成真机部署。机器人、孔的物理初始化不受测量误差影响。

`--hole-pose-source measured --hole-calibration measurements.json` 只接受外部标定，不接收仿真孔位兜底。示例格式：

```json
{
  "coordinate_frame": "robot_base",
  "reference": "insertion_target",
  "episodes": {
    "test:0": {
      "valid": true,
      "position_m": [0.4, 0.1, 0.05],
      "error_bound_m": [0.002, 0.002, 0.001]
    }
  }
}
```

键为 `train:<case_id>`、`validation:<case_id>`、`test:<case_id>`。位置参考点为完全插入时的 peg 底端目标，即固定孔件的根参考点；如果测量的是孔口，须先根据孔件 CAD 深度转换。坐标必须与提供机器人本体测量的基坐标系一致；缺失、无效、非有限值或错误参考点声明均停止。

## 选择、比较与恢复

训练仅采样原 40 个关节起点和新的孔 XY ±5 cm；孔 Z、朝向、物理、视觉固定。验证种子独立，40 个起点各一次。训练/验证不读取历史 50 条测试位置。

每 5 万实际交互步保存候选，另存 final/last。独立验证依次比较成功数、成功耗时和平均 episode 峰值力；训练 reward 不直接决定最终模型。20 万步验证没有超过同协议纯 8001 时停止，不盲目续至 100 万。

最终三组为：纯 8001、8001＋几何纠偏、8001＋PPO，各 50 条、一次。后两组共享同一份带误差标定条件。第一批 VLA 输入/动作按 case 共享，先检查机器人和 force latent 一致；后续 VLA 请求保持闭环在线。此机制不会回放整条轨迹，也不能消除远端后续随机采样的差异。

进程/通信异常不计为任务失败；有效失败回合只提交一次。流水线对训练和评测分别最多自动恢复两次；评测仅补未完成 case。训练保存网络、优化器、采样器和 RNG，在新输出目录恢复时重新开始物理回合，不复用旧 rollout。此前 50 条已经用于诊断，因此最终结果称历史回归，不宣称新的未见测试集。

验收目标：PPO ≥45/50 且超过同协议纯 8001；同时报告几何控制对照，判断收益是否来自 RL。代码不能保证训练达到目标。

## 检查

```bash
/home/gujiawei/env_isaaclab/bin/python -B -m unittest discover -s tavla_rl/ppo_v4/tests -v
```

CPU 检查不会启动 Isaac 或远端推理。实际 GPU reset、相机一致性、物理控制和吞吐必须由运行时基准确认；本版本不能把 CPU 检查写成 GPU 验证通过。
