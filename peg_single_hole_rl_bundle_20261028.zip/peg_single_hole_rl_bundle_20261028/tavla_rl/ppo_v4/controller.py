"""Batched latch, bounded integrator, SO(3), USD FK and residual IK; no Isaac imports."""
import importlib.util
import math
import torch
from .settings import ROOT


def quat_matrix(q):
    q = q/torch.linalg.vector_norm(q,dim=-1,keepdim=True).clamp_min(1e-12)
    x,y,z,w = q.unbind(-1)
    return torch.stack((1-2*(y*y+z*z),2*(x*y-z*w),2*(x*z+y*w),
                        2*(x*y+z*w),1-2*(x*x+z*z),2*(y*z-x*w),
                        2*(x*z-y*w),2*(y*z+x*w),1-2*(x*x+y*y)),dim=-1).reshape(*q.shape[:-1],3,3)


def rotation_exp(v):
    x,y,z = v.unbind(-1); zero = torch.zeros_like(x)
    k=torch.stack((zero,-z,y,z,zero,-x,-y,x,zero),-1).reshape(-1,3,3)
    a=torch.linalg.vector_norm(v,dim=-1).reshape(-1,1,1)
    eye=torch.eye(3,device=v.device,dtype=v.dtype).expand_as(k)
    return eye+torch.sinc(a/math.pi)*k+.5*torch.sinc(a/(2*math.pi)).square()*(k@k)


def rotation_log(r):
    c=((r.diagonal(dim1=-2,dim2=-1).sum(-1)-1)/2).clamp(-1,1)
    a=torch.acos(c)
    v=torch.stack((r[:,2,1]-r[:,1,2],r[:,0,2]-r[:,2,0],r[:,1,0]-r[:,0,1]),-1)
    factor=torch.where(a<1e-5,.5+a.square()/12,a/(2*torch.sin(a).clamp_min(1e-8)))
    return v*factor[:,None]


class ContactLatch:
    def __init__(self,count,settings,device='cpu'):
        self.cfg=settings
        self.active=torch.zeros(count,dtype=torch.bool,device=device)
        self.confirm=torch.zeros(count,dtype=torch.long,device=device)
        self.gate=torch.zeros(count,device=device)

    def reset(self,ids):
        self.active[ids]=False; self.confirm[ids]=0; self.gate[ids]=0

    def update(self,force,estimated_height,valid):
        hit=torch.linalg.vector_norm(force,dim=-1)>=self.cfg.gate_force
        self.confirm=torch.where(valid,torch.where(hit,self.confirm+1,torch.zeros_like(self.confirm)),self.confirm)
        self.active |= valid & ((estimated_height<=self.cfg.gate_height) | (self.confirm>=self.cfg.gate_confirm))
        self.gate=torch.where(valid & self.active,(self.gate+self.cfg.dt/self.cfg.gate_ramp).clamp_max(1),self.gate)
        return self.gate.clone()


class ResidualIntegrator:
    def __init__(self,count,settings,device='cpu'):
        self.cfg=settings
        self.offset=torch.zeros(count,5,device=device)
        self.lower=self.offset.new_tensor([-settings.xy_limit]*2+[settings.z_lower]+[-math.radians(settings.rotation_limit_deg)]*2)
        self.upper=self.offset.new_tensor([settings.xy_limit]*2+[settings.z_upper]+[math.radians(settings.rotation_limit_deg)]*2)
        self.speed=self.offset.new_tensor([settings.translation_speed]*3+[math.radians(settings.rotation_speed_deg)]*2)

    def reset(self,ids): self.offset[ids]=0

    def propose(self,action,gate):
        if action.shape!=self.offset.shape or not bool(torch.isfinite(action).all()):
            raise ValueError('Expected finite N x 5 residual-rate actions')
        self.proposed=(self.offset+action.clamp(-1,1)*gate[:,None]*self.speed*self.cfg.dt).clamp(self.lower,self.upper)
        return self.proposed.clone()

    def commit(self,accepted,fraction):
        # Back-calculation: only the realizable increment enters integrator memory.
        fraction=torch.as_tensor(fraction,device=self.offset.device).reshape(-1,1).clamp(0,1)
        self.offset += torch.where(accepted[:,None],fraction*(self.proposed-self.offset),torch.zeros_like(self.offset))
        return self.offset.clone()


class BatchedFK:
    """Exact tensor transcription of the archived asset's row-matrix FK."""
    def __init__(self,cache,device='cpu',dtype=torch.float32):
        self.inv7=torch.as_tensor(cache[0],device=device,dtype=dtype)
        self.tip=torch.as_tensor(cache[1],device=device,dtype=dtype)
        self.frames=[(torch.as_tensor(a,device=device,dtype=dtype),torch.as_tensor(b,device=device,dtype=dtype)) for a,b in cache[2]]

    @classmethod
    def from_asset(cls,device='cpu',dtype=torch.float32):
        spec=importlib.util.spec_from_file_location('_v4_asset_fk',ROOT/'source/tacex_tasks/tacex_tasks/real2sim/policy/force_align_diagnostics.py')
        module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
        return cls(module.AssetFK(ROOT).cache,device,dtype)

    def __call__(self,q):
        parent=torch.eye(4,device=q.device,dtype=q.dtype).repeat(len(q),1,1)
        for j,(f0,f1) in enumerate(self.frames):
            r=torch.eye(4,device=q.device,dtype=q.dtype).repeat(len(q),1,1)
            c,s=torch.cos(q[:,j]),torch.sin(q[:,j])
            r[:,0,0]=c; r[:,0,1]=s; r[:,1,0]=-s; r[:,1,1]=c
            parent=f1@r@f0@parent
        result=self.tip@self.inv7@parent
        return result[:,3,:3],result[:,:3,:3].transpose(-1,-2)

    def jacobian(self,q):
        eye=torch.eye(7,device=q.device,dtype=q.dtype)*1e-4
        batch=torch.cat((q[:,None,:]+eye,q[:,None,:]-eye),1).reshape(-1,7)
        p,r=self(batch); p=p.reshape(len(q),14,3); r=r.reshape(len(q),14,3,3)
        linear=(p[:,:7]-p[:,7:])/2e-4
        angular=rotation_log((r[:,:7]@r[:,7:].transpose(-1,-2)).reshape(-1,3,3)).reshape(len(q),7,3)/2e-4
        return torch.cat((linear,angular),-1).transpose(1,2)

    def ik(self,nominal,offset,lower,upper):
        if not bool(torch.isfinite(nominal).all() & torch.isfinite(offset).all()):
            raise FloatingPointError('Nonfinite IK request')
        p,r=self(nominal)
        rot=torch.cat((offset[:,3:],torch.zeros_like(offset[:,:1])),-1)
        goal_p=p+offset[:,:3]; goal_r=rotation_exp(rot)@r
        q=nominal.clone(); zero=(offset==0).all(-1)
        weights=q.new_tensor([1,1,1,.15,.15,.15])
        for _ in range(24):
            p,r=self(q); pe=goal_p-p; re=rotation_log(goal_r@r.transpose(-1,-2))
            done=(torch.linalg.vector_norm(pe,dim=-1)<=1e-5)&(torch.linalg.vector_norm(re,dim=-1)<=.005)
            if bool((done|zero).all()): break
            j=self.jacobian(q)*weights[None,:,None]
            e=torch.cat((pe,re),-1)*weights
            dq=(j.transpose(1,2)@torch.linalg.solve(j@j.transpose(1,2)+torch.eye(6,device=q.device,dtype=q.dtype)*1e-5,e[:,:,None])).squeeze(-1)
            dq*= (.04/dq.abs().amax(-1,keepdim=True).clamp_min(1e-12)).clamp_max(1)
            q=torch.where((done|zero)[:,None],q,(q+dq).clamp(lower,upper))
        p,r=self(q)
        accepted=(torch.linalg.vector_norm(goal_p-p,dim=-1)<=1e-5)&(torch.linalg.vector_norm(rotation_log(goal_r@r.transpose(-1,-2)),dim=-1)<=.005)
        accepted |= zero
        return torch.where((accepted & ~zero)[:,None],q,nominal),accepted
