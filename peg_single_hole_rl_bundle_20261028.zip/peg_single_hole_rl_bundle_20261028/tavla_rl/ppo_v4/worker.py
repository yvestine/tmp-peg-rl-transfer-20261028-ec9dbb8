"""Isaac worker entry. Run explicitly; imports/help are safe on a CPU machine."""
from contextlib import contextmanager
from dataclasses import asdict
import hashlib
import json
import os
from pathlib import Path
import random
import sys
import tempfile
import time
import numpy as np
import torch
from .settings import ROOT,atomic_json,source_hashes
from .cli import parse


@contextmanager
def environment(args,cfg,sampler):
    from pxr import Usd,UsdGeom
    from .rpc import TeacherPool
    from .environment import VectorPegEnv
    from .evaluation import InitialRequestBank
    old=os.environ.get('TACEX_BACKGROUND_USD')
    fd,name=tempfile.mkstemp(prefix='tavla_v4_background_',suffix='.usd');os.close(fd)
    env=pool=None
    try:
        stage=Usd.Stage.CreateNew(name)
        root=UsdGeom.Xform.Define(stage,'/World');root.GetPrim().GetReferences().AddReference(str(ROOT/'franka_env_background_edit/franka_env.usd'),'/World')
        stage.SetDefaultPrim(root.GetPrim());stage.OverridePrim('/World/PhysicsScene').SetActive(False);stage.GetRootLayer().Save()
        os.environ['TACEX_BACKGROUND_USD']=name
        pool=TeacherPool(args.num_envs,args.host,concurrency=args.rpc_concurrency,audit=args.server_audit)
        bank=InitialRequestBank(args.initial_bank) if args.initial_bank else None
        env=VectorPegEnv(args,cfg,sampler,pool,initial_bank=bank)
        yield env
    finally:
        if env is not None:env.close()
        if pool is not None:pool.close()
        if old is None:os.environ.pop('TACEX_BACKGROUND_USD',None)
        else:os.environ['TACEX_BACKGROUND_USD']=old
        Path(name).unlink(missing_ok=True)


def checkpoint(path,learner,env,steps,actor_steps,cfg):
    value=dict(version=4,revision=1,settings=asdict(cfg),sources=source_hashes(),
        learner=learner.state_dict(),steps=steps,actor_steps=actor_steps,contract=env.contract,
        observer=dict(episodes=getattr(env,'prior_episodes',0)+len(env.rows),
                      successes=getattr(env,'prior_successes',0)+sum(r['success'] for r in env.rows)),
        sampler=env.sampler.state_dict(),torch_rng=torch.get_rng_state(),
        cuda_rng=torch.cuda.get_rng_state_all() if next(learner.policy.parameters()).is_cuda else [],
        numpy_rng=np.random.get_state(),python_rng=random.getstate())
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix('.tmp.pth');torch.save(value,tmp);tmp.replace(path)


def load_checkpoint(path,policy,cfg,*,learner=None,env=None):
    saved=torch.load(path,map_location=next(policy.parameters()).device,weights_only=False)
    if saved.get('version')!=4 or saved.get('settings')!=asdict(cfg):raise ValueError('V4 checkpoint/settings mismatch; V1/V2/V3 are incompatible')
    if saved['sources']!=source_hashes():raise ValueError('V4 code changed since this checkpoint; use an explicitly versioned new experiment')
    policy.load_state_dict(saved['learner']['policy'])
    if env is not None and saved['contract']!=json.loads(json.dumps(env.contract,default=str)):
        # Tuple/list normalization only; parallel count is intentionally absent.
        if json.loads(json.dumps(saved['contract']))!=json.loads(json.dumps(env.contract)):raise ValueError('Training/evaluation environment contract changed')
    if learner is not None:
        learner.load_state_dict(saved['learner'])
        if env is not None:env.sampler.load_state_dict(saved['sampler'])
        if env is not None:
            env.prior_episodes=saved.get('observer',{}).get('episodes',0)
            env.prior_successes=saved.get('observer',{}).get('successes',0)
        torch.set_rng_state(saved['torch_rng'].cpu())
        if saved['cuda_rng'] and torch.cuda.is_available():torch.cuda.set_rng_state_all(saved['cuda_rng'])
        np.random.set_state(saved['numpy_rng']);random.setstate(saved['python_rng'])
    return saved


def train(args,cfg,env):
    from .environment import ACTOR_DIM,CRITIC_DIM
    from .learner import Policy,PPO
    torch.manual_seed(args.seed)
    policy=Policy(ACTOR_DIM,CRITIC_DIM).to(args.device);learner=PPO(policy,cfg)
    steps=actor_steps=0
    if args.resume:
        saved=load_checkpoint(args.resume,policy,cfg,learner=learner,env=env)
        steps=saved['steps'];actor_steps=saved['actor_steps']
        # Restore sampling before installing fresh physical episodes. No partial
        # simulation state or previous-policy rollout is reused.
        env.reset()
    if steps>=args.total_steps:raise ValueError('--total-steps must exceed restored learned steps')
    start_steps=steps
    next_save=(steps//args.checkpoint_every+1)*args.checkpoint_every
    deadline=getattr(args,'deadline',time.monotonic()+args.wall_hours*3600)
    obs=env.observe();started=time.monotonic();last_report=started
    recent=[]
    while steps<args.total_steps and time.monotonic()<deadline:
        rows=[];sampled=0
        for _ in range(cfg.horizon):
            action,log,value=policy.act(obs)
            action=torch.where(obs['actor_valid'][:,None],action,torch.zeros_like(action))
            next_obs,rew,done,info=env.step(action)
            with torch.no_grad():next_value=policy.value(next_obs['critic'])
            row=dict(actor=obs['actor'].detach(),critic=obs['critic'].detach(),action=action.detach(),
                     log_prob=log.detach(),value=value.detach(),next_value=next_value.detach(),reward=rew.detach(),
                     done=done.detach(),valid=info['valid'].detach(),actor_valid=info['actor_valid'].detach())
            rows.append(row);sampled+=int(info['valid'].sum())
            recent.extend(info['episodes']);obs=next_obs
            if info['episodes']:
                with (args.output/'episodes.jsonl').open('a') as handle:
                    for result in info['episodes']:handle.write(json.dumps(result,allow_nan=False)+'\n')
            if steps+sampled>=args.total_steps or time.monotonic()>=deadline:break
        metrics=learner.update(rows)
        steps+=sampled;actor_steps+=sum(int(r['actor_valid'].sum()) for r in rows)
        checkpoint(args.output/'checkpoints/last.pth',learner,env,steps,actor_steps,cfg)
        if steps>=next_save:
            checkpoint(args.output/f'checkpoints/step_{steps:09d}.pth',learner,env,steps,actor_steps,cfg)
            next_save+=args.checkpoint_every
        if time.monotonic()-last_report>=15 or steps>=args.total_steps:
            last_report=time.monotonic()
            completed=getattr(env,'prior_episodes',0)+len(recent)
            success=getattr(env,'prior_successes',0)+sum(r['success'] for r in recent)
            report=dict(status='RUNNING',sampled_steps=steps,total_steps=args.total_steps,actor_steps=actor_steps,
                        updates=learner.updates,episodes=completed,successes=success,metrics=metrics,
                        measured_steps_per_second=(steps-(saved['steps'] if args.resume else 0))/max(1,time.monotonic()-started),
                        **{k:v for k,v in env.progress().items() if k not in ('episodes',)})
            atomic_json(args.output/'training_progress.json',report)
            atomic_json(args.output/'runtime_timing.json',env.progress())
            print(f'[PPO v4] steps={steps}/{args.total_steps}; actor={actor_steps}; update={learner.updates}; episodes={completed}; successes={success}; active={metrics["actor_samples"]}; KL={metrics["kl"]:.5f}',flush=True)
    checkpoint(args.output/'checkpoints/last.pth',learner,env,steps,actor_steps,cfg)
    complete=steps>=args.total_steps
    checkpoint(args.output/'checkpoints/final.pth' if complete else args.output/'checkpoints/wall_limit.pth',learner,env,steps,actor_steps,cfg)
    atomic_json(args.output/'training_summary.json',dict(status='COMPLETE' if complete else 'WALL_LIMIT',
                sampled_steps=steps,actor_steps=actor_steps,episodes=getattr(env,'prior_episodes',0)+len(recent),
                successes=getattr(env,'prior_successes',0)+sum(r['success'] for r in recent),
                sampled_before_run=start_steps,interactions_this_run=steps-start_steps,
                next_checkpoint=str(args.output/'checkpoints/last.pth')))


def evaluate(args,cfg,env):
    from .environment import ACTOR_DIM,CRITIC_DIM,ACTOR_FIELDS
    from .learner import Policy
    from .evaluation import geometric_action,summarize
    policy=Policy(ACTOR_DIM,CRITIC_DIM).to(args.device)
    if args.policy=='ppo':load_checkpoint(args.checkpoint,policy,cfg,env=env)
    obs=env.observe();planned=40 if args.split=='validation' else 50
    while len(env.rows)<planned:
        if time.monotonic()>=getattr(args,'deadline',float('inf')):
            report=summarize(env.rows);report.update(status='WALL_LIMIT',policy=args.policy,planned=planned)
            atomic_json(args.output/'summary.json',report)
            return
        if args.policy=='ppo':action=policy.act(obs,deterministic=True)[0]
        elif args.policy=='geometric':action=geometric_action(obs,ACTOR_FIELDS,cfg)
        else:action=torch.zeros(env.num_envs,5,device=env.device)
        obs,_,_,info=env.step(action)
        if info['episodes']:
            report=summarize(env.rows);report.update(status='RUNNING',policy=args.policy,planned=planned)
            atomic_json(args.output/'summary.json',report)
            print(f'[PPO v4 eval] {len(env.rows)}/{planned}; policy={args.policy}; successes={report["successes"]}; running cases={[c["case_id"] for i,c in enumerate(env.cases) if c is not None]}',flush=True)
        atomic_json(args.output/'runtime_timing.json',env.progress())
    report=summarize(env.rows);report.update(status='COMPLETE',policy=args.policy,planned=planned)
    atomic_json(args.output/'summary.json',report)


def benchmark(args,cfg,env):
    obs=env.observe();started=None;count=0
    torch.cuda.reset_peak_memory_stats()
    reset_verified=False
    while count<args.benchmark_steps*args.num_envs:
        obs,_,_,info=env.step(torch.zeros(env.num_envs,5,device=env.device))
        n=int(info['valid'].sum())
        if n and started is None:started=time.monotonic()
        count+=n
        if args.num_envs>1 and n==args.num_envs and not reset_verified:
            # One reset must leave the other rows, counters and histories intact.
            old_q=env.joint_pos[1:].clone();old_hist=env.encoder.features[1:].clone();old_steps=env.steps[1:].clone()
            env.reset_ids(torch.tensor([0],device=env.device))
            reset_verified=bool(torch.equal(old_q,env.joint_pos[1:]) and torch.equal(old_hist,env.encoder.features[1:]) and torch.equal(old_steps,env.steps[1:]))
            if not reset_verified:raise RuntimeError('Physical reset isolation check failed')
            obs=env.observe()
        atomic_json(args.output/'runtime_timing.json',env.progress())
    elapsed=time.monotonic()-started
    free,total=torch.cuda.mem_get_info()
    report=dict(status='PASS',num_envs=args.num_envs,control_steps=count,seconds=elapsed,
                effective_steps_per_second=count/elapsed,gpu_memory_fraction=(total-free)/total,
                reset_isolation=reset_verified if args.num_envs>1 else True,
                torch_peak_allocated_bytes=torch.cuda.max_memory_allocated(),stages=env.timing,
                cloned_visual_audit=env.benchmark_visual_audit,settings=asdict(cfg),sources=source_hashes())
    atomic_json(args.output/'benchmark.json',report)
    print(f'[PPO v4 benchmark] envs={args.num_envs}; {count/elapsed:.2f} steps/s; memory={(total-free)/total:.1%}',flush=True)


def run(args,cfg):
    from .data import CaseSampler
    torch.set_num_threads(1);torch.manual_seed(args.seed);np.random.seed(args.seed);random.seed(args.seed)
    torch.cuda.manual_seed_all(args.seed)
    split=args.split if args.mode=='eval' else 'train'
    sampler=CaseSampler(args.seed,cfg,split=split,manifest=args.manifest)
    if args.mode=='benchmark':
        # Identical starts make mismatched cloned appearances observable before
        # any policy can produce a different robot pose. No benchmark data train PPO.
        source=sampler.sources[0]
        sampler.fixed=[dict(case_id=i,source_profile=0,initial_joint_pos_rad=source['joint_pos_rad'],
            hole_position_m=source['hole_position_m'],evaluation_seed=42,calibration_seed=args.seed+i,split='train') for i in range(1024)]
    existing=[]
    if args.mode=='eval':
        for path in sorted(args.output.glob('case_*/summary.json')):
            row=json.loads(path.read_text())
            if row['case']['split']!=args.split:raise ValueError('Evaluation output contains another split')
            if int(path.parent.name.removeprefix('case_'))!=row['case']['case_id']:raise ValueError('Saved case identity mismatch')
            existing.append(row)
        completed={r['case']['case_id'] for r in existing}
        sampler.fixed=[case for case in sampler.fixed if case['case_id'] not in completed]
    with environment(args,cfg,sampler) as env:
        env.rows=existing
        {'train':train,'eval':evaluate,'benchmark':benchmark}[args.mode](args,cfg,env)


def main():
    args,cfg=parse()
    # Fail before Kit or inference if the requested experiment cannot be valid.
    if args.num_envs>1 and not args.server_audit.is_file():raise FileNotFoundError(f'Run the server audit and client probe first: {args.server_audit}')
    if args.num_envs>1:
        proof=json.loads(args.server_audit.read_text())
        if proof.get('status')!='PASS' or proof.get('reset_scope')!='no_op' or proof.get('inference_state')!='stateless' or not proof.get('server_metadata'):
            raise ValueError('Parallel service audit/probe has not passed; rejected before launching Isaac')
    if args.mode=='train':
        report=json.loads(args.benchmark_report.read_text())
        if (report.get('status')!='PASS' or report.get('num_envs')!=args.num_envs or not report.get('reset_isolation') or
                report.get('gpu_memory_fraction',1)>=.8 or report.get('effective_steps_per_second',0)<cfg.minimum_steps_per_second or
                not report.get('cloned_visual_audit',{}).get('passed') or report.get('sources')!=source_hashes() or report.get('settings')!=asdict(cfg)):
            raise ValueError('No matching isolated, visually consistent, sufficiently fast benchmark; long training was not started')
    for path in (args.resume,args.checkpoint):
        if path:
            saved=torch.load(path,map_location='cpu',weights_only=False)
            if saved.get('version')!=4 or saved.get('settings')!=asdict(cfg) or saved.get('sources')!=source_hashes():
                raise ValueError('Checkpoint version/settings/source mismatch; rejected before launching Isaac')
    identity=dict(arguments={k:v for k,v in vars(args).items() if k!='wall_hours'},settings=asdict(cfg),sources=source_hashes(),
                  checkpoint_sha256=hashlib.sha256(args.checkpoint.read_bytes()).hexdigest() if args.checkpoint else None,
                  test_manifest_sha256=hashlib.sha256(args.manifest.read_bytes()).hexdigest() if args.mode=='eval' and args.split=='test' else None,
                  calibration_file_sha256=hashlib.sha256(args.hole_calibration.read_bytes()).hexdigest() if args.hole_calibration else None)
    identity=json.loads(json.dumps(identity,default=str))
    if args.output.exists() and any(args.output.iterdir()):
        manifest=args.output/'run_manifest.json'
        if args.mode!='eval' or not manifest.is_file() or json.loads(manifest.read_text())!=identity:
            raise FileExistsError(f'Choose a new output directory: {args.output}')
        failure=args.output/'failure.json'
        if failure.exists():
            index=0
            while (args.output/f'failure_{index:03d}.json').exists():index+=1
            failure.rename(args.output/f'failure_{index:03d}.json')
    args.output.mkdir(parents=True,exist_ok=True)
    atomic_json(args.output/'run_manifest.json',identity)
    from isaaclab.app import AppLauncher
    # Do not let Kit teardown replace a Python exception by exit status zero.
    app=None;exit_code=0
    args.deadline=time.monotonic()+args.wall_hours*3600
    try:
        app=AppLauncher(headless=args.headless,enable_cameras=True,device=args.device).app
        run(args,cfg)
    except BaseException as exc:
        import traceback
        exit_code=1
        atomic_json(args.output/'failure.json',dict(status='INFRASTRUCTURE_FAILURE',error=f'{type(exc).__name__}: {exc}'))
        traceback.print_exc()
    finally:
        if app is not None:
            try:app.close()
            except SystemExit as exc:
                if exc.code and not exit_code:exit_code=int(exc.code)
            except BaseException:
                exit_code=1
    raise SystemExit(exit_code)


if __name__=='__main__':main()
