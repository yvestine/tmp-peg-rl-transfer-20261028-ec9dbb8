"""Privileged geometry is confined to this module and the Critic."""
import torch


def potential(xy,z):
    u=((xy-.002)/.002).clamp(0,1)
    alignment=1-u*u*(3-2*u)
    return (-2*(xy-.0015).clamp(0,.02)+alignment*(.035-(z-.003).clamp(0,.035)))/.001


def reward(before,after,tilt_deg,force_peak,command_change,success,failed,settings,phase):
    def square(x): return x.clamp(0,1).square()
    cfg=settings
    terms=dict(progress=potential(*after)-potential(*before),
        terminal=cfg.success_reward*success.float()-cfg.failure_penalty*failed.float(),
        time_cost=torch.ones_like(after[0])*cfg.dt*cfg.time_cost,
        force_cost=cfg.dt*cfg.force_cost*square((force_peak-cfg.force_limit)/cfg.force_limit),
        tilt_cost=cfg.dt*cfg.tilt_cost*square((tilt_deg-3)/5)*phase.float(),
        smooth_cost=cfg.dt*cfg.smooth_cost*square(command_change.abs()).mean(-1))
    total=terms['progress']+terms['terminal']-sum(v for k,v in terms.items() if k.endswith('cost'))
    if not bool(torch.isfinite(total).all()): raise FloatingPointError('Nonfinite V4 reward')
    return total,terms
