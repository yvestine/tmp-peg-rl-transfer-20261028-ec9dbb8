"""Run on the TAVLA server: export inspectable inference/reset source without inference.

Constructing the trained policy is deliberately left to its existing launcher.
Instead import the actual policy class named by --policy-class. A static audit
accepts only the standard no-op reset and an infer method with RNG-only state
mutation. Any other state mutation requires a session-aware serving adapter.
"""
import argparse
import ast
import hashlib
import importlib
import inspect
import json
import textwrap
from pathlib import Path
try:
    from .settings import atomic_json
except ImportError:  # This file may be copied alone to the TAVLA machine.
    def atomic_json(path,value):
        path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
        tmp=path.with_suffix('.tmp.json');tmp.write_text(json.dumps(value,indent=2)+'\n');tmp.replace(path)


def audit_methods(infer_source,reset_source):
    reset=ast.parse(textwrap.dedent(reset_source))
    fn=next(n for n in reset.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)))
    body=[n for n in fn.body if not (isinstance(n,ast.Expr) and isinstance(n.value,ast.Constant) and isinstance(n.value.value,str))]
    no_op=bool(body) and all(isinstance(n,ast.Pass) or (isinstance(n,ast.Return) and (n.value is None or isinstance(n.value,ast.Constant) and n.value.value is None)) for n in body)
    tree=ast.parse(textwrap.dedent(infer_source))
    writes=[]
    for node in ast.walk(tree):
        if isinstance(node,(ast.Assign,ast.AugAssign,ast.AnnAssign)):
            targets=node.targets if isinstance(node,ast.Assign) else [node.target]
            for target in targets:
                if isinstance(target,ast.Subscript):
                    base=target.value
                    while isinstance(base,ast.Subscript):base=base.value
                    if isinstance(base,ast.Attribute) and isinstance(base.value,ast.Name) and base.value.id=='self':writes.append(base.attr)
        if isinstance(node,ast.Attribute) and isinstance(node.ctx,ast.Store) and isinstance(node.value,ast.Name) and node.value.id=='self':writes.append(node.attr)
        if isinstance(node,ast.Call) and isinstance(node.func,ast.Attribute) and node.func.attr in ('append','extend','update','copy_','add_','clear','pop','reset'):
            if isinstance(node.func.value,ast.Attribute) and isinstance(node.func.value.value,ast.Name) and node.func.value.value.id=='self':writes.append(node.func.value.attr)
    # Shared PRNG affects reproducibility, but does not represent episode memory.
    forbidden_calls=any((isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id in ('setattr','exec','eval')) or isinstance(n,ast.Global) for n in ast.walk(tree))
    safe=not forbidden_calls and all(name in ('_rng','rng') for name in writes)
    return dict(status='PASS' if no_op and safe else 'UNVERIFIED',
                reset_scope='no_op' if no_op else 'unknown',
                inference_state='stateless' if safe else 'unknown',mutated_attributes=writes,
                limitation='Static direct-method audit; delegated transforms/wrappers must be reviewed in the exported source.')


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--policy-class',default='openpi.policies.policy:Policy')
    p.add_argument('--launcher',type=Path,required=True,help='Actual 8001 serving script, read only')
    p.add_argument('--output',type=Path,required=True)
    args=p.parse_args()
    module,name=args.policy_class.split(':');cls=getattr(importlib.import_module(module),name)
    infer=inspect.getsource(cls.infer);reset=inspect.getsource(cls.reset)
    result=audit_methods(infer,reset)
    launcher=args.launcher.read_text()
    launcher_ast=ast.parse(launcher)
    # The released launcher validates inputs then forwards to Policy. Reject
    # stateful wrappers even when the underlying model is stateless.
    wrappers=[]
    for item in launcher_ast.body:
        if not isinstance(item,ast.ClassDef):continue
        methods={m.name:m for m in item.body if isinstance(m,ast.FunctionDef)}
        if 'infer' not in methods:continue
        i_src=ast.get_source_segment(launcher,methods['infer'])
        r_src=ast.get_source_segment(launcher,methods['reset']) if 'reset' in methods else ''
        forwards=bool(r_src) and len(methods['reset'].body)==1 and isinstance(methods['reset'].body[0],ast.Expr) and isinstance(methods['reset'].body[0].value,ast.Call) and ast.unparse(methods['reset'].body[0].value.func)=='self._policy.reset'
        wrapped=audit_methods(i_src,'def reset(self):\n    pass\n')
        wrappers.append(dict(name=item.name,stateless=wrapped['inference_state']=='stateless',reset_forwards=forwards))
    if not wrappers or not all(w['stateless'] and w['reset_forwards'] for w in wrappers):result['status']='UNVERIFIED'
    result.update(policy_class=args.policy_class,infer_source=infer,reset_source=reset,
                  source_file=inspect.getfile(cls),source_sha256=hashlib.sha256(Path(inspect.getfile(cls)).read_bytes()).hexdigest(),
                  launcher_source=launcher,launcher_sha256=hashlib.sha256(args.launcher.read_bytes()).hexdigest(),
                  wrappers=wrappers,server_metadata=None)
    atomic_json(args.output,result)
    print(json.dumps({k:v for k,v in result.items() if not k.endswith('_source')},indent=2))


if __name__=='__main__':main()
