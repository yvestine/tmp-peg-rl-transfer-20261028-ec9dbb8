"""Paired first requests, deterministic baselines and success-first selection."""
from pathlib import Path
import numpy as np
import torch


class InitialRequestBank:
    """Only the FIRST request/chunk is shared. All later requests stay live.

    Requires matching measured robot/force input before replacing camera/RNG
    variation by a common archived first input. Never replays whole trajectories.
    """
    def __init__(self,path):self.path=Path(path);self.path.mkdir(parents=True,exist_ok=True)

    def _path(self,case):return self.path/f"{case['split']}_{case['case_id']:04d}.npz"

    def get(self,case,payload):
        path=self._path(case)
        if not path.exists():return None
        with np.load(path) as d:
            if not np.allclose(d['state'],payload['state'],rtol=0,atol=1e-5) or not np.allclose(d['effort'],payload['effort'],rtol=0,atol=1e-4):
                raise RuntimeError(f'Paired initial state/force differs for {case["split"]}:{case["case_id"]}; inspect reset before comparing')
            return d['actions'].copy()

    def put(self,case,payload,actions):
        path=self._path(case)
        if path.exists():return
        np.savez_compressed(path,state=payload['state'],effort=payload['effort'],
                            front=payload['images']['cam_high'],wrist=payload['images']['cam_left_wrist'],actions=actions)


def geometric_action(obs,fields,settings):
    values={};start=0
    for name,size in fields:values[name]=obs['actor'][:,start:start+size];start+=size
    rel=values['relative_hole']*.05;axis=values['tool_axis']
    action=torch.zeros(len(rel),5,device=rel.device)
    action[:,:2]=-2*rel[:,:2]/settings.translation_speed
    aligned=(torch.linalg.vector_norm(rel[:,:2],dim=-1)<.002)&(axis[:,2]>.996)
    # Small push; release on overload. Same calibration, bounds and servo as PPO.
    force=torch.linalg.vector_norm(values['force_motion_history'].reshape(-1,20,13)[:,-1,:3]*7.5,dim=-1)
    action[:,2]=torch.where(force>7.5,.2,torch.where(aligned,-torch.ones_like(force),torch.zeros_like(force)))
    action[:,3]=2*axis[:,1]/np.radians(settings.rotation_speed_deg)
    action[:,4]=-2*axis[:,0]/np.radians(settings.rotation_speed_deg)
    return action.clamp(-1,1)


def summarize(rows):
    successful=[r for r in rows if r['success']]
    return dict(completed=len(rows),successes=len(successful),success_rate=len(successful)/len(rows) if rows else None,
                mean_success_seconds=float(np.mean([r['formal_seconds'] for r in successful])) if successful else None,
                mean_peak_force_n=float(np.mean([r['peak_force_n'] for r in rows])) if rows else None,
                maximum_peak_force_n=max([r['peak_force_n'] for r in rows],default=0.),results=rows)


def selection_key(summary):
    return (summary['successes'],-(summary['mean_success_seconds'] if summary['mean_success_seconds'] is not None else float('inf')),
            -summary['mean_peak_force_n'])


def choose(candidates,baseline):
    if not candidates:raise ValueError('No completed validation candidates')
    for item in [baseline,*[v for _,v in candidates]]:
        if item['completed']!=40:raise ValueError('Selection requires all 40 independent validation cases')
    path,summary=max(candidates,key=lambda row:selection_key(row[1]))
    return dict(checkpoint=str(path),validation=summary,
                improved_over_baseline=summary['successes']>baseline['successes'],baseline=baseline,
                selection='validation successes, then successful duration, then mean episode peak force')
