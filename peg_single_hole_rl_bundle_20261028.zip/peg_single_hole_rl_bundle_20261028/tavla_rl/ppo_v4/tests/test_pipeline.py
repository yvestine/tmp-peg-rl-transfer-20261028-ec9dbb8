"""End-to-end orchestration using fake workers, never a simulation subprocess."""
import json
import io
from contextlib import redirect_stdout
from pathlib import Path
import subprocess
import sys
import tempfile
import types
import unittest
from unittest.mock import patch
import torch
from tavla_rl.ppo_v4.settings import Settings,atomic_json,source_hashes
from tavla_rl.ppo_v4.pipeline import main
from tavla_rl.ppo_v4.learner import Policy,PPO
from tavla_rl.ppo_v4.worker import checkpoint,load_checkpoint


class PipelineTests(unittest.TestCase):
    def run_pipeline(self,root,*,improved=True,interrupt_once=False):
        proof=root/'server_audit.json';proof.write_text('{}')
        calls=[];interrupted=False
        def worker(command,*unused,**kwargs):
            nonlocal interrupted
            mode=command[5]
            def argument(name,default=None):return command[command.index(name)+1] if name in command else default
            out=Path(argument('--output'));out.mkdir(parents=True,exist_ok=True)
            atomic_json(out/'run_manifest.json',dict(sources=source_hashes()))
            calls.append((mode,out))
            if mode=='benchmark':
                n=int(argument('--num-envs'))
                atomic_json(out/'benchmark.json',dict(status='PASS',num_envs=n,reset_isolation=True,
                    gpu_memory_fraction=.4,effective_steps_per_second={1:3,4:12,8:18}[n]))
            elif mode=='train':
                steps=int(argument('--total-steps'))
                (out/'checkpoints').mkdir(exist_ok=True)
                for name in ('step_000000500.pth','final.pth','last.pth'):
                    (out/'checkpoints'/name).write_bytes(f'weights {steps}'.encode())
                atomic_json(out/'training_summary.json',dict(status='COMPLETE',sampled_steps=steps))
            else:
                split=argument('--split');count=40 if split=='validation' else 50
                policy=argument('--policy')
                if split=='test':success={'zero':40,'geometric':42,'ppo':45}[policy]
                elif policy=='zero':success=30
                elif 'stage2' in str(out):success=34
                else:success=31 if improved else 30
                if interrupt_once and not interrupted and policy=='zero':
                    interrupted=True
                    atomic_json(out/'case_0000/summary.json',dict(case=dict(case_id=0,split=split),success=True))
                    atomic_json(out/'summary.json',dict(status='RUNNING',completed=1,planned=count))
                    atomic_json(out/'failure.json',dict(error='fake keepalive timeout'))
                    return subprocess.CompletedProcess(command,0)  # Reproduce old Kit masking an exception.
                rows=[]
                for i in range(count):
                    row=dict(case=dict(case_id=i,split=split),success=i<success,formal_seconds=20.,peak_force_n=7.)
                    if not (out/f'case_{i:04d}/summary.json').exists():atomic_json(out/f'case_{i:04d}/summary.json',row)
                    rows.append(row)
                atomic_json(out/'summary.json',dict(status='COMPLETE',completed=count,planned=count,successes=success,
                    mean_success_seconds=20.,mean_peak_force_n=7.,results=rows))
            return subprocess.CompletedProcess(command,0)
        argv=['pipeline','--output',str(root/'run'),'--server-audit',str(proof),'--stage1-steps','1024','--stage2-steps','2048']
        with patch.object(sys,'argv',argv),patch('tavla_rl.ppo_v3.watchdog.run_command',side_effect=worker),redirect_stdout(io.StringIO()):main()
        return calls

    def test_full_sequence_selects_by_validation_and_runs_150_cases(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);calls=self.run_pipeline(root)
            value=json.loads((root/'run/results.json').read_text())
            self.assertTrue(value['acceptance_met']);self.assertEqual(value['learned_advantage_over_geometric'],3)
            self.assertEqual(sum(v['completed'] for v in value['experiments'].values()),150)
            self.assertEqual(sum(mode=='train' for mode,_ in calls),2)
            # Identical final/periodic weights do not cause duplicate validation.
            self.assertEqual(sum(mode=='eval' for mode,_ in calls),6)

    def test_no_improvement_stops_before_second_training_or_test(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);calls=self.run_pipeline(root,improved=False)
            status=json.loads((root/'run/pipeline_status.json').read_text())
            self.assertEqual(status['status'],'VALIDATION_NOT_IMPROVED')
            self.assertEqual(sum(mode=='train' for mode,_ in calls),1)
            self.assertFalse((root/'run/test').exists())

    def test_zero_exit_with_incomplete_eval_is_retried_and_completed_cases_retained(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);calls=self.run_pipeline(root,interrupt_once=True)
            value=json.loads((root/'run/results.json').read_text());self.assertTrue(value['acceptance_met'])
            self.assertEqual(sum(mode=='eval' and path.name=='zero' and path.parent.name=='validation' for mode,path in calls),2)


class CheckpointTests(unittest.TestCase):
    def test_model_optimizers_counters_and_sampler_restore_without_cuda(self):
        cfg=Settings();policy=Policy(6,8);learner=PPO(policy,cfg)
        learner.actor_optimizer.zero_grad()
        (-policy.distribution(torch.randn(4,6)).log_prob(torch.full((4,5),.2)).mean()).backward()
        learner.actor_optimizer.step()
        learner.critic_optimizer.zero_grad()
        policy.value(torch.randn(4,8)).square().mean().backward()
        learner.critic_optimizer.step()
        sampler=types.SimpleNamespace(state_dict=lambda:dict(counter=19),load_state_dict=lambda value:setattr(sampler,'restored',value))
        env=types.SimpleNamespace(contract=dict(version=4),sampler=sampler,rows=[dict(success=True)],prior_episodes=3,prior_successes=2)
        with tempfile.TemporaryDirectory() as directory,patch('torch.cuda.get_rng_state_all',side_effect=AssertionError('CPU test must not initialize CUDA')):
            path=Path(directory)/'checkpoint.pth';checkpoint(path,learner,env,123,77,cfg)
            policy2=Policy(6,8);learner2=PPO(policy2,cfg)
            saved=load_checkpoint(path,policy2,cfg,learner=learner2,env=env)
            self.assertEqual(saved['steps'],123);self.assertEqual(saved['actor_steps'],77)
            self.assertEqual(env.prior_episodes,4);self.assertEqual(env.prior_successes,3)
            self.assertEqual(sampler.restored,dict(counter=19))
            for a,b in zip(policy.parameters(),policy2.parameters()):torch.testing.assert_close(a,b)
            self.assertTrue(learner2.actor_optimizer.state)
            for original,restored in zip(learner.actor_optimizer.state.values(),learner2.actor_optimizer.state.values()):
                torch.testing.assert_close(original['exp_avg'],restored['exp_avg'])


if __name__=='__main__':unittest.main()
