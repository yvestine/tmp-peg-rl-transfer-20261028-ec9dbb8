"""Exercise actual batched runtime methods using CPU buffers, without importing Kit."""
import ast
import importlib.util
import json
import math
from pathlib import Path
import tempfile
import types
import unittest
import numpy as np
import torch
from tavla_rl.ppo_v4.settings import ROOT
from tavla_rl.ppo_v4.controller import quat_matrix
from tavla_rl.ppo_v4.rpc import TeacherPool
from tavla_rl.ppo_v4.server_audit import audit_methods
from tavla_rl.control import base_wrench


def runtime_method(name,extra=None):
    """Compile the real method body; only SDK/package imports are replaced."""
    tree=ast.parse((ROOT/'tavla_rl/ppo_v4/environment.py').read_text())
    cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='VectorPegEnv')
    method=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name==name)
    method.body=[n for n in method.body if not isinstance(n,(ast.Import,ast.ImportFrom))]
    module=ast.Module(body=[method],type_ignores=[]);ast.fix_missing_locations(module)
    namespace=dict(torch=torch,np=np,math=math,quat_matrix=quat_matrix,
                   tensor=lambda value,device:torch.as_tensor(value,device=device,dtype=torch.float32))
    namespace.update(extra or {})
    exec(compile(module,'<real V4 runtime method>','exec'),namespace)
    return namespace[name]


class PhysicsContractTests(unittest.TestCase):
    def test_robot_tip_and_hole_share_one_frame_so_base_height_cannot_shift_gate(self):
        method=runtime_method('_robot_tip_base')
        base=torch.tensor([[0.,0.,.071],[3.,0.,.105]])
        origins=torch.tensor([[0.,0.,0.],[3.,0.,0.]])
        data=types.SimpleNamespace(root_pos_w=base,root_quat_w=torch.tensor([[0.,0.,0.,1.]]*2))
        env=types.SimpleNamespace(device='cpu',_robot=types.SimpleNamespace(data=data),
            scene=types.SimpleNamespace(env_origins=origins),peg_offset=.037392,
            fingertip_midpoint_pos=torch.tensor([[0.,0.,.195]]*2),
            fingertip_midpoint_quat=torch.tensor([[1.,0.,0.,0.]]*2))
        measured_tip=method(env)
        measured_hole=torch.tensor([[0.,0.,.12394]]*2)-(base-origins)
        height=(measured_tip-measured_hole)[:,2]
        torch.testing.assert_close(height,torch.full((2,),.195-.037392-.12394),rtol=0,atol=1e-7)
        self.assertTrue(bool((height<.035).all()))

    def test_zero_residual_slew_is_bitwise_original_for_a_batched_trajectory(self):
        spec=importlib.util.spec_from_file_location('_v4_original_slew',ROOT/'source/tacex_tasks/tacex_tasks/real2sim/policy/joint_slew.py')
        m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
        step=runtime_method('_slew',dict(proportional_joint_step=m.proportional_joint_step))
        env=types.SimpleNamespace(command=torch.zeros(4,7),velocity=torch.zeros(4,7),device='cpu')
        rng=torch.Generator().manual_seed(7)
        for _ in range(200):
            target=env.command+torch.randn(4,7,generator=rng)*.01
            q,v,f,valid=step(env,target)
            eq,ev,ef=m.proportional_joint_step(env.command,target,env.velocity,torch.full((1,7),.03),torch.full((1,7),.7),.1)
            self.assertTrue(bool(valid.all()));self.assertTrue(torch.equal(q,eq));self.assertTrue(torch.equal(v,ev));self.assertTrue(torch.equal(f,ef[:,0]))
            env.command=q;env.velocity=v

    def test_infeasible_row_does_not_stop_other_environments(self):
        spec=importlib.util.spec_from_file_location('_v4_original_slew2',ROOT/'source/tacex_tasks/tacex_tasks/real2sim/policy/joint_slew.py')
        m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
        step=runtime_method('_slew',dict(proportional_joint_step=m.proportional_joint_step))
        env=types.SimpleNamespace(command=torch.zeros(3,7),velocity=torch.zeros(3,7),device='cpu')
        env.velocity[1]=.5
        q,v,f,valid=step(env,torch.zeros(3,7))
        self.assertEqual(valid.tolist(),[True,False,True]);self.assertEqual(float(f[1]),0.)

    def test_vector_force_frame_matches_original_numpy_signed_load_conversion(self):
        method=runtime_method('_wrench')
        rng=np.random.default_rng(8);n=20
        native=rng.normal(size=(n,2,6)).astype(np.float32)
        quats=rng.normal(size=(n,2,4)).astype(np.float32)
        baseq=rng.normal(size=(n,4)).astype(np.float32)
        positions=rng.normal(size=(n,2,3)).astype(np.float32)
        origins=rng.normal(size=(n,3)).astype(np.float32)
        tip=rng.normal(size=(n,3)).astype(np.float32)
        offset=np.array([.01,.02,.03],np.float32);rot=np.eye(3,dtype=np.float32)
        data=types.SimpleNamespace(body_quat_w=quats,root_quat_w=baseq,body_pos_w=positions)
        env=types.SimpleNamespace(device='cpu',link7=1,joint_rotation=torch.tensor(rot),joint_offset=torch.tensor(offset),
            scene=types.SimpleNamespace(env_origins=torch.tensor(origins)),fingertip_midpoint_pos=torch.tensor(tip),
            _robot=types.SimpleNamespace(data=data,root_physx_view=types.SimpleNamespace(get_link_incoming_joint_force=lambda:native)))
        actual=method(env).numpy()
        for i in range(n):
            expected=base_wrench(native[i,1],quats[i,1],baseq[i],rot,positions[i,1],offset,tip[i]+origins[i])
            np.testing.assert_allclose(actual[i],expected,rtol=3e-5,atol=5e-6)

    def test_reset_body_contains_no_physics_step_and_warmup_is_part_of_shared_step(self):
        tree=ast.parse((ROOT/'tavla_rl/ppo_v4/environment.py').read_text())
        cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='VectorPegEnv')
        reset=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='reset_ids')
        calls=[ast.unparse(n.func) for n in ast.walk(reset) if isinstance(n,ast.Call)]
        self.assertNotIn('self.sim.step',calls);self.assertNotIn('self.step',calls)


class RPCTests(unittest.TestCase):
    def test_separate_sessions_reset_and_request_mapping(self):
        clients=[]
        class Client:
            server_metadata={'identity':'fake'}
            def __init__(self,*args):self.resets=0;clients.append(self)
            def reset(self):self.resets+=1
            def infer(self,payload):
                actions=np.full((50,8),payload['id'],np.float32);actions[:,7]=.2
                return {'actions':actions}
            def close(self):pass
        with tempfile.TemporaryDirectory() as directory:
            proof=Path(directory)/'audit.json';proof.write_text(json.dumps(dict(status='PASS',inference_state='stateless',reset_scope='no_op',server_metadata=Client.server_metadata)))
            pool=TeacherPool(4,'unused',concurrency=2,audit=proof,client_factory=Client)
            try:
                out=pool.infer({i:dict(id=i) for i in range(4)})
                for i in range(4):self.assertEqual(float(out[i][0,0]),i)
                pool.reset(2);self.assertEqual([c.resets for c in clients],[0,0,1,0])
                self.assertEqual(pool.tokens.tolist(),[0,0,1,0])
            finally:pool.close()

    def test_parallel_requires_state_reset_audit(self):
        with self.assertRaises(ValueError):TeacherPool(4,'unused')

    def test_stateful_history_and_reset_are_rejected(self):
        self.assertEqual(audit_methods('def infer(self, obs):\n self.cache.append(obs)\n return obs','def reset(self):\n self.cache.clear()')['status'],'UNVERIFIED')
        self.assertEqual(audit_methods('def infer(self, obs):\n self.cache[0]=obs\n return obs','def reset(self):\n pass')['status'],'UNVERIFIED')
        self.assertEqual(audit_methods('def infer(self, obs):\n self._rng = 3\n return obs','def reset(self):\n pass')['status'],'PASS')


if __name__=='__main__':unittest.main()
