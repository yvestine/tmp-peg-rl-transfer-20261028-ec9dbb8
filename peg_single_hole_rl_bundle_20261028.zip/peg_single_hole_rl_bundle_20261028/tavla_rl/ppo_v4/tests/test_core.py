import importlib.util
import json
import tempfile
from pathlib import Path
import unittest
from unittest.mock import patch
import numpy as np
import torch
from tavla_rl.ppo_v4.settings import Settings,ROOT
from tavla_rl.ppo_v4.calibration import HoleCalibration
from tavla_rl.ppo_v4.controller import ResidualIntegrator,ContactLatch,BatchedFK
from tavla_rl.ppo_v4.encoder import BatchedEncoder
from tavla_rl.ppo_v4.reward import reward,potential
from tavla_rl.ppo_v4.learner import Policy,PPO,gae
from tavla_rl.ppo_v4.data import CaseSampler
from tavla_rl.ppo_v4.evaluation import choose,InitialRequestBank
from tavla_rl.ppo_v4.pipeline import select_benchmark

torch.set_num_threads(1)


class ControllerTests(unittest.TestCase):
    def setUp(self):self.cfg=Settings()

    def test_downward_motion_accumulates_across_many_chunks_and_stops_at_bound(self):
        c=ResidualIntegrator(2,self.cfg)
        action=torch.tensor([[0,0,-1,0,0],[1,0,0,0,0]],dtype=torch.float32)
        for _ in range(200):
            proposed=c.propose(action,torch.ones(2));c.commit(torch.ones(2,dtype=torch.bool),torch.ones(2))
        self.assertAlmostEqual(float(c.offset[0,2]),-.04,places=6)
        self.assertAlmostEqual(float(c.offset[1,0]),.005,places=6)
        c.reset([0]);self.assertEqual(float(c.offset[0].abs().sum()),0.)
        self.assertAlmostEqual(float(c.offset[1,0]),.005,places=6)

    def test_rejected_or_unrealized_action_cannot_wind_up_and_zero_starts_zero(self):
        c=ResidualIntegrator(3,self.cfg)
        c.propose(torch.ones(3,5),torch.ones(3))
        c.commit(torch.tensor([False,True,True]),torch.tensor([1.,0.,.5]))
        torch.testing.assert_close(c.offset[:2],torch.zeros(2,5))
        self.assertAlmostEqual(float(c.offset[2,0]),.00025,places=7)
        c.reset([2]);c.propose(torch.zeros(3,5),torch.ones(3));c.commit(torch.ones(3,dtype=torch.bool),torch.ones(3))
        torch.testing.assert_close(c.offset,torch.zeros_like(c.offset))

    def test_contact_permission_survives_retreat_and_other_env_reset(self):
        gate=ContactLatch(2,self.cfg)
        for _ in range(5):gate.update(torch.ones(2,3),torch.ones(2),torch.ones(2,dtype=torch.bool))
        self.assertTrue(bool(gate.active.all()))
        for _ in range(200):gate.update(torch.zeros(2,3),torch.ones(2)*.1,torch.ones(2,dtype=torch.bool))
        torch.testing.assert_close(gate.gate,torch.ones(2))
        gate.reset([0]);self.assertFalse(bool(gate.active[0]));self.assertTrue(bool(gate.active[1]))

    def test_masked_latch_update_does_not_reset_another_contact_confirmation(self):
        gate=ContactLatch(2,self.cfg)
        gate.update(torch.ones(2,3),torch.ones(2),torch.tensor([False,True]))
        gate.update(torch.zeros(2,3),torch.ones(2),torch.tensor([True,False]))
        gate.update(torch.ones(2,3),torch.ones(2),torch.tensor([False,True]))
        self.assertTrue(bool(gate.active[1]))


class FKTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        from tavla_rl.random_cases import recorded_starts
        spec=importlib.util.spec_from_file_location('_v4_test_reference_fk',ROOT/'source/tacex_tasks/tacex_tasks/real2sim/policy/force_align_diagnostics.py')
        module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        cls.reference=module.AssetFK(ROOT)
        cls.q=torch.tensor([r['joint_pos_rad'] for r in recorded_starts(audit_orientation=False)],dtype=torch.float64)
        cls.fk=BatchedFK(cls.reference.cache,dtype=torch.float64)

    def test_fk_matches_all_40_original_initializations(self):
        p,r=self.fk(self.q)
        for i,q in enumerate(self.q):
            expected_p,expected_r=self.reference(q.numpy())
            np.testing.assert_allclose(p[i],expected_p,rtol=0,atol=1e-10)
            np.testing.assert_allclose(r[i],expected_r,rtol=0,atol=1e-10)

    def test_zero_residual_is_bitwise_original_and_downward_ik_really_moves_down(self):
        q=self.q[:4];limits=torch.tensor([[-2.8973,2.8973],[-1.7628,1.7628],[-2.8973,2.8973],[-3.0718,-.0698],[-2.8973,2.8973],[-.0175,3.7525],[-2.8973,2.8973]],dtype=torch.float64)
        result,accepted=self.fk.ik(q,torch.zeros(4,5,dtype=torch.float64),limits[:,0],limits[:,1])
        self.assertTrue(torch.equal(result,q));self.assertTrue(bool(accepted.all()))
        offset=torch.zeros(4,5,dtype=torch.float64);offset[:,2]=-.001
        result,accepted=self.fk.ik(q,offset,limits[:,0],limits[:,1])
        self.assertTrue(bool(accepted.all()))
        delta=self.fk(result)[0]-self.fk(q)[0]
        torch.testing.assert_close(delta,offset[:,:3],rtol=0,atol=1e-5)


class CalibrationTests(unittest.TestCase):
    def test_measurement_error_is_episode_fixed_bounded_and_reset_isolated(self):
        c=HoleCalibration(2,Settings())
        truth=torch.tensor([[.1,.2,.3],[.4,.5,.6]])
        c.reset([0,1],['train:0','train:1'],[2,3],simulator_hole_base=truth)
        saved=c.position.clone()
        torch.testing.assert_close(c.observe(truth)['relative_hole'],truth-saved)
        for _ in range(10):torch.testing.assert_close(c.position,saved)
        self.assertTrue(bool(((saved-truth).abs()<=torch.tensor([.002,.002,.001])).all()))
        c.reset([0],['train:2'],[7],simulator_hole_base=truth[:1])
        torch.testing.assert_close(c.position[1],saved[1])

    def test_missing_real_measurement_never_falls_back_to_truth(self):
        with self.assertRaises(ValueError):HoleCalibration(1,Settings(),source='measured')
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'measurement.json';path.write_text(json.dumps(dict(coordinate_frame='robot_base',reference='insertion_target',episodes={})))
            c=HoleCalibration(1,Settings(),source='measured',measurements=path)
            with self.assertRaises(ValueError):c.reset([0],['test:0'],[3])
            with self.assertRaises(ValueError):c.reset([0],['test:0'],[3],simulator_hole_base=torch.zeros(1,3))


class EncoderTests(unittest.TestCase):
    def test_batched_and_scalar_encoders_match_including_even_median_and_startup_backfill(self):
        from tavla_rl.runtime import load_streaming_encoder
        scalar=[load_streaming_encoder(),load_streaming_encoder()]
        vector=BatchedEncoder(2,reference=load_streaming_encoder())
        forces=np.random.default_rng(13).normal(0,2,(50,2,3)).astype(np.float32)
        for t,force in enumerate(forces):
            result=vector.update(torch.from_numpy(force),torch.ones(2,dtype=torch.bool))
            for i,encoder in enumerate(scalar):
                expected=encoder.update(force[i],round(.1*t,9))
                if expected is not None:np.testing.assert_allclose(result[i],expected,rtol=2e-5,atol=2e-6)
        saved=vector.features[1].clone();vector.reset([0])
        torch.testing.assert_close(vector.features[1],saved)
        self.assertFalse(bool(vector.ready[0]));self.assertTrue(bool(vector.ready[1]))


class RewardTests(unittest.TestCase):
    def score(self,z0,z1,force=1.,success=False,failed=False):
        t=lambda x:torch.tensor([x])
        return reward((t(.001),t(z0)),(t(.001),t(z1)),t(2.),t(force),torch.zeros(1,6),t(success).bool(),t(failed).bool(),Settings(),t(True).bool())

    def test_real_progress_up_and_no_motion_have_correct_sign_and_normal_contact_is_free(self):
        _,down=self.score(.025,.024);_,up=self.score(.024,.025);_,still=self.score(.025,.025)
        self.assertAlmostEqual(float(down['progress']),1.,places=4)
        self.assertAlmostEqual(float(up['progress']),-1.,places=4)
        self.assertEqual(float(still['progress']),0.)
        for f in [0.,1.,7.5]:self.assertEqual(float(self.score(.025,.025,f)[1]['force_cost']),0.)
        self.assertGreater(float(self.score(.025,.025,9.)[1]['force_cost']),0.)

    def test_closed_loop_cannot_farm_shaping_and_terminal_dominates_cost_bound(self):
        a=potential(torch.tensor([.001]),torch.tensor([.02]));b=potential(torch.tensor([.0025]),torch.tensor([.01]))
        self.assertEqual(float((b-a)+(a-b)),0.)
        cfg=Settings()
        self.assertLess(cfg.seconds*(cfg.time_cost+cfg.force_cost+cfg.tilt_cost+cfg.smooth_cost)+150,600)
        self.assertAlmostEqual(float(self.score(.02,.02,success=True)[0]-self.score(.02,.02,failed=True)[0]),600.,places=3)


class LearnerTests(unittest.TestCase):
    def test_gae_is_per_env_stops_at_terminals_and_bootstraps_horizon(self):
        rewards=torch.tensor([[1.,10.],[2.,20.],[1000.,30.]])
        values=torch.zeros_like(rewards);next_values=torch.zeros_like(values);next_values[-1,1]=7
        done=torch.tensor([[False,False],[True,False],[False,False]])
        valid=torch.tensor([[True,True],[True,True],[False,True]])
        advantages,_=gae(rewards,values,next_values,done,valid,1.,1.)
        torch.testing.assert_close(advantages,torch.tensor([[3.,67.],[2.,57.],[0.,37.]]))

    def test_real_vector_ppo_uses_active_rows_and_does_not_change_actor_on_approach_only(self):
        cfg=Settings(horizon=4,minibatch=4,update_epochs=2)
        policy=Policy(6,8);learner=PPO(policy,cfg)
        original={k:v.clone() for k,v in policy.actor.state_dict().items()}
        def rollout(active):
            rows=[]
            for _ in range(4):
                obs=dict(actor=torch.randn(2,6),critic=torch.randn(2,8))
                a,l,v=policy.act(obs)
                rows.append(dict(**obs,action=a,log_prob=l,value=v,next_value=torch.zeros(2),reward=torch.tensor([1.,-1.]),
                                 done=torch.zeros(2,dtype=torch.bool),valid=torch.ones(2,dtype=torch.bool),actor_valid=torch.tensor(active)))
            return rows
        m=learner.update(rollout([False,False]))
        self.assertEqual(m['actor_samples'],0)
        self.assertTrue(all(torch.equal(v,policy.actor.state_dict()[k]) for k,v in original.items()))
        m=learner.update(rollout([True,False]));self.assertEqual(m['actor_samples'],4)
        self.assertTrue(any(not torch.equal(v,policy.actor.state_dict()[k]) for k,v in original.items()))


class ProtocolTests(unittest.TestCase):
    def test_training_sampling_never_reads_test_manifest_and_validation_is_fixed(self):
        with patch('tavla_rl.pose_eval.load_pose_cases',side_effect=AssertionError('test leak')):
            a=CaseSampler(2,Settings());b=CaseSampler(7,Settings(),split='validation');c=CaseSampler(9,Settings(),split='validation')
            batch=[a.next() for _ in range(40)]
            self.assertEqual(len({r['source_profile'] for r in batch}),40)
            self.assertEqual([b.next() for _ in range(40)],[c.next() for _ in range(40)])

    def test_validation_case_keeps_same_clone_when_episode_completion_order_changes(self):
        a=CaseSampler(1,Settings(),split='validation');b=CaseSampler(1,Settings(),split='validation')
        for slot in (0,1,2,3):
            self.assertEqual(a.next(env_id=slot,num_envs=4)['case_id'],slot)
            self.assertEqual(b.next(env_id=slot,num_envs=4)['case_id'],slot)
        self.assertEqual(a.next(env_id=1,num_envs=4)['case_id'],5)
        self.assertEqual(a.next(env_id=0,num_envs=4)['case_id'],4)
        self.assertEqual(b.next(env_id=0,num_envs=4)['case_id'],4)
        self.assertEqual(b.next(env_id=1,num_envs=4)['case_id'],5)

    def test_training_sampler_resume_preserves_pending_profiles_and_hole_rng(self):
        a=CaseSampler(3,Settings())
        for _ in range(13):a.next()
        state=a.state_dict()
        expected=[a.next() for _ in range(20)]
        b=CaseSampler(99,Settings());b.load_state_dict(state)
        self.assertEqual([b.next() for _ in range(20)],expected)

    def test_checkpoint_selection_uses_success_then_duration_and_force(self):
        baseline=dict(completed=40,successes=30,mean_success_seconds=20.,mean_peak_force_n=8.)
        a=dict(baseline,successes=31,mean_success_seconds=25.)
        b=dict(baseline,successes=32,mean_success_seconds=30.)
        chosen=choose([('a',a),('b',b)],baseline)
        self.assertEqual(chosen['checkpoint'],'b');self.assertTrue(chosen['improved_over_baseline'])
        self.assertFalse(choose([('a',baseline)],baseline)['improved_over_baseline'])

    def test_low_throughput_or_unisolated_configuration_cannot_start_long_training(self):
        reports=[dict(status='PASS',num_envs=1,effective_steps_per_second=3.,gpu_memory_fraction=.2,reset_isolation=True),
                 dict(status='PASS',num_envs=8,effective_steps_per_second=20.,gpu_memory_fraction=.9,reset_isolation=True)]
        best,passed=select_benchmark(reports)
        self.assertFalse(passed);self.assertEqual(best['num_envs'],1)

    def test_initial_chunk_bank_checks_robot_force_and_shares_only_initial_chunk(self):
        with tempfile.TemporaryDirectory() as folder:
            bank=InitialRequestBank(folder);case=dict(split='test',case_id=3)
            p=dict(state=np.zeros(8,np.float32),effort=np.zeros((10,32),np.float32),images=dict(cam_high=np.zeros((2,2,3),np.uint8),cam_left_wrist=np.zeros((2,2,3),np.uint8)))
            self.assertIsNone(bank.get(case,p));bank.put(case,p,np.ones((50,8),np.float32))
            np.testing.assert_array_equal(bank.get(case,p),np.ones((50,8),np.float32))
            p['state'][0]=.01
            with self.assertRaises(RuntimeError):bank.get(case,p)


if __name__=='__main__':unittest.main()
