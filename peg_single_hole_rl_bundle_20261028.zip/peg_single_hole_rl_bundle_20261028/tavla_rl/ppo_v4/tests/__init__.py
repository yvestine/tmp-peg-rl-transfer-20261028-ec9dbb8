"""CPU tests; never launch Isaac, remote inference or a GPU job."""
