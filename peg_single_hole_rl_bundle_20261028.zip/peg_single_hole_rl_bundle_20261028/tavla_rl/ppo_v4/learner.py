"""Small asymmetric vector PPO; chronological GAE never flattens time with envs."""
import math
import torch
from torch import nn
from torch.distributions import Normal


class RunningNorm(nn.Module):
    def __init__(self,size):
        super().__init__()
        self.register_buffer('mean',torch.zeros(size))
        self.register_buffer('var',torch.ones(size))
        self.register_buffer('count',torch.tensor(1e-4,dtype=torch.float64))

    @torch.no_grad()
    def update(self,x):
        if len(x)==0:return
        n=len(x);mean=x.mean(0);var=x.var(0,unbiased=False)
        delta=mean-self.mean;total=self.count+n
        m2=self.var*self.count+var*n+delta.square()*self.count*n/total
        self.mean.add_(delta*(n/total).float());self.var.copy_((m2/total).float().clamp_min(1e-8));self.count.copy_(total)

    def forward(self,x):return ((x-self.mean)/torch.sqrt(self.var+1e-8)).clamp(-20,20)


class Policy(nn.Module):
    def __init__(self,actor_dim,critic_dim):
        super().__init__()
        self.actor_norm=RunningNorm(actor_dim);self.critic_norm=RunningNorm(critic_dim)
        def mlp(size,last):return nn.Sequential(nn.Linear(size,256),nn.ELU(),nn.Linear(256,256),nn.ELU(),nn.Linear(256,last))
        self.actor=mlp(actor_dim,5);self.critic=mlp(critic_dim,1)
        nn.init.zeros_(self.actor[-1].weight);nn.init.zeros_(self.actor[-1].bias)
        self.log_std=nn.Parameter(torch.full((5,),-2.3))

    def distribution(self,obs):return Normal(self.actor(self.actor_norm(obs)),self.log_std.clamp(-5,1).exp())

    def value(self,obs):return self.critic(self.critic_norm(obs)).squeeze(-1)

    @torch.no_grad()
    def act(self,obs,deterministic=False):
        dist=self.distribution(obs['actor'])
        action=dist.mean if deterministic else dist.sample()
        return action,dist.log_prob(action).sum(-1),self.value(obs['critic'])


def gae(rewards,values,next_values,done,valid,gamma=1.,lam=.99):
    """T x N arrays. Startup is not an MDP transition and never contributes loss.

    Episode terminal values are explicitly zero; horizon truncations bootstrap.
    Invalid ticks break the recurrence, so reset/idle intervals cannot transmit
    credit between episodes (including when an env finishes before its peers).
    """
    if not (rewards.shape==values.shape==next_values.shape==done.shape==valid.shape):raise ValueError('GAE shape mismatch')
    advantages=torch.zeros_like(rewards);carry=torch.zeros_like(rewards[0])
    for t in reversed(range(len(rewards))):
        keep=(~done[t]).float()
        delta=rewards[t]+gamma*next_values[t]*keep-values[t]
        carry=torch.where(valid[t],delta+gamma*lam*keep*carry,torch.zeros_like(carry))
        advantages[t]=carry
    return advantages,advantages+values


class PPO:
    def __init__(self,policy,settings):
        self.policy=policy;self.cfg=settings
        actor=list(policy.actor.parameters())+[policy.log_std]
        self.actor_optimizer=torch.optim.Adam(actor,lr=settings.learning_rate)
        self.critic_optimizer=torch.optim.Adam(policy.critic.parameters(),lr=settings.learning_rate)
        self.updates=0

    def update(self,rows):
        cfg=self.cfg;p=self.policy
        data={k:torch.stack([row[k] for row in rows]) for k in rows[0]}
        for name,value in data.items():
            if value.is_floating_point() and not bool(torch.isfinite(value).all()):raise FloatingPointError(f'Nonfinite PPO rollout: {name}')
        advantage,returns=gae(data['reward'],data['value'],data['next_value'],data['done'],data['valid'],cfg.gamma,cfg.gae_lambda)
        actor_mask=data['actor_valid'].flatten();critic_mask=data['valid'].flatten()
        if not bool(critic_mask.any()):return dict(actor_samples=0,critic_samples=0,kl=0.)
        flat=lambda x:x.flatten(0,1)
        cobs=flat(data['critic'])[critic_mask];target=returns.flatten()[critic_mask]
        # Keep behavior actor statistics unchanged throughout all PPO epochs.
        # Actor inputs already have fixed physical scales. Fitting RMS on an
        # approach-only first rollout would destroy contact/force resolution.
        # Keep identity normalization; behavior likelihoods remain exact.
        p.critic_norm.update(cobs)
        losses=[]
        for _ in range(cfg.update_epochs):
            for ids in torch.randperm(len(cobs),device=cobs.device).split(cfg.minibatch):
                loss=.5*(p.value(cobs[ids])-target[ids]).square().mean()
                if not bool(torch.isfinite(loss)):raise FloatingPointError('Nonfinite critic loss')
                self.critic_optimizer.zero_grad();loss.backward()
                nn.utils.clip_grad_norm_(p.critic.parameters(),1.);self.critic_optimizer.step();losses.append(float(loss.detach()))
        count=int(actor_mask.sum());kl=0.;accepted=0
        if count>=2:
            obs=flat(data['actor'])[actor_mask];actions=flat(data['action'])[actor_mask]
            old_log=data['log_prob'].flatten()[actor_mask]
            adv=advantage.flatten()[actor_mask];adv=(adv-adv.mean())/(adv.std(unbiased=False)+1e-8)
            with torch.no_grad():old_dist=p.distribution(obs);old_mu=old_dist.mean.clone();old_sigma=old_dist.scale.clone()
            stop=False
            for _ in range(cfg.update_epochs):
                if stop:break
                for ids in torch.randperm(count,device=obs.device).split(cfg.minibatch):
                    dist=p.distribution(obs[ids]);log=dist.log_prob(actions[ids]).sum(-1)
                    ratio=(log-old_log[ids]).exp()
                    loss=-torch.minimum(ratio*adv[ids],ratio.clamp(1-cfg.clip,1+cfg.clip)*adv[ids]).mean()
                    if not bool(torch.isfinite(loss)):raise FloatingPointError('Nonfinite actor loss')
                    self.actor_optimizer.zero_grad();loss.backward()
                    nn.utils.clip_grad_norm_(list(p.actor.parameters())+[p.log_std],1.)
                    self.actor_optimizer.step();accepted+=1
                    with torch.no_grad():
                        new=p.distribution(obs)
                        kl=float(torch.distributions.kl_divergence(Normal(old_mu,old_sigma),new).sum(-1).mean())
                    if not math.isfinite(kl):raise FloatingPointError('Nonfinite PPO KL')
                    if kl>cfg.target_kl:stop=True;break
        self.updates+=1
        return dict(actor_samples=count,critic_samples=int(critic_mask.sum()),kl=kl,
                    critic_loss=sum(losses)/max(1,len(losses)),actor_optimizer_steps=accepted)

    def state_dict(self):
        return dict(policy=self.policy.state_dict(),actor_optimizer=self.actor_optimizer.state_dict(),
                    critic_optimizer=self.critic_optimizer.state_dict(),updates=self.updates)

    def load_state_dict(self,state):
        self.policy.load_state_dict(state['policy']);self.actor_optimizer.load_state_dict(state['actor_optimizer'])
        self.critic_optimizer.load_state_dict(state['critic_optimizer']);self.updates=state['updates']
