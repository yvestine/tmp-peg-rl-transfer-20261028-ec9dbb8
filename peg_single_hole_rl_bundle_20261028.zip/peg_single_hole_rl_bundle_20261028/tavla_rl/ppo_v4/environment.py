"""One Isaac scene, N physical environments; no reset method advances physics.

Import only after AppLauncher. Scene, assets, gains and visual transformations
come from the existing RealSim implementation. Legacy step/reset are bypassed
because they advance the whole simulator while resetting a single episode.
"""
import hashlib
import math
import time
import numpy as np
import torch
from isaaclab_tasks.direct.factory import factory_utils
from tacex_tasks.real2sim.realsim_env import RealSimEnv
from tacex_tasks.real2sim.forge_env import ForgeEnv
from tacex_tasks.real2sim.tavla_residual_env import _configure_pi0_rollout_scene
from tacex_tasks.real2sim.sim_data_visual import (load_sim_data_profile,configure_sim_data_visual_scene,
                                                apply_visual_domain_randomization,make_image_rng)
from tacex_tasks.real2sim.policy.force_contact_capture import incoming_joint_frame
from .settings import ROOT,atomic_json
from .controller import BatchedFK,ContactLatch,ResidualIntegrator,quat_matrix,rotation_log
from .calibration import HoleCalibration
from .encoder import BatchedEncoder
from .data import calibration_key
from .reward import reward

ACTOR_FIELDS=(('q',7),('qd',7),('gripper',1),('nominal',8),('latent',32),('command',7),
              ('command_velocity',7),('chunk_phase',1),('tool_axis',3),('nominal_axis',3),
              ('angular_velocity',3),('gate',1),('contact_phase',1),('relative_hole',3),
              ('calibration_error_bound',3),('calibration_valid',1),('offset',5),('remaining',1),
              ('force_motion_history',260))
ACTOR_DIM=sum(n for _,n in ACTOR_FIELDS)
CRITIC_DIM=ACTOR_DIM+3+4+3+4+6


def tensor(value,device):
    value=value.torch if hasattr(value,'torch') and not isinstance(value,torch.Tensor) else value
    return torch.as_tensor(value,device=device,dtype=torch.float32)


def build_config(args,settings):
    from tavla_rl.env_cfg import TavlaRLCfg
    cfg=TavlaRLCfg()
    visual=load_sim_data_profile(ROOT/'sim-data-aligned',0)
    configure_sim_data_visual_scene(cfg)
    cfg.replay_left_background_visual_shell=False
    apply_visual_domain_randomization(cfg,visual.domain_randomization)
    _configure_pi0_rollout_scene(cfg)
    cfg.scene.num_envs=args.num_envs
    cfg.scene.env_spacing=3.
    cfg.scene.replicate_physics=True
    cfg.sim.device=args.device;cfg.seed=42  # Frozen physics seed, independent of training-hole/PPO RNG.
    cfg.sim.dt=1/120;cfg.decimation=12;cfg.sim.render_interval=12
    cfg.enable_cameras=True
    cfg.policy_cfg=None
    cfg.action_space=8
    cfg.episode_length_s=settings.seconds;cfg.is_finite_horizon=True
    cfg.data_collect_cfg['collect_data']=False
    cfg.teacher_control_mode='aligned_joint'
    cfg.use_implicit_position_servo=False
    cfg.ft_parent_body_name='panda_link7'
    cfg.ft_raw_wrench_frame='parent_body';cfg.ft_raw_torque_reference='parent_origin'
    cfg.ft_apply_child_joint_frame_calibration=True
    cfg.task.skip_reset_ik=True;cfg.task.use_pi0_reset_pose=True
    cfg.task.fixed_asset_init_pos_noise=[0.]*3;cfg.task.hand_init_pos_noise=[0.]*3
    cfg.task.held_asset_pos_noise=[0.]*3
    cfg.task.success_xy_threshold=.003;cfg.task.success_z_threshold=.003
    cfg.events.object_scale_mass=None
    for name in ('held_physics_material','fixed_physics_material','robot_physics_material'):
        getattr(cfg.events,name).params.update(static_friction_range=(.75,.75),dynamic_friction_range=(.75,.75),num_buckets=1)
    cfg.ctrl.task_prop_gains_noise_level=[0.]*6
    cfg.ctrl.pos_threshold_noise_level=[0.]*3;cfg.ctrl.rot_threshold_noise_level=[0.]*3
    cfg.ctrl.ema_factor_range=[1.,1.];cfg.obs_rand.ft_wrench_noise_std=[0.]*6
    cfg.task.contact_penalty_threshold_range=[settings.force_limit]*2
    return cfg,visual


class VectorPegEnv(RealSimEnv):
    # States advance only in step(): 6 close ticks, 2 settle ticks, 20 tare ticks.
    CLOSE,SETTLE,WARMUP,READY,IDLE=range(5)

    def __init__(self,args,settings,sampler,pool,*,initial_bank=None):
        self.settings=settings;self.sampler=sampler;self.pool=pool
        self.args=args;self.output=args.output;self.initial_bank=initial_bank
        self._v4_ready=False
        cfg,self.visual=build_config(args,settings)
        # Forge initializes the same Factory articulation/dynamics buffers; the
        # RealSim constructor would initialize a second remote policy and reset loop.
        ForgeEnv.__init__(self,cfg)
        from tacex_tasks.real2sim.tavla_residual_env import TavlaResidualEnv
        TavlaResidualEnv._override_pi0_active_robot_base_gray_to_white(self)
        self._synchronize_cloned_materials()
        self._v4_ready=True
        n=self.num_envs;d=self.device
        self.fk=BatchedFK.from_asset(d)
        self.encoder=BatchedEncoder(n,d)
        self.latch=ContactLatch(n,settings,d);self.integrator=ResidualIntegrator(n,settings,d)
        self.calibration=HoleCalibration(n,settings,d,source=args.hole_pose_source,measurements=args.hole_calibration)
        self.phase=torch.full((n,),self.IDLE,dtype=torch.long,device=d)
        self.phase_tick=torch.zeros(n,dtype=torch.long,device=d)
        self.steps=torch.zeros_like(self.phase_tick)
        self.episode_id=torch.zeros_like(self.phase_tick)
        self.guard=torch.zeros(n,dtype=torch.long,device=d)
        self.peaks=torch.zeros(n,device=d);self.step_peak=torch.zeros(n,device=d)
        self.returns=torch.zeros(n,device=d)
        self.chunks=torch.zeros(n,50,8,device=d)
        self.chunk_index=torch.ones(n,dtype=torch.long,device=d)
        self.chunk_age=torch.zeros_like(self.chunk_index)
        self.nominal=torch.zeros(n,8,device=d)
        self.command=torch.zeros(n,7,device=d)
        self.command_gripper=torch.zeros(n,device=d)
        self.velocity=torch.zeros_like(self.command)
        self.previous_effect=torch.zeros(n,6,device=d)
        self.effect=torch.zeros_like(self.previous_effect)
        self.history=torch.zeros(n,20,13,device=d)
        self.last_tip=torch.zeros(n,3,device=d)
        self.warm_q=torch.zeros(n,self._robot.num_joints,device=d)
        self.source_q=torch.zeros(n,7,device=d)
        self.last_q=torch.zeros_like(self.source_q)
        self.cases=[None]*n;self.image_rng=[None]*n
        self.rows=[];self.trace=[[] for _ in range(n)]
        self.benchmark_visual_audit=None
        self.timing={};self.global_ticks=0;self.control_samples=0
        self.elapsed_start=time.monotonic()
        self.lower=tensor(self._robot.data.soft_joint_pos_limits,d)[:,:7,0]
        self.upper=tensor(self._robot.data.soft_joint_pos_limits,d)[:,:7,1]
        self.link7=self._robot.body_names.index('panda_link7')
        r,meta=incoming_joint_frame(self.sim.stage,self._robot.root_physx_view.link_paths[0][self.link7])
        self.joint_rotation=torch.as_tensor(r,device=d,dtype=torch.float32)
        self.joint_offset=torch.as_tensor(meta['child_local_position_m'],device=d)
        self.peg_offset=.050-.017608+float(self.cfg.pi0_peg_mount_depth_adjust_m)
        # Same servo as TavlaResidualEnv._activate_teacher_position_servo.
        stiffness=tensor(self._robot.data.joint_stiffness,d).clone()
        damping=tensor(self._robot.data.joint_damping,d).clone()
        stiffness[:,:7]=torch.as_tensor(self.cfg.joint_target_kp,device=d)
        damping[:,:7]=torch.as_tensor(self.cfg.joint_target_kd,device=d)
        self._robot.write_joint_stiffness_to_sim(stiffness)
        self._robot.write_joint_damping_to_sim(damping)
        self.reset()
        self.contract=dict(version=4,settings=settings.contract,actor_fields=ACTOR_FIELDS,
            actor_dim=ACTOR_DIM,critic_dim=CRITIC_DIM,physics='original assets/120Hz/implicit200-40/proportional slew',
            friction={'peg':.75,'hole_static':.75,'hole_dynamic':.75,'robot':.75},
            physics_seed=42,
            visuals=self.visual.domain_randomization,calibration_source=args.hole_pose_source,
            calibration_file_sha256=hashlib.sha256(args.hole_calibration.read_bytes()).hexdigest() if args.hole_calibration else None,
            tool_reference='measured robot fingertip + configured fixed peg mounting transform; same base frame as hole measurement',
            peg_offset_m=self.peg_offset,teacher_metadata=pool.metadata,
            recorded_starts=self.sampler.sources,
            observation_scales='qd/.1, command_velocity/.03, relative_hole/.05, uncertainty/.005, offset/[.005,.005,.04,5deg,5deg]')
        atomic_json(self.output/'environment_contract.json',self.contract)

    def _set_default_dynamics_parameters(self):
        super()._set_default_dynamics_parameters()
        # Factory's final overwrite sets only dynamic friction; set both.
        import warp as wp
        for asset in (self._robot,self._fixed_asset,self._held_asset):
            props=wp.to_torch(asset.root_view.get_material_properties()).clone()
            props[...,:2]=.75
            indices=torch.arange(self.num_envs,dtype=torch.int32,device='cpu')
            asset.root_view.set_material_properties(wp.from_torch(props.contiguous()),wp.from_torch(indices))

    def _synchronize_cloned_materials(self):
        """The legacy final gray/white override explicitly edits only env_0.

        Replicate those visual bindings after cloning without touching physics,
        poses or materials of the contact surfaces.
        """
        from pxr import UsdShade
        prefix='/World/envs/env_0/'
        bindings=[]
        for prim in self.sim.stage.Traverse():
            path=str(prim.GetPath())
            if not path.startswith(prefix):continue
            rel=prim.GetRelationship('material:binding')
            if rel and any(str(p)=='/World/Looks/pi0_active_robot_base_white' for p in rel.GetTargets()):
                bindings.append((path,rel.GetTargets(),rel.GetMetadata('bindMaterialAs')))
        for i in range(1,self.num_envs):
            for path,targets,strength in bindings:
                destination=self.sim.stage.GetPrimAtPath(path.replace(prefix,f'/World/envs/env_{i}/',1))
                if not destination.IsValid():raise RuntimeError('Cloned robot visual hierarchy differs from env_0')
                UsdShade.MaterialBindingAPI.Apply(destination)
                rel=destination.CreateRelationship('material:binding')
                rel.SetTargets(targets)
                if strength:rel.SetMetadata('bindMaterialAs',strength)

    def _compute_intermediate_values(self,dt):
        # All readbacks remain batched. Actor pose uses robot link measurements,
        # never the peg body pose or the old inconsistent scalar FK height.
        d=self.device
        self.joint_pos=tensor(self._robot.data.joint_pos,d)
        self.joint_vel=tensor(self._robot.data.joint_vel,d)
        self.fingertip_midpoint_pos=tensor(self._robot.data.body_pos_w,d)[:,self.fingertip_body_idx]-self.scene.env_origins
        self.fingertip_midpoint_quat=tensor(self._robot.data.body_quat_w,d)[:,self.fingertip_body_idx]
        self.held_pos=tensor(self._held_asset.data.root_pos_w,d)-self.scene.env_origins
        self.held_quat=tensor(self._held_asset.data.root_quat_w,d)
        self.fixed_pos=tensor(self._fixed_asset.data.root_pos_w,d)-self.scene.env_origins
        self.fixed_quat=tensor(self._fixed_asset.data.root_quat_w,d)

    def _reset_idx(self,ids):
        # DirectRLEnv may invoke this before construction is complete.
        if getattr(self,'_v4_ready',False):self.reset_ids(ids)

    def reset(self,*,seed=None,options=None):
        self.reset_ids(torch.arange(self.num_envs,device=self.device))
        return self.observe(),{}

    def reset_ids(self,ids):
        ids=torch.as_tensor(ids,device=self.device,dtype=torch.long)
        reset_ids=[]
        for i in ids.cpu().tolist():
            case=self.sampler.next(env_id=i,num_envs=self.num_envs)
            self.cases[i]=case
            if case is None:self.phase[i]=self.IDLE;continue
            self.pool.reset(i)
            self.image_rng[i]=make_image_rng(self.visual.domain_randomization)
            q=torch.as_tensor(case['initial_joint_pos_rad'],device=self.device)
            self.source_q[i]=q;self.last_q[i]=q
            self.warm_q[i]=tensor(self._robot.data.default_joint_pos,self.device)[i]
            self.warm_q[i,:7]=q;self.warm_q[i,7:9]=.04
            self.command[i]=q;self.velocity[i]=0
            self.command_gripper[i]=0.
            self.nominal[i,:7]=q;self.nominal[i,7]=1.
            pose=tensor(self._fixed_asset.data.default_root_pose,self.device)[i:i+1].clone()
            pose[:,:3]=torch.as_tensor(case['hole_position_m'],device=self.device)+self.scene.env_origins[i]
            one=torch.tensor([i],device=self.device)
            self._fixed_asset.write_root_pose_to_sim(pose,env_ids=one)
            self._fixed_asset.write_root_velocity_to_sim(torch.zeros(1,6,device=self.device),env_ids=one)
            self._robot.write_joint_state_to_sim(self.warm_q[i:i+1],torch.zeros_like(self.warm_q[i:i+1]),env_ids=one)
            self.phase[i]=self.CLOSE;self.phase_tick[i]=0;self.steps[i]=0;self.episode_id[i]+=1
            self.guard[i]=0;self.peaks[i]=0;self.returns[i]=0;self.chunk_age[i]=0;self.chunk_index[i]=1
            self.history[i]=0;self.effect[i]=0;self.previous_effect[i]=0;self.trace[i]=[]
            reset_ids.append(i)
        if not reset_ids:return
        ids=torch.tensor(reset_ids,device=self.device)
        self.encoder.reset(ids);self.latch.reset(ids);self.integrator.reset(ids)
        self.calibration.valid[ids]=False
        # forward updates transforms without advancing any environment's time.
        self.scene.write_data_to_sim();self.sim.forward();self.scene.update(dt=0.)
        self._compute_intermediate_values(self.physics_dt)
        self._snap_peg(ids)
        base=tensor(self._robot.data.root_pos_w,self.device)-self.scene.env_origins
        rb=quat_matrix(tensor(self._robot.data.root_quat_w,self.device))
        hole_base=(rb.transpose(1,2)@(self.fixed_pos-base)[:,:,None]).squeeze(-1)
        kwargs={'simulator_hole_base':hole_base[ids]} if self.calibration.source=='simulated' else {}
        self.calibration.reset(ids,[calibration_key(self.cases[i]) for i in reset_ids],
                               [self.cases[i]['calibration_seed'] for i in reset_ids],**kwargs)
        self.last_tip[ids]=self._robot_tip_base()[ids]

    def _snap_peg(self,ids):
        from isaaclab.utils import math as m
        flip=torch.zeros(len(ids),4,device=self.device);flip[:,1]=1
        offset=torch.zeros(len(ids),3,device=self.device);offset[:,2]=self.peg_offset
        p=self.fingertip_midpoint_pos[ids]+(quat_matrix(self.fingertip_midpoint_quat[ids])@offset[:,:,None]).squeeze(-1)
        q=m.quat_mul(self.fingertip_midpoint_quat[ids],flip)
        self._held_asset.write_root_pose_to_sim(torch.cat((p+self.scene.env_origins[ids],q),-1),env_ids=ids)
        self._held_asset.write_root_velocity_to_sim(torch.zeros(len(ids),6,device=self.device),env_ids=ids)

    def _robot_tip_base(self):
        base=tensor(self._robot.data.root_pos_w,self.device)-self.scene.env_origins
        rb=quat_matrix(tensor(self._robot.data.root_quat_w,self.device))
        rt=quat_matrix(self.fingertip_midpoint_quat)
        offset=self.fingertip_midpoint_pos.new_tensor([0,0,self.peg_offset])
        tip=self.fingertip_midpoint_pos+(rt@offset[:,None]).squeeze(-1)
        return (rb.transpose(1,2)@(tip-base)[:,:,None]).squeeze(-1)

    def _wrench(self):
        raw=tensor(self._robot.root_physx_view.get_link_incoming_joint_force(),self.device)[:,self.link7]
        link=quat_matrix(tensor(self._robot.data.body_quat_w,self.device)[:,self.link7])
        rb=quat_matrix(tensor(self._robot.data.root_quat_w,self.device))
        r=rb.transpose(1,2)@link@self.joint_rotation
        force=-(r@raw[:,:3,None]).squeeze(-1)
        linkpos=tensor(self._robot.data.body_pos_w,self.device)[:,self.link7]
        kp=self.fingertip_midpoint_pos+self.scene.env_origins
        arm=(rb.transpose(1,2)@(linkpos+(link@self.joint_offset[:,None]).squeeze(-1)-kp)[:,:,None]).squeeze(-1)
        torque=-(r@raw[:,3:,None]).squeeze(-1)+torch.linalg.cross(arm,force)
        return torch.cat((force,torque),-1)

    def _images(self,ids):
        # Reuse the existing exact pixel processing on each camera's own buffer.
        from tacex_tasks.real2sim import sim_data_visual as visual
        from tacex_tasks.real2sim.pi0_env import (_resize_pi0_rgb,_composite_pi0_green_table_front,
            _composite_pi0_reference_cylinder,_composite_pi0_cable_grommets,_match_pi0_wrist_appearance)
        self.sim.render()
        self.tiled_camera.update(self.physics_dt,force_recompute=True)
        self.wrist_tiled_camera.update(self.physics_dt,force_recompute=True)
        front=self.tiled_camera.data.output['rgb'].detach().cpu().numpy()
        wrist=self.wrist_tiled_camera.data.output['rgb'].detach().cpu().numpy()
        if len(front)!=self.num_envs or len(wrist)!=self.num_envs:raise RuntimeError('Cloned camera batch mismatch')
        out={}
        for i in ids:
            f=_resize_pi0_rgb(front[i].copy(),self.cfg)
            f=_composite_pi0_green_table_front(f,self.cfg)
            for polygon,enabled,alpha in [('pi0_green_table_right_patch_image_polygon','pi0_green_table_right_edge_front_repair_enabled','pi0_green_table_right_edge_front_repair_alpha'),('pi0_green_table_border_image_polygon','pi0_green_table_border_front_repair_enabled','pi0_green_table_border_front_repair_alpha')]:
                f=_composite_pi0_green_table_front(f,self.cfg,polygon_attr=polygon,enabled_attr=enabled,alpha_attr=alpha,apply_hole_cutout=False)
            f=_composite_pi0_reference_cylinder(f,self.cfg,'rgb');f=_composite_pi0_cable_grommets(f,self.cfg,'rgb')
            w=_match_pi0_wrist_appearance(_resize_pi0_rgb(wrist[i].copy(),self.cfg),self.cfg,'rgb')
            if self.visual.domain_randomization.get('enabled'):
                f=visual.apply_rgb_domain_randomization(f,self.visual.domain_randomization,self.image_rng[i])
                w=visual.apply_rgb_domain_randomization(w,self.visual.domain_randomization,self.image_rng[i])
            out[i]=(np.ascontiguousarray(f[...,:3]),np.ascontiguousarray(w[...,:3]))
        if self.args.mode=='benchmark' and self.benchmark_visual_audit is None and len(ids)==self.num_envs:
            comparisons=[]
            for i in ids[1:]:
                comparisons.append(dict(env_id=i,
                    front_mae=float(np.abs(out[i][0].astype(float)-out[ids[0]][0]).mean()),
                    wrist_mae=float(np.abs(out[i][1].astype(float)-out[ids[0]][1]).mean())))
            passed=all(max(row['front_mae'],row['wrist_mae'])<=3. for row in comparisons)
            self.benchmark_visual_audit=dict(passed=passed,maximum_mean_pixel_error=3.,comparisons=comparisons)
            atomic_json(self.output/'cloned_visual_audit.json',self.benchmark_visual_audit)
            if not passed:raise RuntimeError('Identical recorded starts have inconsistent cloned camera appearance; inspect cloned_visual_audit.json')
        return out

    def prepare_teacher(self):
        ids=((self.phase==self.READY)&(self.chunk_age==0)).nonzero().flatten().cpu().tolist()
        if ids:
            started=time.monotonic();images=self._images(ids);self._time('camera',started)
            payloads={}
            for i in ids:
                front,wrist=images[i]
                state=torch.cat((self.joint_pos[i,:7],self.joint_pos[i,7:9].sum().view(1)/.08)).detach().cpu().numpy().astype(np.float32)
                payloads[i]=dict(state=state,effort=self.encoder.latents[i].cpu().numpy().copy(),
                    images=dict(cam_high=front,cam_left_wrist=wrist,cam_right_wrist=wrist.copy()),prompt='peg-in-hole')
            started=time.monotonic()
            cached={}
            if self.initial_bank is not None:
                for i in ids:
                    if int(self.steps[i])==0:
                        value=self.initial_bank.get(self.cases[i],payloads[i])
                        if value is not None:cached[i]=value
            chunks={**self.pool.infer({i:p for i,p in payloads.items() if i not in cached}),**cached}
            self._time('teacher',started)
            for i,a in chunks.items():
                if self.initial_bank is not None and int(self.steps[i])==0:self.initial_bank.put(self.cases[i],payloads[i],a)
                self.chunks[i]=torch.as_tensor(a,device=self.device)
                self.chunk_index[i]=1
        ready=self.phase==self.READY
        ids=ready.nonzero().flatten()
        self.nominal[ids]=self.chunks[ids,self.chunk_index[ids]]
        out=((self.nominal[:,:7]<self.lower)|(self.nominal[:,:7]>self.upper)).any(-1)&ready
        self.guard[out]=1
        # Invalid teacher actions end as guarded failures; never feed NaNs/limits to IK.
        self.nominal[out,:7]=self.command[out]

    def observe(self):
        tip=self._robot_tip_base()
        # During startup idle entries are zero-padded and excluded from all PPO losses.
        rb=quat_matrix(tensor(self._robot.data.root_quat_w,self.device))
        tool=rb.transpose(1,2)@quat_matrix(self.fingertip_midpoint_quat)
        nominal_rotation=self.fk(self.nominal[:,:7])[1]
        relative=tip-self.calibration.position
        values=dict(q=self.joint_pos[:,:7],qd=self.joint_vel[:,:7]/.1,gripper=self.joint_pos[:,7:9].sum(-1,keepdim=True)/.08,
            nominal=self.nominal,latent=self.encoder.latents[:,-1],command=self.command,command_velocity=self.velocity/.03,
            chunk_phase=self.chunk_index[:,None].float()/10,tool_axis=-tool[:,:,2],nominal_axis=-nominal_rotation[:,:,2],
            angular_velocity=(rb.transpose(1,2)@tensor(self._robot.data.body_ang_vel_w,self.device)[:,self.fingertip_body_idx,:,None]).squeeze(-1),
            gate=self.latch.gate[:,None],contact_phase=self.latch.active[:,None].float(),relative_hole=relative/.05,
            calibration_error_bound=self.calibration.uncertainty/.005,calibration_valid=self.calibration.valid[:,None].float(),
            offset=self.integrator.offset/self.integrator.upper.abs().maximum(self.integrator.lower.abs()),remaining=(1-self.steps[:,None]*.1/self.settings.seconds).clamp(0,1),
            force_motion_history=self.history.flatten(1))
        actor=torch.cat([values[k] for k,_ in ACTOR_FIELDS],-1).float()
        critic=torch.cat((actor,self.held_pos-self.fixed_pos,self.held_quat,self.fixed_pos,self.fixed_quat,self._wrench()),-1)
        if actor.shape[-1]!=ACTOR_DIM or critic.shape[-1]!=CRITIC_DIM:raise RuntimeError('V4 observation contract mismatch')
        return dict(actor=actor,critic=critic,valid=self.phase==self.READY,
                    actor_valid=(self.phase==self.READY)&(self.latch.gate>0))

    def _time(self,stage,started):self.timing[stage]=self.timing.get(stage,0.)+time.monotonic()-started

    def _slew(self,target):
        from tacex_tasks.real2sim.policy.joint_slew import proportional_joint_step
        # Determine per-row feasibility first so one safety failure cannot abort
        # all the other environments. The accepted rows use the original function.
        direction=(target-self.command)/.1
        nz=direction!=0;div=torch.where(nz,direction,torch.ones_like(direction))
        a=(self.velocity-.07)/div;b=(self.velocity+.07)/div
        lo=torch.where(nz,torch.minimum(a,b),torch.zeros_like(a)).amax(-1).clamp_min(0)
        hi=torch.minimum(torch.where(nz,torch.maximum(a,b),torch.ones_like(a)),torch.where(nz,.03/direction.abs().clamp_min(1e-12),torch.ones_like(a))).amin(-1).clamp_max(1)
        feasible=(hi>=lo)&(hi>=0)&(nz|(self.velocity.abs()<=.07)).all(-1)
        result=self.command.clone();velocity=torch.zeros_like(result);fraction=torch.zeros(len(result),device=self.device)
        ids=feasible.nonzero().flatten()
        if len(ids):
            q,v,f=proportional_joint_step(self.command[ids],target[ids],self.velocity[ids],target.new_full((1,7),.03),target.new_full((1,7),.7),.1)
            result[ids]=q;velocity[ids]=v;fraction[ids]=f[:,0]
        return result,velocity,fraction,feasible

    def step(self,action):
        valid=self.phase==self.READY;actor_valid=valid&(self.latch.gate>0)
        before=(torch.linalg.vector_norm((self.held_pos-self.fixed_pos)[:,:2],dim=-1),(self.held_pos-self.fixed_pos)[:,2])
        requested=self.integrator.propose(action,self.latch.gate*valid)
        target,accepted=self.fk.ik(self.nominal[:,:7],requested,self.lower,self.upper)
        started=time.monotonic()
        command,velocity,fraction,feasible=self._slew(target)
        zero_command,_,_,_=self._slew(self.nominal[:,:7])
        self.integrator.commit(accepted & feasible & valid,fraction)
        self.previous_effect=self.effect.clone()
        cp,cr=self.fk(command);zp,zr=self.fk(zero_command)
        self.effect=torch.cat(((cp-zp)/.0005,rotation_log(cr@zr.transpose(-1,-2))/math.radians(.1)),-1)
        self.effect[~valid]=0
        self.guard[valid&~feasible]=2
        self.command=torch.where(valid[:,None],command,self.command)
        self.velocity=torch.where(valid[:,None],velocity,torch.zeros_like(velocity))
        grip_delta=(self.nominal[:,7]-self.command_gripper).clamp(-.2,.2)
        self.command_gripper=torch.where(valid,self.command_gripper+grip_delta,self.command_gripper)
        self._time('control',started)
        self.step_peak.zero_()
        # Startup restores only the warming rows; ongoing episodes keep moving.
        warming=(self.phase==self.WARMUP).nonzero().flatten()
        if len(warming):self._robot.write_joint_state_to_sim(self.warm_q[warming],torch.zeros_like(self.warm_q[warming]),env_ids=warming)
        started=time.monotonic()
        for _ in range(12):
            closing=(self.phase==self.CLOSE).nonzero().flatten()
            if len(closing):self._snap_peg(closing)
            self.ctrl_target_joint_pos[:,:7]=self.command
            self.ctrl_target_joint_pos[:,7:9]=self.command_gripper[:,None].clamp(0,1)*.04
            resetting=(self.phase==self.CLOSE)|(self.phase==self.SETTLE)|(self.phase==self.WARMUP)
            self.ctrl_target_joint_pos[resetting,7:9]=0.
            self._robot.set_joint_position_target(self.ctrl_target_joint_pos)
            self._robot.set_joint_effort_target(torch.zeros_like(self.ctrl_target_joint_pos))
            self.scene.write_data_to_sim();self.sim.step(render=False);self.scene.update(dt=self.physics_dt)
            self._compute_intermediate_values(self.physics_dt)
            wrench=self._wrench();force=torch.linalg.vector_norm(wrench[:,:3],dim=-1)
            self.step_peak=torch.maximum(self.step_peak,force)
            q=self.joint_pos[:,:7];qd=self.joint_vel[:,:7]
            finite=torch.isfinite(torch.cat((q,qd,self.held_pos,self.fixed_pos,wrench),-1)).all(-1)
            if not bool(finite.all()):raise FloatingPointError('Nonfinite physical state; infrastructure failure')
            self.guard[valid&(((q<self.lower-.02)|(q>self.upper+.02)).any(-1))]=3
            self.guard[valid&(qd.abs().amax(-1)>1.)]=4
            self.guard[valid&(force>100)]=5
            hand=-quat_matrix(self.fingertip_midpoint_quat)[:,:,2]
            peg=quat_matrix(self.held_quat)[:,:,2]
            self.guard[valid&((hand[:,2]<math.cos(math.pi/4))|(peg[:,2].abs()<math.cos(math.pi/4)))]=6
            self.guard[valid&((q-self.source_q).abs().amax(-1)>self.args.drift_limit)]=7
            bad=(self.guard>0)&valid
            self.command[bad]=q[bad]
        self._time('physics_and_state',started)
        self.sim.render()
        self.global_ticks+=1;self.steps[valid]+=1;self.phase_tick+=1
        self.control_samples+=int(valid.sum())
        self.peaks=torch.maximum(self.peaks,self.step_peak*valid)
        self.guard[valid&((self.joint_pos[:,:7]-self.last_q).abs().amax(-1)>.03)]=8
        self.last_q=self.joint_pos[:,:7].clone()
        tip=self._robot_tip_base()
        # Encoder samples occur once per 0.1s, never per PhysX substep.
        encoder_valid=(self.phase==self.WARMUP)|valid
        self.encoder.update(self._wrench()[:,:3],encoder_valid)
        force=self._wrench()[:,:3]-self.encoder.baseline
        row=torch.cat((force/7.5,(tip-self.last_tip)/.002,self.effect,torch.ones(self.num_envs,1,device=self.device)),-1).clamp(-40,40)
        self.history[valid]=torch.cat((self.history[valid,1:],row[valid,None]),1)
        self.last_tip=tip.clone()
        self.latch.update(force,(tip-self.calibration.position)[:,2],valid)
        after=(torch.linalg.vector_norm((self.held_pos-self.fixed_pos)[:,:2],dim=-1),(self.held_pos-self.fixed_pos)[:,2])
        tilt=torch.rad2deg(torch.acos(quat_matrix(self.held_quat)[:,2,2].abs().clamp(0,1)))
        success=valid&(after[0]<.003)&(after[1]<.003)&(self.guard==0)
        timeout=valid&(self.steps>=round(self.settings.seconds/.1))
        done=valid&(success|timeout|(self.guard>0))
        rew,terms=reward(before,after,tilt,self.step_peak,self.effect-self.previous_effect,success,done&~success,self.settings,self.latch.active)
        rew*=valid;self.returns+=rew
        self.chunk_age[valid]+=1;self.chunk_index[valid]+=1
        self.chunk_age[valid&(self.chunk_age>=10)]=0
        self._advance_startup()
        # Bootstrap observations precede reset; no GAE path ever crosses reset.
        terminal_observation=self.observe()
        if self.args.save_trace:
            for i in valid.nonzero().flatten().cpu().tolist():self._append_trace(i,action,before,after,terms)
        episodes=[]
        for i in done.nonzero().flatten().cpu().tolist():
            result=dict(case=self.cases[i],env_id=i,episode_id=int(self.episode_id[i]),success=bool(success[i]),
                timed_out=bool(timeout[i]),guard=int(self.guard[i]),steps=int(self.steps[i]),
                formal_seconds=int(self.steps[i])*.1,return_value=float(self.returns[i]),
                xy_m=float(after[0][i]),z_m=float(after[1][i]),peak_force_n=float(self.peaks[i]),
                calibration_position_base_m=self.calibration.position[i].cpu().tolist(),
                calibration_error_bound_m=self.calibration.uncertainty[i].cpu().tolist())
            episodes.append(result);self.rows.append(result)
            self._save_case(i,result)
        if bool(done.any()):self.reset_ids(done.nonzero().flatten())
        self.prepare_teacher()
        next_obs=self.observe()
        return next_obs,rew,done,dict(valid=valid,actor_valid=actor_valid,episodes=episodes,
                                    terminal_observation=terminal_observation)

    def _advance_startup(self):
        closing=(self.phase==self.CLOSE)&(self.phase_tick>=6)
        if bool(closing.any()):
            ids=closing.nonzero().flatten();self._snap_peg(ids)
            self.phase[ids]=self.SETTLE;self.phase_tick[ids]=0
        settling=(self.phase==self.SETTLE)&(self.phase_tick>=2)
        if bool(settling.any()):
            ids=settling.nonzero().flatten()
            self.warm_q[ids]=self.joint_pos[ids];self.command[ids]=self.joint_pos[ids,:7]
            self.phase[ids]=self.WARMUP;self.phase_tick[ids]=0;self.encoder.reset(ids)
        warmed=(self.phase==self.WARMUP)&(self.phase_tick>=20)&self.encoder.ready
        if bool(warmed.any()):
            ids=warmed.nonzero().flatten()
            q_error=(self.joint_pos[ids,:7]-self.source_q[ids]).abs().amax(-1)
            if bool((q_error>.03).any()):raise RuntimeError('Recorded joint reset mismatch')
            if bool((-quat_matrix(self.fingertip_midpoint_quat[ids])[:,2,2]<math.cos(math.radians(8))).any()):
                raise RuntimeError('Recorded initial tool is not downward within the original 8 degree tolerance')
            for i in ids.cpu().tolist():
                if np.max(np.abs(self.fixed_pos[i].cpu().numpy()-np.array(self.cases[i]['hole_position_m'])))>1e-4:
                    raise RuntimeError('Frozen hole reset mismatch')
            estimated=(self._robot_tip_base()-self.calibration.position)[:,2]
            tare=self._wrench()[:,:3]-self.encoder.baseline
            mask=torch.zeros(self.num_envs,dtype=torch.bool,device=self.device);mask[ids]=True
            self.latch.update(tare,estimated,mask)
            self.phase[ids]=self.READY;self.phase_tick[ids]=0;self.chunk_age[ids]=0
            self.command_gripper[ids]=self.joint_pos[ids,7:9].sum(-1)/.08

    def _append_trace(self,i,action,before,after,terms):
        self.trace[i].append(dict(time_s=float(self.steps[i])*.1,action=action[i].detach().cpu().numpy(),
            offset=self.integrator.offset[i].cpu().numpy(),command=self.command[i].cpu().numpy(),
            command_effect=self.effect[i].cpu().numpy(),nominal=self.nominal[i].cpu().numpy(),
            gate=float(self.latch.gate[i]),force=self._wrench()[i].cpu().numpy(),
            xy_m=float(after[0][i]),z_m=float(after[1][i]),**{k:float(v[i]) for k,v in terms.items()}))

    def _save_case(self,i,result):
        if self.sampler.split=='train':return
        name=f"case_{result['case']['case_id']:04d}"
        path=self.output/name
        atomic_json(path/'summary.json',result)
        if self.trace[i]:
            np.savez_compressed(path/'episode.npz',**{k:np.asarray([r[k] for r in self.trace[i]]) for k in self.trace[i][0]})

    def progress(self):
        elapsed=time.monotonic()-self.elapsed_start
        return dict(physical_ticks=self.global_ticks,control_steps=self.control_samples,
                    elapsed_seconds=elapsed,control_steps_per_second=self.control_samples/max(elapsed,1e-6),
                    stages=self.timing,episodes=len(self.rows),active_environments=int((self.phase==self.READY).sum()))

    def close(self):
        # The runner owns pool lifetime, including construction failures.
        super().close()
