"""Independent training/validation holes and immutable historical regression cases."""
import copy
import numpy as np
from .settings import ROOT


def records():
    from tavla_rl.random_cases import recorded_starts
    return recorded_starts(audit_orientation=False)


def normalize_record(row):
    return dict(profile=int(row.get('profile',row.get('source_profile',0))),
                joint_pos_rad=row.get('joint_pos_rad',row.get('arm_joint_pos_rad')),
                hole_position_m=row['hole_position_m'])


class CaseSampler:
    def __init__(self,seed,settings,*,split='train',manifest=None):
        self.cfg=settings; self.split=split; self.rng=np.random.default_rng(seed)
        self.sources=[normalize_record(r) for r in records()]
        self.round=[]; self.counter=0
        self.delivered=set()
        self.fixed=None
        if split=='validation':
            rng=np.random.default_rng(settings.validation_seed)
            self.fixed=[dict(self._make(i,rng,settings.validation_seed+i),case_id=i) for i in range(40)]
        elif split=='test':
            from tavla_rl.pose_eval import load_pose_cases
            saved=load_pose_cases(manifest or ROOT/'outputs/peg_three_models_v6/test_cases.json')
            if saved['config']['formal_seconds']!=settings.seconds:
                raise ValueError('Test duration must match the frozen 50-case comparison')
            self.fixed=[dict(case_id=c['case_id'],source_profile=c['source_profile'],
                initial_joint_pos_rad=c['arm_joint_pos_rad'],hole_position_m=c['hole_position_m'],
                evaluation_seed=c['physics_seed'],calibration_seed=731003+c['case_id'],split='test') for c in saved['cases']]
            self.manifest_id=saved['manifest_id']

    def _make(self,profile,rng,seed):
        source=self.sources[profile]
        hole=np.asarray(source['hole_position_m'],float).copy(); hole[:2]+=rng.uniform(-.05,.05,2)
        return dict(case_id=self.counter,source_profile=profile,initial_joint_pos_rad=source['joint_pos_rad'],
                    hole_position_m=hole.tolist(),evaluation_seed=42,sampling_seed=int(seed),calibration_seed=int(seed)+40121,split=self.split)

    def next(self,env_id=None,num_envs=None):
        if self.fixed is not None and self.split in ('validation','test') and env_id is not None:
            # The same case always runs on the same clone in every policy arm,
            # regardless of which previous episodes happened to finish first.
            candidates=[c for c in self.fixed if c['case_id']%num_envs==env_id and c['case_id'] not in self.delivered]
            if not candidates:return None
            value=copy.deepcopy(candidates[0]);self.delivered.add(value['case_id']);self.counter+=1
            return value
        if self.fixed is not None:
            if self.counter>=len(self.fixed): return None
            value=copy.deepcopy(self.fixed[self.counter])
        else:
            if not self.round:self.round=list(self.rng.permutation(40))
            value=self._make(int(self.round.pop()),self.rng,int(self.rng.integers(0,2**31)))
        self.counter+=1
        return value

    def state_dict(self):return copy.deepcopy(dict(rng=self.rng.bit_generator.state,round=self.round,counter=self.counter))

    def load_state_dict(self,value):
        self.rng.bit_generator.state=value['rng']; self.round=list(value['round']); self.counter=int(value['counter'])


def calibration_key(case): return f"{case['split']}:{case['case_id']}"
